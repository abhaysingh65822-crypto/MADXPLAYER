# MADXPLAYER — Premium Neon Audio Experience

A modern, local-first Android music player built with Jetpack Compose and AndroidX Media3 ExoPlayer, pairing a distinct AMOLED black and purple neon visual identity with seamless local and legal online streaming, offline downloads, synchronized lyrics, a custom equalizer, and an integrated Gemini AI Music DJ.

### User Review & Critical Decisions

> [!IMPORTANT]
> The following product decisions were confirmed during clarification and will govern the system design:

- **Confirmed Decision 1 (Gemini AI Integration)**: An integrated **AI Music DJ & Smart Playlist Generator** provides intelligent mood mixes, contextual song insights, dynamic smart queues, and conversational music discovery.
- **Confirmed Decision 2 (Default Landing View)**: The app launches into **Discovery Home** with trending genres (Hindi, Bollywood, Punjabi, Lo-fi, Indie, English), mood radio carousels, and quick picks, with one-tap access to Your Library and Search.
- **Confirmed Decision 3 (Stream Catalog & Source Architecture)**: Out-of-the-box legal streaming combines high-quality curated royalty-free tracks (Jamendo & Creative Commons catalogs) and ambient radio channels with device MediaStore scanning and custom stream URL playback.

---

### 1. Overview & Core Concept

- **What It Does**: MADXPLAYER delivers a high-performance, subscription-free music listening experience. It indexes and plays local device audio files, streams licensed online catalogs and ambient mood stations, manages multi-track offline downloads with progress tracking, displays time-synced lyrics with autoscroll, and shapes sound via a 5-band audio equalizer with bass boost.
- **Target Audience / Persona**: Music enthusiasts who want an ultra-responsive, private, local-first music player with Spotify-grade polish, zero forced sign-ups or subscription paywalls, and deep user control over queues, playlists, audio effects, and downloads.
- **Key Value**: Uncompromised audio playback powered by AndroidX Media3 ExoPlayer and MediaSessionService, paired with an original black-and-purple neon aesthetic, offline durability via Room, and intelligent playlist crafting via Gemini AI.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **Launch & Quick Play**: User launches the app directly into Discovery Home. Tapping any song or playlist immediately loads the persistent Mini-Player and starts background playback through AndroidX MediaSession.
2. **Immersive Now Playing & Lyrics**: Expanding the Mini-Player reveals a full-bleed player featuring high-res album artwork, neon glow effects, dynamic progress slider, shuffle/repeat toggles, queue manager drawer, and a dedicated Synced Lyrics view that autoscrolls with playback.
3. **Local Library & SAF Scanner**: Navigating to "Your Library" scans device audio via MediaStore (with graceful runtime storage/audio permission prompts), organizing tracks by Songs, Albums, Artists, Playlists, and Downloads.
4. **AI Music DJ**: User taps the neon DJ badge on Home or Search to prompt the Gemini AI DJ (e.g., "Late night coding lo-fi with heavy bass" or "Upbeat 90s Bollywood workout"), generating instant custom playable queues and track explanations.
5. **Download Manager**: Tapping download on any eligible streaming track queues it in the Downloads Manager with real-time transfer progress, pause/resume, Wi-Fi constraints, and offline playback availability in the Library.
6. **Equalizer & Sound FX**: Accessible from Now Playing or Settings, users can switch between Rock, Pop, Bass Boost, Vocal, and Jazz presets or tweak a 5-band graphic EQ and bass virtualizer.

#### Visual Identity & Theme
- **Aesthetic Direction**: *AMOLED Cyber-Neon* — deeply dark, pitch-black canvases (#0A0812 and #000000) accentuated by vivid electric purple (#A855F7), hot magenta (#E879F9), and neon violet (#7C3AED) glows.
- **Color Tokens**:
  - `background`: `#09070F` (True dark with subtle violet undertone)
  - `surface`: `#140F24` (Elevated dark card surface)
  - `surfaceVariant`: `#1E1736` (Interactive element container)
  - `primary`: `#A855F7` (Vivid Neon Purple)
  - `primaryContainer`: `#3B185F` (Deep luminous violet container)
  - `secondary`: `#06B6D4` (Electric Cyan secondary accent for highlights and active indicators)
  - `tertiary`: `#F43F5E` (Hot Neon Rose for favorites/likes)
  - `onBackground` / `onSurface`: `#F3F0FA` (High-contrast crisp typography)
  - `outline`: `#2E224D` (Subtle boundary borders)
- **Typography & Hierarchy**:
  - Display & Headers: Bold, modern sans-serif typography with generous line-height and letter-spacing for category headers.
  - Body & Metadata: Crisp, accessible body text with high contrast ratios (APCA / WCAG AA compliant).
- **Component Styling & Layout**:
  - Bottom navigation bar with 3 primary destinations: *Home*, *Search*, *Your Library*.
  - Floating/docked Mini-Player positioned directly above the bottom bar with gesture-swipe expand to full-screen.
  - Rounded cards (16dp-20dp), neon edge highlights, and smooth gradient overlays.

---

### 3. Key Product Decisions & Trade-Offs

- **AndroidX Media3 ExoPlayer + MediaSessionService**:
  - *Chosen Approach*: Implement a foreground `MediaSessionService` that manages `ExoPlayer` lifecycle, audio focus, lock-screen notifications, headset disconnect events, and background continuity.
  - *Why*: It is the modern, official Android standard for media playback, ensuring flawless background playback without OS termination and standard Android media controls.
- **Local-First Data Persistence (Room + DataStore)**:
  - *Chosen Approach*: Use Room Database for playlists, track metadata, playback history, liked tracks, and download queue records. DataStore for audio presets and UI preferences.
  - *Why*: MADXPLAYER is strictly local-first and requires no user authentication or third-party cloud backend. User data stays private, fast, and durable across app restarts.
- **Curated Legal Streaming & Extensible Resolver Architecture**:
  - *Chosen Approach*: A modular `MusicSourceAdapter` interface with two active implementations: `MediaStoreLocalAdapter` for device files and `CuratedStreamAdapter` for licensed, royalty-free audio tracks and radio streams across Hindi/Bollywood, Lo-fi, Indie, and Electronic genres.
  - *Why*: Guarantees instant, zero-configuration playback out-of-the-box on the streaming emulator without requiring external Python environments or violating DRM.
- **Direct REST Integration with Gemini 3.5 Flash**:
  - *Chosen Approach*: Integrate Gemini REST API using Retrofit and OkHttp for the AI Music DJ and track intelligence, reading `BuildConfig.GEMINI_API_KEY` with graceful fallback when offline.
  - *Why*: Fast responses, structured JSON parsing for smart playlist recommendations, and no heavy unnecessary SDK overhead.

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                              MADXPLAYER                                │
├────────────────────────────────────────────────────────────────────────┤
│                           PRESENTATION LAYER                           │
│  ┌─────────────────┐  ┌─────────────────┐  ┌────────────────────────┐  │
│  │   HomeScreen    │  │  SearchScreen   │  │     LibraryScreen      │  │
│  │ (Genres/Moods/  │  │ (Live Search &  │  │ (Local, Playlists,     │  │
│  │  AI DJ Card)    │  │  AI Prompts)    │  │  Downloads, History)   │  │
│  └────────┬────────┘  └────────┬────────┘  └───────────┬────────────┘  │
│           │                    │                       │               │
│           └────────────────────┼───────────────────────┘               │
│                                ▼                                       │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │    NowPlayingScreen & SyncedLyricsSheet & EqualizerDialog        │  │
│  │    Persistent Mini-Player Bar (Swipe up to expand)               │  │
│  └─────────────────────────────┬────────────────────────────────────┘  │
├────────────────────────────────┼───────────────────────────────────────┤
│                         VIEWMODEL & DOMAIN                             │
│  ┌─────────────────────────────▼────────────────────────────────────┐  │
│  │     PlayerViewModel  •  LibraryViewModel  •  AiDjViewModel       │  │
│  └─────────────────────────────┬────────────────────────────────────┘  │
├────────────────────────────────┼───────────────────────────────────────┤
│                            DATA LAYER                                  │
│  ┌─────────────────────────────▼────────────────────────────────────┐  │
│  │                      MusicRepository                             │  │
│  │  ┌──────────────────┐  ┌──────────────────┐  ┌─────────────────┐ │  │
│  │  │ MediaStore Local │  │  Curated Online  │  │ DownloadManager │ │  │
│  │  │    Audio Scanner │  │  Stream Catalog  │  │  (Multi-track)  │ │  │
│  │  └──────────────────┘  └──────────────────┘  └─────────────────┘ │  │
│  │  ┌─────────────────────────────────────────────────────────────┐ │  │
│  │  │ Room Database: Tracks, Playlists, Favorites, PlaybackHistory│ │  │
│  │  └─────────────────────────────────────────────────────────────┘ │  │
│  │  ┌─────────────────────────────────────────────────────────────┐ │  │
│  │  │ GeminiService: AI Smart Playlists, Music DJ, Song Meaning   │ │  │
│  │  └─────────────────────────────────────────────────────────────┘ │  │
│  └─────────────────────────────┬────────────────────────────────────┘  │
├────────────────────────────────┼───────────────────────────────────────┤
│                         PLAYBACK CORE                                  │
│  ┌─────────────────────────────▼────────────────────────────────────┐  │
│  │  MediaPlaybackService (AndroidX MediaSessionService)             │  │
│  │   - ExoPlayer Engine                                             │  │
│  │   - AudioFocus & NoisyReceiver (Headphone unplug pause)          │  │
│  │   - Android Equalizer & BassBoost Audio Effect                   │  │
│  │   - MediaNotificationProvider (Lock-screen & persistent notification)│
│  └──────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
```

#### Key Entities & Schema
- `TrackEntity`: id, title, artist, album, durationMs, streamUrl/localUri, artworkUrl, genre, isDownloaded, localFilePath, lyricsJson.
- `PlaylistEntity`: id, name, description, coverArtworkUrl, createdAt.
- `PlaylistTrackCrossRef`: playlistId, trackId, sortOrder.
- `PlaybackHistoryEntity`: trackId, playedAtTimestamp, completionPercentage.
- `FavoriteTrackEntity`: trackId, favoritedAt.

#### Interactive Component & State Mapping
- `PlayerViewModel` maintains `PlayerUiState`: currentTrack, isPlaying, currentPositionMs, durationMs, shuffleMode, repeatMode, queue, equalizerSettings.
- `MediaPlaybackService` acts as the single source of truth for audio playback, broadcasting state changes to `PlayerViewModel` via Kotlin StateFlow.
- `DownloadManager` runs background coroutines to download selected streaming audio into app-specific media storage, updating Room `TrackEntity.isDownloaded` and `localFilePath`.
