# MADXPLAYER Upgrade Report

## What changed

This update targets the main source-level problems found in the supplied ZIP rather than only restyling screens.

### Catalog quality and discovery
- Removed the hardcoded fictional tracks paired with generic SoundHelix demo audio from the production catalog.
- Disabled the old curated provider as a source of results so it cannot fabricate song, artist, album, or detail content.
- Home discovery now fetches from configured online providers, refreshes when the selected genre changes, and keeps local playback available when online discovery fails.
- Added honest empty/loading/retry states and replaced invented “popular search” names with genre/topic suggestions.
- The Composite provider now combines configured source results without letting one provider occupy every first result.

### Provider integration
- Jamendo search, artist and album lookups use the documented API adapter and require a configured Client ID.
- Jamendo stream URLs are kept separate from direct download URLs; the per-track `audiodownload_allowed` field is respected.
- Internet Archive search resolves the actual audio filename from item metadata rather than guessing `{identifier}.mp3`. The adapter excludes records without a recognizable Creative Commons/public-domain rights label and an actual accessible audio file.
- Provider failures are contained so one source failing should not prevent local use or results from another source.

### Playback and data reliability
- Fixed the AI DJ catalog loading path so it reads the first available catalog snapshot rather than repeatedly collecting an endless flow before completing.
- Playback history is now recorded when a track begins playing rather than only after it finishes; removed the earlier duplicate record on the tap event.
- Added a Room migration for provider-authorized download URL and permission fields.
- Download policy denies arbitrary custom streams and local device files; downloaded files are validated for audio-like MIME/extensions and length before being marked complete. Cancellation cleanup is protected against a rapid retry race.
- Removing an app-managed offline copy preserves the original stream URI.
- Device-local music is marked as local, not as an app-managed downloaded copy.
- Added a Gradle bootstrap script because the uploaded project did not contain the usual Gradle wrapper script/JAR, and improved the GitHub Actions Android SDK setup.

## Files materially changed

- `app/src/main/java/com/example/data/repository/CuratedMusicCatalog.kt`
- `app/src/main/java/com/example/data/source/CuratedSourceAdapter.kt`
- `app/src/main/java/com/example/data/source/JamendoSourceAdapter.kt`
- `app/src/main/java/com/example/data/source/InternetArchiveSourceAdapter.kt`
- `app/src/main/java/com/example/data/source/CompositeMusicProvider.kt`
- `app/src/main/java/com/example/data/repository/MusicRepository.kt`
- `app/src/main/java/com/example/data/local/MusicDao.kt`
- `app/src/main/java/com/example/data/local/Entities.kt`
- `app/src/main/java/com/example/data/local/MadxDatabase.kt`
- `app/src/main/java/com/example/data/model/Track.kt`
- `app/src/main/java/com/example/data/download/DownloadManager.kt`
- `app/src/main/java/com/example/data/download/MusicDownloadPolicy.kt`
- `app/src/main/java/com/example/playback/PlaybackController.kt`
- `app/src/main/java/com/example/playback/MediaPlaybackService.kt`
- `app/src/main/java/com/example/data/ai/GeminiMusicService.kt`
- `app/src/main/java/com/example/ui/viewmodel/HomeViewModel.kt`
- `app/src/main/java/com/example/ui/viewmodel/PlayerViewModel.kt`
- `app/src/main/java/com/example/ui/viewmodel/AiDjViewModel.kt`
- `app/src/main/java/com/example/ui/screens/HomeScreen.kt`
- `app/src/main/java/com/example/ui/screens/SearchScreen.kt`
- `app/src/main/java/com/example/ui/screens/AiDjDialog.kt`
- `app/src/main/java/com/example/ui/components/TrackRowItem.kt`
- `app/src/main/java/com/example/MadxApplication.kt`
- `.env.example`, `app/build.gradle.kts`, `gradlew`, `gradlew.bat`, `.github/workflows/build.yml`, `README.md`
- Added `app/src/test/java/com/example/MusicDownloadPolicyTest.kt`

## Checks performed

- `gradlew` shell syntax validation: passed.
- Android manifest XML parsing: passed.
- Version catalog TOML parsing: passed.
- GitHub Actions workflow YAML parsing: passed.
- Pure Kotlin download-policy smoke test: 8 assertions passed.
- Full Gradle/Android build and Robolectric/unit test suite: **not verified in this environment**. The Gradle distribution is not preinstalled, and the environment could not resolve `services.gradle.org` while trying to download it. Do not treat this ZIP as a confirmed compiled APK until the GitHub Actions workflow finishes successfully.

## Required setup

1. Create a Jamendo application in the official [Jamendo Developer Portal](https://devportal.jamendo.com/).
2. Copy `.env.example` to `.env` for a local build and set the real `JAMENDO_CLIENT_ID`; keep `.env` private. A placeholder/unknown ID will not enable the Jamendo source.
3. Gemini is optional. For personal testing, configure `GEMINI_API_KEY` only through an appropriate local environment/secret setup. A key compiled into an Android APK can be extracted; a public release should use a protected backend.
4. For GitHub builds, add `JAMENDO_CLIENT_ID` and, optionally, `GEMINI_API_KEY` under **Repository → Settings → Secrets and variables → Actions**. The workflow creates an ignored temporary `.env`; neither credential is committed to the ZIP.
5. Push the project to GitHub and run **MADXPLAYER Build & Test** under Actions. Download the `madxplayer-debug-apk` artifact only if the workflow completes successfully.
6. Test the resulting APK on a physical Android device: permissions, local audio, online provider results, stream playback, background/lock-screen controls, app restart, and download eligibility.

## Known limitations

- These sources do not provide Spotify's full commercial catalog. New commercial Hindi/Bollywood/Punjabi tracks are not guaranteed to exist in Jamendo or Internet Archive.
- Search quality and available results depend on real API responses and network access. No provider credentials/network could be live-tested during this source edit.
- This project is not yet certified for release and has not been verified by a successful full Android build in this environment.


## Link extraction / offline download integration (2026-10-18)

- Added the maintained `yt-dlp-android` wrapper for resolving supported user-supplied URLs to a live stream URL (`-g`) and optional user-authorized audio-only downloads.
- Added maintained FFmpegKit audio for conversion of successful offline downloads to MP3 when that conversion is available. Original audio is preserved when optional conversion fails.
- Added Media3 HLS module and limited packaged native ABIs to `arm64-v8a` and `x86_64`, matching the extractor runtime.
- Wired a Search link dialog with separate **PLAY LIVE** and **DOWNLOAD** actions and an explicit permission confirmation. Completed downloads are recorded in the Room-backed offline library.
- Audio.com URLs intentionally open the official Audio.com player. The app does not automate extraction on Audio.com, and does not download tracks there; Audio.com’s help says a track is downloadable by others only when its uploader enables downloads.
- Build verification remains pending until GitHub Actions completes. The yt-dlp runtime substantially increases APK size; unsupported websites/streams can still fail, so device/provider testing is required.


## Validation note

- AndroidManifest XML parsed successfully and changed Kotlin source files have balanced braces/parentheses under basic static checks.
- A local Gradle build was attempted, but the runner could not resolve `services.gradle.org` (DNS/network unavailable); therefore dependency resolution and Kotlin compilation have not been verified in this environment. Please run the supplied GitHub Actions build to verify the final Android package.
