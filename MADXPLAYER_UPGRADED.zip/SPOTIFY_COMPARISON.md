# MADXPLAYER vs Spotify: honest feature comparison

MADXPLAYER is being upgraded to be a useful customizable Android player. It cannot honestly be described as “better than Spotify overall” today: Spotify has licensed catalog and service infrastructure that an individual app cannot reproduce just by writing code. The fair comparison is feature by feature.

| Area | MADXPLAYER in this source update | Spotify service | Current practical edge |
|---|---|---|---|
| Commercial catalogue | Jamendo + selected open-license/public-domain Internet Archive audio + files on the user's phone. Hindi/Bollywood/Punjabi commercial releases may be missing. | Broad commercial streaming catalogue under its licensing arrangements. Availability can vary by market. | Spotify for catalogue breadth. |
| Online search | Queries configured providers; displays actual results rather than fixed demo tracks. Results may be sparse if providers have no match. | Search across Spotify's available music catalogue. | Spotify for breadth and consistency; MADXPLAYER gives control over its provider adapters. |
| Local device files | First-class local library from Android MediaStore, with local-only search and playback. | Spotify's primary experience is its service catalogue; local-file behaviour depends on supported client/platform and settings. | MADXPLAYER is designed around local-first use. |
| Background/lock-screen playback | Media3 + MediaSessionService controls are implemented in source; requires device verification. | Established background playback and cross-device controls. | Spotify's integration is more mature; MADXPLAYER needs real-device validation. |
| Playlists / favourites / history | Local Room storage and playlist/favourite/history flows. | Account-synced playlists, saved music and history features depending on client/settings. | Spotify for account sync; MADXPLAYER for local-first personal data. |
| Offline copies | Only source-authorized downloadable files are enabled. Device-local files already work offline. | Spotify Premium offers offline downloads in supported markets/plans, subject to app/track rules. | Spotify for its licensed offline catalogue; MADXPLAYER for user-owned local files and permitted provider files. |
| Lyrics | Lyrics UI exists; actual lyrics require a real available provider/local file. | Lyrics are available for supported tracks and markets, with catalogue/availability limits. | Spotify for integrated catalogue coverage; MADXPLAYER requires lyric-source integration. |
| AI recommendations | Gemini commentary is optional, with local mood matching fallback; suggestions must resolve to real tracks before they can be played. | Spotify provides editorial/personalization features and has product-specific AI features by market/plan. | Neither can be compared until tested against defined tasks; Spotify has more service data. |
| Audio effects | 5-band EQ/bass boost uses Android device audio effects where supported; hardware behaviour varies. | Spotify's audio settings/features vary by app, market and plan. | Potential MADXPLAYER customization advantage, device-dependent. |
| Accounts and cloud sync | Designed for no-login/local-first use; does not provide Spotify-like multi-device cloud sync. | Spotify accounts and Spotify Connect support service use across supported devices. | Spotify for multi-device continuity; MADXPLAYER for no-account personal use. |
| Ads and payment | The app itself has no subscription/payment system, but external provider terms still apply. | Free and paid plans differ by market and features; Premium adds ad-free/offline and other paid features. | MADXPLAYER avoids app-level subscription complexity, but does not substitute for a licensed commercial catalogue. |

## What would be required before claiming competitive parity

1. Verify all Gradle build/tests and test on multiple physical devices.
2. Integrate a broad licensed music catalogue with explicit rights for streaming, caching and downloads; a Jamendo Client ID alone does not do this.
3. Add a reliable lyrics source, metadata/artwork caching, robust network/offline state and accessibility tests.
4. Add account/cloud sync only if desired, with secure authentication and data protection.
5. Measure crash rate, start time, stream failures, search latency, battery use and user task completion against a defined comparison checklist.

## Public references

- Spotify Free plan feature overview: https://www.spotify.com/free/
- Spotify Premium feature overview: https://www.spotify.com/premium/
- Spotify Connect support: https://support.spotify.com/article/spotify-connect/
- Jamendo API portal/documentation: https://developer.jamendo.com/v3.0
- Jamendo API track response includes an explicit `audiodownload_allowed` field: https://developer.jamendo.com/v3.0/tracks
- Internet Archive metadata API: https://archive.org/developers/md-read.html
- Gemini API model catalogue: https://ai.google.dev/gemini-api/docs/models

Feature availability, plan names, API permissions, and catalogue access may change. Verify current official terms before public distribution.
