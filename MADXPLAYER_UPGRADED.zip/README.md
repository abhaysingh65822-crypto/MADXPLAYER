# MADXPLAYER

MADXPLAYER is a local-first Android music player with an AMOLED black / purple-neon interface. It combines music stored on the phone with online results from configured providers. It does **not** ship a fictional song catalog or pretend that demo audio is real music.

## What is implemented in this project

- Kotlin, Jetpack Compose and Material 3 UI.
- AndroidX Media3 ExoPlayer and a `MediaSessionService` for system media controls.
- Local device audio discovery through MediaStore (Android permission required).
- Room-backed playlists, favorites, search history and playback history.
- Online music-provider adapters for Jamendo and Internet Archive audio that has a recognizable Creative Commons/public-domain rights label and a real audio file listed in item metadata.
- Genre-aware home discovery that requests fresh provider results when a genre changes instead of filtering one fixed sample list.
- Download policy that separates a playable stream URL from a provider-authorized download URL; Jamendo downloads require its per-track permission flag.
- Artist, album and track results derived from provider responses.
- Custom direct-stream URL playback (streaming only; not automatically downloadable).
- Android link player powered by the maintained yt-dlp Android wrapper: resolves supported, user-supplied source pages to playable audio URLs for live playback without first saving the whole track.
- Optional user-authorized offline audio downloads from supported sources. The embedded FFmpegKit audio module attempts a local MP3 conversion, and completed files are saved in the MADXPLAYER offline library.
- HLS playback module for supported extracted live streams.
- Audio.com links are opened in Audio.com’s official web player. MADXPLAYER intentionally does not use yt-dlp/scraping against Audio.com because its terms restrict automated extraction; in-app downloads are not attempted there. Use Audio.com’s own download control only when the uploader has enabled it.
- Lyrics view, audio effects/equalizer UI, queue, sleep timer and a Gemini-powered/locally matched DJ flow.
- A Gradle bootstrap launcher and GitHub Actions workflow for tests and a debug APK artifact.

## Important catalog limitations

MADXPLAYER does not have Spotify's commercial licensing agreements or Spotify's complete catalog. Jamendo mainly provides independent/open-license music, and the Internet Archive has mixed content; this integration filters out Archive items unless the metadata identifies an open license/public-domain status and a playable audio filename. Therefore some searches can return no result. Bollywood/Hindi/Punjabi commercial releases are not guaranteed to be available through these sources.

## Link player: yt-dlp, FFmpeg, and Audio.com

From **Search → link icon**, enter a direct audio URL or a page on a yt-dlp-supported source. Tap **PLAY LIVE** to resolve a stream URL and hand it to Media3; the app does not intentionally save a complete file for this action. Tap **DOWNLOAD** to download an audio rendition and, where supported, convert it to MP3 with FFmpeg before saving it to the app’s offline library. The link dialog requires the user to confirm they are authorized to use the media and that the source permits the selected action.

This is not a promise that every website will work. Site changes, short-lived stream URLs, required headers, authentication, formats, network conditions, and a source’s rules can prevent extraction or playback. MADXPLAYER does not bypass DRM, paywalls, login restrictions, or source access controls. The embedded yt-dlp runtime supports arm64-v8a and x86_64 and adds a substantial amount to APK size (the upstream library documents roughly 60–80 MB for its runtime). 32-bit-only devices are not supported by this extractor build.

**Audio.com:** public/unlisted tracks can stream through Audio.com’s player; downloads are available only when the uploader enables them. MADXPLAYER opens Audio.com URLs in the official player instead of scraping/extracting its media URLs. See [Audio.com playback help](https://help.audio.com/en/articles/11585576-streaming-playback-how-audio-playback-works), [download permissions](https://help.audio.com/en/articles/11492536-can-other-users-download-my-audio-content), and [Terms of Use](https://audio.com/legal/terms-of-use).

## MADX AI DJ model selection

AI DJ tries Gemini models in this order: `gemini-3.8-flash` (preferred quality/speed balance), `gemini-3.6-flash`, `gemini-3.5-flash-lite`, then `gemini-2.5-flash`. Model availability can vary by API key, region, and model lifecycle; failures fall through to the next model and ultimately to deterministic local mood matching. The AI can only recommend tracks already present in the app's real local/online catalog; it cannot create licensed streaming access.

For a public release, do not ship a long-lived Gemini API key inside the APK. Android BuildConfig values can be extracted. Use a protected backend with rate limiting, or make users supply their own key locally and store it securely. GitHub Actions Secrets prevent the key from being committed to source, but do not make a key embedded in the APK secret.

## Configuration

### Jamendo

1. Create your own application in the [Jamendo Developer Portal](https://devportal.jamendo.com/).
2. Copy the **Client ID** shown for that application.
3. Copy `.env.example` to `.env` and replace `MY_JAMENDO_CLIENT_ID` with your actual ID.
4. Keep `.env` private. Do not commit real API credentials to a public repository.

If Jamendo is not configured, the app still scans and plays local music and can query the open-license Internet Archive provider. No test/dummy audio is presented as a real track.

### Gemini AI DJ (optional)

Set `GEMINI_API_KEY` in your local `.env` or CI secret configuration to enable Gemini-generated commentary. The app currently requests the configured model ID `gemini-3.8-flash`; if your API account does not support it, update the model ID after checking the official Gemini model list. Direct API keys embedded in an APK can be extracted; this is appropriate only for personal/testing use. For public distribution, use a backend that protects the key and enforces quotas. The local matching fallback works without Gemini but is not a hosted AI model.

## Build

Requirements: JDK 17, Android SDK Platform 36, Build Tools 36.0.0, `curl`, `unzip`, and an internet connection for the first Gradle bootstrap.

```bash
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
```

On Windows use `gradlew.bat`. The bootstrap launcher downloads the Gradle distribution declared in `gradle/wrapper/gradle-wrapper.properties` the first time it runs. GitHub Actions runs tests, builds the debug APK, and publishes `madxplayer-debug-apk` as an artifact.

## Feature status and verification

A source-code change is not proof that a feature works on every device or provider. Online playback depends on a live provider response, license availability and network access. Equalizer effects vary by Android device. Before distribution, run the GitHub workflow and test real provider responses and background playback on a physical Android device.
