# MADXPLAYER

MADXPLAYER is a local-first Android music player with an AMOLED black / purple-neon interface. It combines music stored on the phone with online results from configured providers. It does **not** ship a fictional song catalog or pretend that demo audio is real music.

## What is implemented in this project

- Kotlin, Jetpack Compose and Material 3 UI.
- AndroidX Media3 ExoPlayer and a `MediaSessionService` for system media controls.
- Local device audio discovery through MediaStore (Android permission required).
- Room-backed playlists, favorites, search history and playback history.
- Online music-provider adapters for Jamendo and Internet Archive audio that has a recognizable Creative Commons/public-domain rights label and a real audio file listed in item metadata.
- Genre-aware home discovery that requests fresh provider results when a genre changes instead of filtering one fixed sample list.
- Download policy that separates a playable stream URL from a provider-authorized download URL; Jamendo downloads require its per-track permission flag.
- Artist, album and track results derived from provider responses.
- Custom direct-stream URL playback (streaming only; not automatically downloadable).
- Lyrics view, audio effects/equalizer UI, queue, sleep timer and a Gemini-powered/locally matched DJ flow.
- A Gradle bootstrap launcher and GitHub Actions workflow for tests and a debug APK artifact.

## Important catalog limitations

MADXPLAYER does not have Spotify's commercial licensing agreements or Spotify's complete catalog. Jamendo mainly provides independent/open-license music, and the Internet Archive has mixed content; this integration filters out Archive items unless the metadata identifies an open license/public-domain status and a playable audio filename. Therefore some searches can return no result. Bollywood/Hindi/Punjabi commercial releases are not guaranteed to be available through these sources.

## Configuration

### Jamendo

1. Create your own application in the [Jamendo Developer Portal](https://devportal.jamendo.com/).
2. Copy the **Client ID** shown for that application.
3. Copy `.env.example` to `.env` and replace `MY_JAMENDO_CLIENT_ID` with your actual ID.
4. Keep `.env` private. Do not commit real API credentials to a public repository.

If Jamendo is not configured, the app still scans and plays local music and can query the open-license Internet Archive provider. No test/dummy audio is presented as a real track.

### Gemini AI DJ (optional)

Set `GEMINI_API_KEY` in your local `.env` or CI secret configuration to enable Gemini-generated commentary. The app currently requests the configured model ID `gemini-3.8-flash`; if your API account does not support it, update the model ID after checking the official Gemini model list. Direct API keys embedded in an APK can be extracted; this is appropriate only for personal/testing use. For public distribution, use a backend that protects the key and enforces quotas. The local matching fallback works without Gemini but is not a hosted AI model.

## Build

Requirements: JDK 17, Android SDK Platform 36, Build Tools 36.0.0, `curl`, `unzip`, and an internet connection for the first Gradle bootstrap.

```bash
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
```

On Windows use `gradlew.bat`. The bootstrap launcher downloads the Gradle distribution declared in `gradle/wrapper/gradle-wrapper.properties` the first time it runs. GitHub Actions runs tests, builds the debug APK, and publishes `madxplayer-debug-apk` as an artifact.

## Feature status and verification

A source-code change is not proof that a feature works on every device or provider. Online playback depends on a live provider response, license availability and network access. Equalizer effects vary by Android device. Before distribution, run the GitHub workflow and test real provider responses and background playback on a physical Android device.
