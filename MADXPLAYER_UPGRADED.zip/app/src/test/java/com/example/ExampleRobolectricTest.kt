package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.CuratedMusicCatalog
import com.example.playback.PlaybackController
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app_name from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("MADXPLAYER", appName)
  }

  @Test
  fun `verify production catalog has genre filters but no fake sample tracks`() {
    val genres = CuratedMusicCatalog.getGenres()
    assertTrue(genres.contains("Hindi"))
    assertTrue(genres.contains("Bollywood"))
    assertTrue(genres.contains("Punjabi"))
    assertTrue(genres.contains("Bhojpuri"))
    assertTrue(genres.contains("Lo-fi"))
    assertTrue(genres.contains("English"))
    assertTrue(genres.contains("Indie"))

    val tracks = CuratedMusicCatalog.getInitialTracks()
    assertTrue("Production must not ship fictional tracks with generic demo audio", tracks.isEmpty())
  }

  @Test
  fun `verify lrc lyric parser extracts timestamps and text`() {
    val lrc = """
      [00:15.50]First line of lyrics
      [01:02.00]Second line of lyrics
    """.trimIndent()
    val parsed = PlaybackController.parseLrcLyrics(lrc)
    assertEquals(2, parsed.size)
    assertEquals(15500L, parsed[0].timeMs)
    assertEquals("First line of lyrics", parsed[0].text)
    assertEquals(62000L, parsed[1].timeMs)
    assertEquals("Second line of lyrics", parsed[1].text)
  }
}
