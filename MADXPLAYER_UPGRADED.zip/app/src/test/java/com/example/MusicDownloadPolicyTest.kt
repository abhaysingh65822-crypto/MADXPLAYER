package com.example

import com.example.data.download.MusicDownloadPolicy
import com.example.data.model.Track
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MusicDownloadPolicyTest {
    private fun track(
        source: String = "Jamendo",
        stream: String = "https://music.example/stream",
        download: String? = "https://music.example/download.mp3",
        allowed: Boolean = true,
        local: Boolean = false
    ) = Track(
        id = "test-track",
        title = "Test track",
        artist = "Test artist",
        mediaUri = stream,
        source = source,
        downloadUri = download,
        downloadAllowed = allowed,
        isLocal = local
    )

    @Test fun `Jamendo track downloads only when provider grants permission and URL exists`() {
        assertTrue(MusicDownloadPolicy.canDownload(track()))
        assertFalse(MusicDownloadPolicy.canDownload(track(allowed = false)))
        assertFalse(MusicDownloadPolicy.canDownload(track(download = null)))
    }

    @Test fun `arbitrary custom streams cannot be downloaded`() {
        assertFalse(MusicDownloadPolicy.canDownload(track(source = "Custom Stream")))
        assertFalse(MusicDownloadPolicy.canDownload(track(download = "http://music.example/file.mp3")))
        assertFalse(MusicDownloadPolicy.canDownload(track(local = true)))
    }

    @Test fun `open-license archive audio can be downloaded using its explicit file URL`() {
        assertTrue(MusicDownloadPolicy.canDownload(track(source = "Internet Archive • open-license audio")))
        assertFalse(MusicDownloadPolicy.canDownload(track(source = "Internet Archive", allowed = true)))
    }
}
