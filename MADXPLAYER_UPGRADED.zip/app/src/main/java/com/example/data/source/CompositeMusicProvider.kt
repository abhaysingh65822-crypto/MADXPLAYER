package com.example.data.source

import com.example.data.model.*
import android.util.Log
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

/** Fans out to real configured providers. No fake catalog is used as an online fallback. */
class CompositeMusicProvider(
    val internetArchiveAdapter: InternetArchiveSourceAdapter = InternetArchiveSourceAdapter(),
    val jamendoAdapter: JamendoSourceAdapter = JamendoSourceAdapter(),
    val curatedAdapter: CuratedSourceAdapter = CuratedSourceAdapter()
) {
    val providers: List<MusicSourceAdapter> = listOf(internetArchiveAdapter, jamendoAdapter)

    suspend fun searchAll(
        query: String,
        category: SearchCategory = SearchCategory.ALL,
        page: Int = 1,
        limit: Int = 20
    ): SearchResult = coroutineScope {
        val results = providers.filter { it.isAvailable }.map { provider ->
            async {
                runCatching { provider.search(query, category, page, limit).getOrThrow() }
                    .getOrElse { error ->
                        Log.w("MADX_SOURCES", "${provider.providerName} search failed: ${error.message}", error)
                        SearchResult(query = query)
                    }
            }
        }.awaitAll()
        val tracks = results.flatMap { it.tracks }.distinctBy { it.id }
        val artists = results.flatMap { it.artists }.filter { it.name.isNotBlank() }.distinctBy { it.name.lowercase().trim() }
        val albums = results.flatMap { it.albums }.filter { it.title.isNotBlank() }.distinctBy { it.id.ifBlank { it.title.lowercase().trim() } }
        SearchResult(query, tracks, artists, albums, results.sumOf { it.totalCount }.coerceAtLeast(tracks.size + artists.size + albums.size))
    }

    suspend fun getTrendingTracks(genre: String? = null, limit: Int = 20): List<Track> = coroutineScope {
        val providerResults = providers.filter { it.isAvailable }.map { provider ->
            async {
                runCatching { provider.getTrendingTracks(genre, limit).getOrThrow() }.getOrElse { error ->
                    Log.w("MADX_SOURCES", "${provider.providerName} discovery failed: ${error.message}", error)
                    emptyList()
                }
            }
        }.awaitAll()
        // Round-robin keeps the first provider from crowding out every other connected catalog.
        interleave(providerResults).distinctBy { it.id }.take(limit)
    }

    suspend fun getFeaturedArtists(limit: Int = 15): List<Artist> = coroutineScope {
        val providerResults = providers.filter { it.isAvailable }.map { provider ->
            async {
                runCatching { provider.getFeaturedArtists(limit).getOrThrow() }.getOrElse { error ->
                    Log.w("MADX_SOURCES", "${provider.providerName} artists failed: ${error.message}", error)
                    emptyList()
                }
            }
        }.awaitAll()
        interleave(providerResults).filter { it.name.isNotBlank() }
            .distinctBy { it.name.lowercase().trim() }.take(limit)
    }

    suspend fun getFeaturedAlbums(limit: Int = 15): List<Album> = coroutineScope {
        val providerResults = providers.filter { it.isAvailable }.map { provider ->
            async {
                runCatching { provider.getFeaturedAlbums(limit).getOrThrow() }.getOrElse { error ->
                    Log.w("MADX_SOURCES", "${provider.providerName} albums failed: ${error.message}", error)
                    emptyList()
                }
            }
        }.awaitAll()
        interleave(providerResults).filter { it.title.isNotBlank() }
            .distinctBy { it.id.ifBlank { it.title.lowercase().trim() } }.take(limit)
    }

    private fun <T> interleave(lists: List<List<T>>): List<T> = buildList {
        val maxSize = lists.maxOfOrNull { it.size } ?: 0
        for (index in 0 until maxSize) {
            lists.forEach { values -> values.getOrNull(index)?.let(::add) }
        }
    }

    suspend fun getArtistDetail(artistId: String, artistName: String): ArtistDetail {
        val preferred = when {
            artistId.startsWith("jam_art_") -> jamendoAdapter
            artistId.startsWith("ia_art_") -> internetArchiveAdapter
            else -> null
        }
        if (preferred != null && preferred.isAvailable) {
            preferred.getArtistDetail(artistId, artistName).getOrNull()?.let { detail ->
                if (detail.topTracks.isNotEmpty()) return detail
            }
        }
        val result = searchAll(artistName, SearchCategory.ALL, 1, 30)
        val tracks = result.tracks.filter { it.artist.equals(artistName, true) }
        val artist = result.artists.firstOrNull { it.id == artistId || it.name.equals(artistName, true) }
            ?: Artist(id = artistId, name = artistName)
        val albums = result.albums.filter { it.artist.equals(artistName, true) || it.artistId == artistId }
        return ArtistDetail(artist, tracks, albums)
    }

    suspend fun getAlbumDetail(albumId: String, albumTitle: String = ""): AlbumDetail {
        val preferred = when {
            albumId.startsWith("jam_alb_") -> jamendoAdapter
            albumId.startsWith("ia_alb_") -> internetArchiveAdapter
            else -> null
        }
        if (preferred != null && preferred.isAvailable) {
            preferred.getAlbumDetail(albumId).getOrNull()?.let { detail ->
                if (detail.tracks.isNotEmpty() || albumTitle.isBlank()) return detail
            }
        }
        if (albumTitle.isNotBlank()) {
            val results = searchAll(albumTitle, SearchCategory.ALL, 1, 40)
            val tracks = results.tracks.filter { it.album.equals(albumTitle, true) || it.album.contains(albumTitle, true) }
            val first = tracks.firstOrNull()
            return AlbumDetail(
                album = Album(
                    id = albumId,
                    title = first?.album ?: albumTitle,
                    artist = first?.artist.orEmpty(),
                    artistId = first?.artistId.orEmpty(),
                    artworkUrl = first?.artworkUrl.orEmpty(),
                    trackCount = tracks.size,
                    genre = first?.genre.orEmpty()
                ),
                tracks = tracks
            )
        }
        return AlbumDetail(Album(id = albumId, title = "", artist = ""), emptyList())
    }
}
