package com.example.data.source

import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** Searches Internet Archive audio and only exposes items with a recognizable open/public-domain license
 * and a real audio file listed by the item's metadata API. Archive identifiers are not filenames.
 */
class InternetArchiveSourceAdapter(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
    .build()
) : MusicSourceAdapter {

    override val providerName: String = "Internet Archive (open-license audio)"
    override val isAvailable: Boolean = true

    private data class AudioResource(val uri: String, val license: String)
    private val resolvedResources = ConcurrentHashMap<String, AudioResource>()
    private val metadataSemaphore = Semaphore(3)

    override suspend fun search(
        query: String,
        category: SearchCategory,
        page: Int,
        limit: Int
    ): Result<SearchResult> = withContext(Dispatchers.IO) {
        try {
            val cleanQuery = query.trim().take(120)
            val escaped = cleanQuery.replace("\\", " ").replace('"', ' ').replace(Regex("[{}\\[\\]^~]"), " ")
            val expression = if (escaped.isBlank()) {
                "mediatype:audio"
            } else {
                "mediatype:audio AND (title:($escaped) OR creator:($escaped) OR description:($escaped) OR subject:($escaped))"
            }
            val url = "https://archive.org/advancedsearch.php?q=${encodeQuery(expression)}" +
                "&fl[]=identifier,title,creator,album,description,year,genre,licenseurl,rights" +
                "&rows=${(limit.coerceIn(1, 40) * 3).coerceAtMost(80)}&page=${page.coerceAtLeast(1)}&output=json"
            val request = Request.Builder().url(url).header("User-Agent", "MADXPLAYER/1.1 (Android; open audio discovery)").build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext Result.failure(Exception("Internet Archive HTTP ${response.code}"))
                val json = JSONObject(response.body?.string().orEmpty())
                val responseObj = json.optJSONObject("response") ?: return@withContext Result.success(SearchResult(cleanQuery))
                val docs = responseObj.optJSONArray("docs") ?: return@withContext Result.success(SearchResult(cleanQuery))
                val tracks = resolveTracks(docs, limit.coerceIn(1, 40), "Open audio")
                // numFound includes unlicensed/non-audio items filtered below; report actual playable records.
                Result.success(toSearchResult(cleanQuery, tracks, tracks.size))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getTrendingTracks(genre: String?, limit: Int): Result<List<Track>> = withContext(Dispatchers.IO) {
        try {
            val terms = when {
                genre.isNullOrBlank() || genre.equals("All", true) -> "music OR song OR instrumental OR concert"
                genre.equals("Hindi", true) || genre.equals("Bollywood", true) -> "hindi OR bollywood OR raga OR indian classical"
                genre.equals("Punjabi", true) -> "punjabi OR bhangra"
                genre.equals("Bhojpuri", true) -> "bhojpuri OR purvanchal"
                genre.equals("Haryanvi", true) -> "haryanvi"
                genre.equals("Tamil", true) -> "tamil music"
                genre.equals("Telugu", true) -> "telugu music"
                genre.equals("Bengali", true) -> "bengali music"
                genre.equals("Lo-fi", true) -> "lofi OR ambient OR chill"
                genre.equals("Indie", true) -> "indie OR acoustic"
                genre.equals("Instrumental", true) -> "instrumental"
                else -> genre
            }
            val expression = "mediatype:audio AND ($terms)"
            val url = "https://archive.org/advancedsearch.php?q=${encodeQuery(expression)}" +
                "&fl[]=identifier,title,creator,album,description,year,genre,licenseurl,rights" +
                "&rows=${(limit.coerceIn(1, 40) * 3).coerceAtMost(100)}&page=1&output=json"
            val request = Request.Builder().url(url).header("User-Agent", "MADXPLAYER/1.1 (Android; open audio discovery)").build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext Result.failure(Exception("Internet Archive HTTP ${response.code}"))
                val json = JSONObject(response.body?.string().orEmpty())
                val docs = json.optJSONObject("response")?.optJSONArray("docs") ?: return@withContext Result.success(emptyList())
                Result.success(resolveTracks(docs, limit.coerceIn(1, 40), genre?.takeIf { it != "All" } ?: "Open audio"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getFeaturedArtists(limit: Int): Result<List<Artist>> {
        val tracks = getTrendingTracks("All", (limit * 2).coerceIn(1, 40))
        return tracks.map { list ->
            list.filter { it.artist.isNotBlank() && it.artist != "Unknown creator" }.distinctBy { it.artist.lowercase() }.take(limit).map { track ->
                Artist(
                    id = track.artistId,
                    name = track.artist,
                    bio = "Creator name supplied by Internet Archive. A verified biography was not provided by the source.",
                    imageUrl = "",
                    trackCount = 0,
                    genre = track.genre
                )
            }
        }
    }

    override suspend fun getFeaturedAlbums(limit: Int): Result<List<Album>> {
        val tracks = getTrendingTracks("All", (limit * 2).coerceIn(1, 40))
        return tracks.map { list ->
            list.filter { it.album.isNotBlank() }.distinctBy { it.album.lowercase() }.take(limit).map { track ->
                Album(
                    id = track.albumId,
                    title = track.album,
                    artist = track.artist,
                    artistId = track.artistId,
                    artworkUrl = track.artworkUrl,
                    releaseYear = "",
                    trackCount = 0,
                    genre = track.genre
                )
            }
        }
    }

    override suspend fun getArtistDetail(artistId: String, artistName: String): Result<ArtistDetail> {
        val found = search(artistName, SearchCategory.ALL, 1, 30)
        return found.map { result ->
            val tracks = result.tracks.filter { it.artist.equals(artistName, ignoreCase = true) || it.artistId == artistId }
            val artist = result.artists.firstOrNull { it.id == artistId || it.name.equals(artistName, true) }
                ?: Artist(id = artistId, name = artistName, bio = "No verified biography is available from this source.")
            ArtistDetail(artist = artist, topTracks = tracks, albums = tracks.map {
                Album(it.albumId, it.album, it.artist, it.artistId, it.artworkUrl, genre = it.genre)
            }.filter { it.title.isNotBlank() }.distinctBy { it.id })
        }
    }

    override suspend fun getAlbumDetail(albumId: String): Result<AlbumDetail> {
        val albumName = decodePathSegment(albumId.removePrefix("ia_alb_"))
        if (albumName.isBlank() || albumName == albumId) {
            return Result.failure(NoSuchElementException("Album title is not available for this cached entry. Search again to refresh the album."))
        }
        val found = search(albumName, SearchCategory.ALL, 1, 40)
        return found.map { result ->
            val tracks = result.tracks.filter { it.album.equals(albumName, ignoreCase = true) || it.album.contains(albumName, true) }
            val first = tracks.firstOrNull()
            AlbumDetail(
                album = Album(
                    id = albumId,
                    title = first?.album ?: albumName,
                    artist = first?.artist.orEmpty(),
                    artistId = first?.artistId.orEmpty(),
                    artworkUrl = first?.artworkUrl.orEmpty(),
                    genre = first?.genre.orEmpty(),
                    trackCount = tracks.size
                ),
                tracks = tracks
            )
        }
    }

    /** Returns a real audio file URL from item metadata; never guesses identifier.mp3. */
    suspend fun resolveDirectAudioFile(identifier: String): String? = resolveAudioResource(identifier)?.uri

    private suspend fun resolveTracks(docs: JSONArray, limit: Int, defaultGenre: String): List<Track> = coroutineScope {
        // Archive search results often include records with no declared license or playable file.
        // Inspect a bounded set in small batches and stop once enough valid tracks are found.
        val target = limit.coerceIn(1, 40)
        val candidates = (0 until docs.length()).mapNotNull { docs.optJSONObject(it) }
            .take((target * 3).coerceAtMost(80))
        val collected = mutableListOf<Track>()

        suspend fun resolveOne(doc: JSONObject): Track? {
            val id = doc.optString("identifier").takeIf { it.isNotBlank() } ?: return null
            val resource = resolveAudioResource(id) ?: return null
            val title = valueAsText(doc.opt("title")).ifBlank { id }
            val creator = valueAsText(doc.opt("creator")).ifBlank { "Unknown creator" }
            val album = valueAsText(doc.opt("album"))
            val genre = valueAsText(doc.opt("genre")).ifBlank { defaultGenre }
            val artwork = "https://archive.org/services/img/${encodePathSegment(id)}"
            return Track(
                id = "ia_$id",
                title = title,
                artist = creator,
                album = album,
                durationMs = 0L,
                mediaUri = resource.uri,
                artworkUrl = artwork,
                genre = genre,
                isLocal = false,
                artistId = "ia_art_${encodePathSegment(creator)}",
                albumId = "ia_alb_${encodePathSegment(album)}",
                source = "Internet Archive • open-license audio",
                downloadUri = resource.uri,
                downloadAllowed = true
            )
        }

        for (batch in candidates.chunked(6)) {
            val resolvedBatch = batch.map { doc -> async(Dispatchers.IO) { resolveOne(doc) } }.awaitAll()
            collected += resolvedBatch.filterNotNull()
            if (collected.size >= target) break
        }
        collected.distinctBy { it.id }.take(target)
    }

    private suspend fun resolveAudioResource(identifier: String): AudioResource? {
        resolvedResources[identifier]?.let { return it }
        return metadataSemaphore.withPermit {
            resolvedResources[identifier]?.let { return@withPermit it }
            withContext(Dispatchers.IO) {
                try {
                    val url = "https://archive.org/metadata/${encodePathSegment(identifier)}"
                    val request = Request.Builder().url(url).header("User-Agent", "MADXPLAYER/1.1").build()
                    client.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) return@withContext null
                        val json = JSONObject(response.body?.string().orEmpty())
                        val itemMeta = json.optJSONObject("metadata") ?: JSONObject()
                        val licenseUrl = itemMeta.optString("licenseurl").trim()
                        val rights = itemMeta.optString("rights").trim()
                        val combinedRights = "$licenseUrl $rights".lowercase()
                        val hasReusableLicense = combinedRights.contains("creativecommons.org/licenses/") ||
                            combinedRights.contains("creativecommons.org/publicdomain/") ||
                            combinedRights.contains("creative commons") || combinedRights.contains("public domain")
                        if (!hasReusableLicense) return@withContext null

                        val files = json.optJSONArray("files") ?: return@withContext null
                        val choices = mutableListOf<Pair<Int, String>>()
                        for (i in 0 until files.length()) {
                            val file = files.optJSONObject(i) ?: continue
                            if (file.optBoolean("private", false) || file.optString("private").equals("true", true)) continue
                            val name = file.optString("name").trim()
                            if (name.isBlank() || name.contains("/")) continue
                            val format = file.optString("format").lowercase()
                            val extension = name.substringAfterLast('.', "").lowercase()
                            val rank = when {
                                extension == "mp3" || format.contains("mp3") -> 0
                                extension in setOf("m4a", "aac", "mp4") || format.contains("aac") || format.contains("mpeg4") -> 1
                                extension == "ogg" || extension == "oga" || format.contains("ogg") -> 2
                                extension == "flac" || format.contains("flac") -> 3
                                extension == "wav" || format.contains("wave") -> 4
                                else -> -1
                            }
                            if (rank < 0) continue
                            val size = file.optString("size").toLongOrNull() ?: 0L
                            if (size <= 0L) continue
                            choices += rank to name
                        }
                        val bestName = choices.minByOrNull { it.first }?.second ?: return@withContext null
                        val direct = "https://archive.org/download/${encodePathSegment(identifier)}/${encodePathSegment(bestName)}"
                        AudioResource(direct, if (licenseUrl.isNotBlank()) licenseUrl else rights).also {
                            resolvedResources[identifier] = it
                        }
                    }
                } catch (_: Exception) {
                    null
                }
            }
        }
    }

    private fun toSearchResult(query: String, tracks: List<Track>, total: Int): SearchResult {
        val artists = tracks.filter { it.artist.isNotBlank() && it.artist != "Unknown creator" }
            .distinctBy { it.artist.lowercase() }
            .map { track -> Artist(track.artistId, track.artist, bio = "Creator name supplied by Internet Archive; no verified biography was provided.", genre = track.genre) }
        val albums = tracks.filter { it.album.isNotBlank() }
            .distinctBy { it.album.lowercase() }
            .map { track -> Album(track.albumId, track.album, track.artist, track.artistId, track.artworkUrl, genre = track.genre) }
        return SearchResult(query = query, tracks = tracks, artists = artists, albums = albums, totalCount = maxOf(total, tracks.size))
    }

    private fun valueAsText(value: Any?): String = when (value) {
        null, JSONObject.NULL -> ""
        is JSONArray -> (0 until value.length()).mapNotNull { value.optString(it).takeIf { text -> text.isNotBlank() } }.joinToString(", ")
        else -> value.toString().trim()
    }

    private fun encodeQuery(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.name())
    private fun encodePathSegment(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.name()).replace("+", "%20")
    private fun decodePathSegment(value: String): String = runCatching { URLDecoder.decode(value, StandardCharsets.UTF_8.name()) }.getOrDefault(value)
}
