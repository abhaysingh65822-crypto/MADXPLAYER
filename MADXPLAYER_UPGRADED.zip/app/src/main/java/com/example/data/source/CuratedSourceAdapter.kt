package com.example.data.source

import com.example.data.model.*

/**
 * Compatibility adapter retained so existing dependency wiring does not break.
 * It intentionally returns no catalog items. Fictional artists and demo audio are not
 * presented as real music in production builds.
 */
class CuratedSourceAdapter : MusicSourceAdapter {
    override val providerName: String = "MADXPLAYER (no bundled catalog)"
    override val isAvailable: Boolean = false

    override suspend fun search(query: String, category: SearchCategory, page: Int, limit: Int): Result<SearchResult> =
        Result.success(SearchResult(query = query))

    override suspend fun getTrendingTracks(genre: String?, limit: Int): Result<List<Track>> = Result.success(emptyList())
    override suspend fun getFeaturedArtists(limit: Int): Result<List<Artist>> = Result.success(emptyList())
    override suspend fun getFeaturedAlbums(limit: Int): Result<List<Album>> = Result.success(emptyList())

    override suspend fun getArtistDetail(artistId: String, artistName: String): Result<ArtistDetail> =
        Result.failure(NoSuchElementException("No bundled artist catalog is available."))

    override suspend fun getAlbumDetail(albumId: String): Result<AlbumDetail> =
        Result.failure(NoSuchElementException("No bundled album catalog is available."))
}
