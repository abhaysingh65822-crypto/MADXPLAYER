package com.example.data.model

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val durationMs: Long = 0L,
    val mediaUri: String, // Stream URL or local content URI / file path
    val artworkUrl: String = "",
    val genre: String = "All",
    val isLocal: Boolean = false,
    val isDownloaded: Boolean = false,
    val localFilePath: String? = null,
    val lyrics: String? = null, // Raw lyrics or LRC format
    val artistId: String = "",
    val albumId: String = "",
    val source: String = "Online", // e.g. "Internet Archive", "Jamendo", "Local Device"
    /** Separate, provider-authorized direct download URL. Never assume a stream URL is downloadable. */
    val downloadUri: String? = null,
    val downloadAllowed: Boolean = false
)

data class Artist(
    val id: String,
    val name: String,
    val bio: String = "",
    val imageUrl: String = "",
    val trackCount: Int = 0,
    val albumCount: Int = 0,
    val genre: String = ""
)

data class Album(
    val id: String,
    val title: String,
    val artist: String,
    val artistId: String = "",
    val artworkUrl: String = "",
    val releaseYear: String = "",
    val trackCount: Int = 0,
    val genre: String = ""
)

data class ArtistDetail(
    val artist: Artist,
    val topTracks: List<Track>,
    val albums: List<Album>
)

data class AlbumDetail(
    val album: Album,
    val tracks: List<Track>
)

enum class SearchCategory {
    ALL, TRACKS, ARTISTS, ALBUMS, LOCAL
}

data class SearchResult(
    val query: String,
    val tracks: List<Track> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val albums: List<Album> = emptyList(),
    val totalCount: Int = 0
)

data class SyncedLyric(
    val timeMs: Long,
    val text: String
)

data class Playlist(
    val id: String,
    val name: String,
    val description: String = "",
    val artworkUrl: String = "",
    val trackCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

data class EqualizerPreset(
    val name: String,
    val bandLevels: List<Int>, // 5 band values in decibels (-10 to +10)
    val bassBoost: Int // 0 to 1000
)
