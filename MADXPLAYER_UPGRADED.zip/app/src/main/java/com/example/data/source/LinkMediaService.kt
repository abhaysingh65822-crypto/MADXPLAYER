package com.example.data.source

import android.content.Context
import android.net.Uri
import android.os.Environment
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import dev.ffmpegkit_maintained.ytdlp.YtDlp
import dev.ffmpegkit_maintained.ytdlp.YtDlpRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

/**
 * Android-native yt-dlp link handling.
 *
 * Important: Audio.com is deliberately routed to its official player. Its terms restrict
 * automated scraping/extraction, so this service must not use yt-dlp against audio.com URLs.
 * Downloading arbitrary third-party media is only exposed after the user confirms they have
 * permission and the source allows that use.
 */
object LinkMediaService {
    private val initLock = Any()
    @Volatile private var initialized = false

    data class DownloadedAudio(val file: File, val title: String)

    fun initialize(context: Context) {
        if (initialized) return
        synchronized(initLock) {
            if (initialized) return
            YtDlp.init(context.applicationContext)
            initialized = true
        }
    }

    fun isAudioComUrl(rawUrl: String): Boolean {
        val host = runCatching { Uri.parse(rawUrl).host?.lowercase(Locale.ROOT) }.getOrNull() ?: return false
        return host == "audio.com" || host.endsWith(".audio.com")
    }

    fun isDirectAudioUrl(rawUrl: String): Boolean {
        val uri = runCatching { Uri.parse(rawUrl) }.getOrNull() ?: return false
        if (uri.scheme !in setOf("http", "https")) return false
        val path = uri.path?.lowercase(Locale.ROOT).orEmpty()
        return listOf(".mp3", ".m4a", ".m4b", ".aac", ".ogg", ".oga", ".opus", ".flac", ".wav", ".aif", ".aiff", ".wma", ".alac", ".3gp", ".mp4", ".mka", ".mkv", ".webm", ".m3u8", ".mpd")
            .any(path::endsWith)
    }

    /** Resolve a supported source page to a stream URL; direct audio/HLS URLs need no extraction. */
    suspend fun resolveStreamUrl(context: Context, rawUrl: String): String = withContext(Dispatchers.IO) {
        val url = validateHttpUrl(rawUrl)
        require(!isAudioComUrl(url)) {
            "Audio.com links must use the official Audio.com player. Automated extraction is disabled for this site."
        }
        if (isDirectAudioUrl(url)) return@withContext url
        initialize(context)

        val request = YtDlpRequest(url)
            .addOption("--no-playlist")
            .addOption("--no-warnings")
            .addOption("-f", "bestaudio/best")
            .addOption("-g")
        val response = YtDlp.execute(request, null)
        if (!response.isSuccess) {
            val details = response.errorOutput.orEmpty().lineSequence()
                .map(String::trim).filter(String::isNotBlank).lastOrNull()
            throw IllegalStateException(details ?: "No playable stream was returned by this source.")
        }
        response.output.orEmpty().lineSequence().map(String::trim)
            .firstOrNull { it.startsWith("https://") || it.startsWith("http://") }
            ?: throw IllegalStateException("The source did not return a direct playable stream URL.")
    }

    /** Download an audio-only rendition for links the user is authorized to download. */
    suspend fun downloadAudio(context: Context, rawUrl: String, preferredTitle: String): DownloadedAudio =
        withContext(Dispatchers.IO) {
            val url = validateHttpUrl(rawUrl)
            require(!isAudioComUrl(url)) {
                "Use Audio.com's own download control. It is available only when the uploader enables downloads."
            }
            initialize(context)

            val baseDir = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: context.filesDir
            val outputDir = File(baseDir, "MADXPLAYER").apply {
                if (!exists() && !mkdirs()) throw IllegalStateException("Could not create the MADXPLAYER downloads folder.")
            }
            val workDir = File(outputDir, ".extract-${System.currentTimeMillis()}").apply {
                if (!mkdirs()) throw IllegalStateException("Could not create a temporary extraction folder.")
            }
            try {
                val outputTemplate = File(workDir, "%(title).120s [%(id)s].%(ext)s").absolutePath
                val request = YtDlpRequest(url)
                    .setOutputTemplate(outputTemplate)
                    .addOption("--no-playlist")
                    .addOption("--no-warnings")
                    .addOption("-f", "bestaudio/best")
                val response = YtDlp.execute(request, null)
                if (!response.isSuccess) {
                    val details = response.errorOutput.orEmpty().lineSequence()
                        .map(String::trim).filter(String::isNotBlank).lastOrNull()
                    throw IllegalStateException(details ?: "Download failed. This URL may be unsupported or disallowed by the source.")
                }
                val audioExtensions = setOf("mp3", "m4a", "m4b", "aac", "ogg", "oga", "opus", "flac", "wav", "aif", "aiff", "wma", "alac", "3gp", "mka", "mkv", "webm", "mp4")
                val downloadedFile = workDir.listFiles().orEmpty()
                    .filter { it.isFile && !it.name.endsWith(".part") && it.extension.lowercase(Locale.ROOT) in audioExtensions }
                    .maxByOrNull(File::lastModified)
                    ?: throw IllegalStateException("yt-dlp reported success but no audio file was created.")

                val safeTitle = preferredTitle.trim().ifBlank { downloadedFile.nameWithoutExtension }
                    .replace(Regex("[^A-Za-z0-9 _.-]"), "_")
                    .trim().take(70).ifBlank { "MADXPLAYER_audio" }
                val stamp = System.currentTimeMillis()
                val converted = File(outputDir, "$safeTitle-$stamp.mp3")

                if (downloadedFile.extension.equals("mp3", true)) {
                    if (!downloadedFile.renameTo(converted)) downloadedFile.copyTo(converted, overwrite = true)
                } else {
                    val command = "-y -i ${shellQuote(downloadedFile.absolutePath)} -vn -codec:a libmp3lame -q:a 2 ${shellQuote(converted.absolutePath)}"
                    val session = FFmpegKit.execute(command)
                    if (ReturnCode.isSuccess(session.returnCode) && converted.isFile && converted.length() > 0L) {
                        downloadedFile.delete()
                    } else {
                        // Conversion is an enhancement, not a reason to throw away an otherwise valid file.
                        val originalExt = downloadedFile.extension.ifBlank { "audio" }
                        val originalTarget = File(outputDir, "$safeTitle-$stamp.$originalExt")
                        if (!downloadedFile.renameTo(originalTarget)) downloadedFile.copyTo(originalTarget, overwrite = true)
                        return@withContext DownloadedAudio(originalTarget, preferredTitle.ifBlank { originalTarget.nameWithoutExtension })
                    }
                }
                if (!converted.isFile || converted.length() <= 0L) {
                    throw IllegalStateException("The downloaded audio file is empty.")
                }
                DownloadedAudio(converted, preferredTitle.ifBlank { converted.nameWithoutExtension })
            } finally {
                workDir.deleteRecursively()
            }
        }

    private fun validateHttpUrl(rawUrl: String): String {
        val cleaned = rawUrl.trim()
        val parsed = Uri.parse(cleaned)
        require(parsed.scheme in setOf("http", "https") && !parsed.host.isNullOrBlank()) {
            "Enter a valid http:// or https:// link."
        }
        return cleaned
    }

    private fun shellQuote(value: String): String = "'${value.replace("'", "'\\''")}'"
}
