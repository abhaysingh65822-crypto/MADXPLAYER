package com.example.data.repository

import com.example.data.model.Track

/**
 * Genre navigation only. Production music results must come from a real provider or the
 * user's device library; never seed the app with invented tracks or demonstration audio.
 */
object CuratedMusicCatalog {
    fun getInitialTracks(): List<Track> = emptyList()

    fun getGenres(): List<String> = listOf(
        "All", "Hindi", "Bollywood", "Punjabi", "Bhojpuri", "Haryanvi",
        "Tamil", "Telugu", "Bengali", "Lo-fi", "English", "Indie", "Instrumental"
    )
}
