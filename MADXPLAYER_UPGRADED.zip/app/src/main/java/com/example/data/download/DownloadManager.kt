package com.example.data.download

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Environment
import com.example.data.local.MusicDao
import com.example.data.local.TrackEntity
import com.example.data.model.Track
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

enum class DownloadStatus {
    IDLE, QUEUED, DOWNLOADING, COMPLETED, FAILED, CANCELLED
}

data class DownloadProgress(
    val trackId: String,
    val progress: Float = 0f,
    val bytesDownloaded: Long = 0L,
    val totalBytes: Long = 0L,
    val status: DownloadStatus = DownloadStatus.IDLE,
    val errorMessage: String? = null
)


class DownloadManager(
    private val context: Context,
    private val musicDao: MusicDao
) {
    private val coroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<String, Job>()

    private val _downloadProgressMap = MutableStateFlow<Map<String, DownloadProgress>>(emptyMap())
    val downloadProgressMap: StateFlow<Map<String, DownloadProgress>> = _downloadProgressMap.asStateFlow()

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    var wifiOnly: Boolean = false

    fun isWifiConnected(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    fun downloadTrack(track: Track) {
        if (track.isDownloaded || activeJobs.containsKey(track.id)) return
        if (!isDownloadAllowed(track)) {
            updateProgress(track.id, DownloadProgress(
                track.id,
                status = DownloadStatus.FAILED,
                errorMessage = "This source has not declared an eligible downloadable audio file."
            ))
            return
        }
        if (wifiOnly && !isWifiConnected()) {
            updateProgress(track.id, DownloadProgress(track.id, status = DownloadStatus.FAILED, errorMessage = "Wi-Fi connection required"))
            return
        }

        updateProgress(track.id, DownloadProgress(track.id, status = DownloadStatus.QUEUED))
        // Lazy start avoids a race where a fast job finishes before it is inserted into activeJobs.
        val job = coroutineScope.launch(start = CoroutineStart.LAZY) {
            val downloadDir = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: context.filesDir
            var partialFile: File? = null
            var finishedFile: File? = null
            var completed = false
            try {
                if (!downloadDir.exists() && !downloadDir.mkdirs()) {
                    throw IllegalStateException("Could not create the downloads folder")
                }
                updateProgress(track.id, DownloadProgress(track.id, status = DownloadStatus.DOWNLOADING, progress = 0f))
                val authorizedDownloadUrl = track.downloadUri?.takeIf { it.isNotBlank() }
                    ?: throw IllegalStateException("This track does not have a provider-authorized download URL")
                val request = Request.Builder()
                    .url(authorizedDownloadUrl)
                    .header("User-Agent", "MADXPLAYER/1.1 Android audio download")
                    .header("Accept", "audio/*,application/octet-stream;q=0.9,*/*;q=0.1")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}")
                    val body = response.body ?: throw IllegalStateException("Empty download response")
                    val mime = body.contentType()?.toString()?.lowercase(Locale.ROOT).orEmpty()
                    val extFromUrl = authorizedDownloadUrl.substringBefore('?').substringBefore('#')
                        .substringAfterLast('.', "").lowercase(Locale.ROOT).takeIf { it in setOf("mp3", "m4a", "aac", "ogg", "oga", "flac", "wav") }
                    val extension = when {
                        mime.contains("mpeg") || mime.contains("mp3") -> "mp3"
                        mime.contains("ogg") -> "ogg"
                        mime.contains("flac") -> "flac"
                        mime.contains("wav") || mime.contains("wave") -> "wav"
                        mime.contains("mp4") || mime.contains("aac") -> if (extFromUrl == "aac") "aac" else "m4a"
                        mime.startsWith("audio/") -> extFromUrl ?: throw IllegalStateException("Unsupported audio type: $mime")
                        mime.contains("octet-stream") && extFromUrl != null -> extFromUrl
                        else -> throw IllegalStateException("The server did not return a recognized audio file ($mime)")
                    }
                    val totalLength = body.contentLength()
                    val safeId = track.id.replace(Regex("[^a-zA-Z0-9_]"), "_")
                    partialFile = File(downloadDir, "madx_${safeId}.$extension.part")
                    finishedFile = File(downloadDir, "madx_${safeId}.$extension")
                    var downloaded = 0L
                    val inputStream: InputStream = body.byteStream()
                    FileOutputStream(partialFile!!).use { output ->
                        inputStream.use { input ->
                            val buffer = ByteArray(16 * 1024)
                            while (true) {
                                currentCoroutineContext().ensureActive()
                                val bytesRead = input.read(buffer)
                                if (bytesRead == -1) break
                                output.write(buffer, 0, bytesRead)
                                downloaded += bytesRead
                                val pct = if (totalLength > 0L) (downloaded.toFloat() / totalLength.toFloat()).coerceIn(0f, 1f) else 0f
                                updateProgress(track.id, DownloadProgress(
                                    trackId = track.id,
                                    progress = pct,
                                    bytesDownloaded = downloaded,
                                    totalBytes = totalLength.coerceAtLeast(0L),
                                    status = DownloadStatus.DOWNLOADING
                                ))
                            }
                            output.flush()
                        }
                    }
                    if (downloaded <= 0L) throw IllegalStateException("The downloaded file was empty")
                    if (totalLength > 0L && downloaded != totalLength) {
                        throw IllegalStateException("Incomplete file: received $downloaded of $totalLength bytes")
                    }
                    if (finishedFile!!.exists() && !finishedFile!!.delete()) throw IllegalStateException("Could not replace existing download")
                    if (!partialFile!!.renameTo(finishedFile!!)) throw IllegalStateException("Could not finalize downloaded file")
                }

                val savedFile = finishedFile ?: throw IllegalStateException("Download file was not created")
                val updatedEntity = TrackEntity(
                    id = track.id,
                    title = track.title,
                    artist = track.artist,
                    album = track.album,
                    durationMs = track.durationMs,
                    // Keep the original stream URI so removing the offline copy restores streaming.
                    mediaUri = track.mediaUri,
                    artworkUrl = track.artworkUrl,
                    genre = track.genre,
                    isLocal = false,
                    isDownloaded = true,
                    localFilePath = savedFile.absolutePath,
                    lyrics = track.lyrics,
                    artistId = track.artistId,
                    albumId = track.albumId,
                    source = track.source,
                    downloadUri = track.downloadUri,
                    downloadAllowed = track.downloadAllowed
                )
                musicDao.insertTrack(updatedEntity)
                completed = true
                updateProgress(track.id, DownloadProgress(track.id, progress = 1f, bytesDownloaded = savedFile.length(), totalBytes = savedFile.length(), status = DownloadStatus.COMPLETED))
            } catch (e: CancellationException) {
                partialFile?.delete()
                finishedFile?.takeIf { !completed }?.delete()
                updateProgress(track.id, DownloadProgress(track.id, status = DownloadStatus.CANCELLED))
                throw e
            } catch (e: Exception) {
                partialFile?.delete()
                finishedFile?.takeIf { !completed }?.delete()
                updateProgress(track.id, DownloadProgress(track.id, status = DownloadStatus.FAILED, errorMessage = e.localizedMessage ?: "Download failed"))
            } finally {
                // A cancelled job may finish after a replacement download has started for the
                // same track. Remove only this job's mapping, never the newer job's entry.
                val finishedJob = currentCoroutineContext()[Job]
                if (finishedJob != null) activeJobs.remove(track.id, finishedJob)
            }
        }
        activeJobs[track.id] = job
        job.start()
    }

    private fun isDownloadAllowed(track: Track): Boolean = MusicDownloadPolicy.canDownload(track)

    fun cancelDownload(trackId: String) {
        // Keep the job registered until its finally block completes file cleanup. This prevents a
        // rapid retry from writing to the same partial-file path while cancellation is still running.
        activeJobs[trackId]?.cancel()
        updateProgress(trackId, DownloadProgress(trackId, status = DownloadStatus.CANCELLED))
    }

    suspend fun deleteDownloadedTrack(track: Track) = withContext(Dispatchers.IO) {
        track.localFilePath?.let { path ->
            val file = File(path)
            if (file.exists()) file.delete()
        }
        val entity = TrackEntity(
            id = track.id,
            title = track.title,
            artist = track.artist,
            album = track.album,
            durationMs = track.durationMs,
            mediaUri = track.mediaUri,
            artworkUrl = track.artworkUrl,
            genre = track.genre,
            isLocal = track.isLocal,
            isDownloaded = false,
            localFilePath = null,
            lyrics = track.lyrics,
            artistId = track.artistId,
            albumId = track.albumId,
            source = track.source,
            downloadUri = track.downloadUri,
            downloadAllowed = track.downloadAllowed
        )
        musicDao.insertTrack(entity)
        _downloadProgressMap.value = _downloadProgressMap.value - track.id
    }

    private fun updateProgress(trackId: String, progress: DownloadProgress) {
        val current = _downloadProgressMap.value.toMutableMap()
        current[trackId] = progress
        _downloadProgressMap.value = current
    }
}
