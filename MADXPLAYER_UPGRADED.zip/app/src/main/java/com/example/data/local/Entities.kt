package com.example.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.Track

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val mediaUri: String,
    val artworkUrl: String,
    val genre: String,
    val isLocal: Boolean,
    val isDownloaded: Boolean,
    val localFilePath: String?,
    val lyrics: String?,
    val addedAt: Long = System.currentTimeMillis(),
    val artistId: String = "",
    val albumId: String = "",
    val source: String = "Online",
    val downloadUri: String? = null,
    @ColumnInfo(defaultValue = "0") val downloadAllowed: Boolean = false
) {
    fun toDomain(): Track = Track(
        id = id,
        title = title,
        artist = artist,
        album = album,
        durationMs = durationMs,
        // Keep mediaUri as the original stream/content URI. PlaybackController chooses localFilePath
        // when an offline copy exists, so deleting that copy does not destroy the source URI.
        mediaUri = mediaUri,
        artworkUrl = artworkUrl,
        genre = genre,
        isLocal = isLocal,
        isDownloaded = isDownloaded,
        localFilePath = localFilePath,
        lyrics = lyrics,
        artistId = artistId,
        albumId = albumId,
        source = source,
        downloadUri = downloadUri,
        downloadAllowed = downloadAllowed
    )

    companion object {
        fun fromDomain(track: Track): TrackEntity = TrackEntity(
            id = track.id,
            title = track.title,
            artist = track.artist,
            album = track.album,
            durationMs = track.durationMs,
            mediaUri = track.mediaUri,
            artworkUrl = track.artworkUrl,
            genre = track.genre,
            isLocal = track.isLocal,
            isDownloaded = track.isDownloaded,
            localFilePath = track.localFilePath,
            lyrics = track.lyrics,
            artistId = track.artistId,
            albumId = track.albumId,
            source = track.source,
            downloadUri = track.downloadUri,
            downloadAllowed = track.downloadAllowed
        )
    }
}

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val artworkUrl: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_tracks", primaryKeys = ["playlistId", "trackId"])
data class PlaylistTrackCrossRef(
    val playlistId: String,
    val trackId: String,
    val sortOrder: Int = 0
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val trackId: String,
    val favoritedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playback_history")
data class PlaybackHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val trackId: String,
    val playedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "recent_searches")
data class RecentSearchEntity(
    @PrimaryKey val query: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "artists")
data class ArtistEntity(
    @PrimaryKey val id: String,
    val name: String,
    val bio: String = "",
    val imageUrl: String = "",
    val trackCount: Int = 0,
    val albumCount: Int = 0,
    val genre: String = "",
    val cachedAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): Artist = Artist(
        id = id,
        name = name,
        bio = bio,
        imageUrl = imageUrl,
        trackCount = trackCount,
        albumCount = albumCount,
        genre = genre
    )

    companion object {
        fun fromDomain(artist: Artist): ArtistEntity = ArtistEntity(
            id = artist.id,
            name = artist.name,
            bio = artist.bio,
            imageUrl = artist.imageUrl,
            trackCount = artist.trackCount,
            albumCount = artist.albumCount,
            genre = artist.genre
        )
    }
}

@Entity(tableName = "albums")
data class AlbumEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val artistId: String = "",
    val artworkUrl: String = "",
    val releaseYear: String = "",
    val trackCount: Int = 0,
    val genre: String = "",
    val cachedAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): Album = Album(
        id = id,
        title = title,
        artist = artist,
        artistId = artistId,
        artworkUrl = artworkUrl,
        releaseYear = releaseYear,
        trackCount = trackCount,
        genre = genre
    )

    companion object {
        fun fromDomain(album: Album): AlbumEntity = AlbumEntity(
            id = album.id,
            title = album.title,
            artist = album.artist,
            artistId = album.artistId,
            artworkUrl = album.artworkUrl,
            releaseYear = album.releaseYear,
            trackCount = album.trackCount,
            genre = album.genre
        )
    }
}
