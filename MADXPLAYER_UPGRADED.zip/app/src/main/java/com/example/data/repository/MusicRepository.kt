package com.example.data.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.example.data.ai.GeminiMusicService
import com.example.data.download.DownloadManager
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.source.CompositeMusicProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class MusicRepository(
    private val context: Context,
    private val musicDao: MusicDao,
    val downloadManager: DownloadManager,
    val geminiService: GeminiMusicService,
    val compositeProvider: CompositeMusicProvider = CompositeMusicProvider()
) {
    private val _localDeviceTracks = MutableStateFlow<List<Track>>(emptyList())
    val localDeviceTracks: StateFlow<List<Track>> = _localDeviceTracks.asStateFlow()

    // Combined local/offline library. Online discovery is loaded explicitly by the home/search UI.
    val allTracks: Flow<List<Track>> = combine(
        musicDao.getAllTracks(),
        _localDeviceTracks
    ) { dbEntities, localTracks ->
        val dbTracks = dbEntities.map { it.toDomain() }
        (dbTracks + localTracks).distinctBy { it.id }
    }

    val downloadedTracks: Flow<List<Track>> = musicDao.getDownloadedTracks().map { entities ->
        entities.map { it.toDomain() }
    }

    val favoriteTrackIds: Flow<Set<String>> = musicDao.getFavoriteTrackIds().map { it.toSet() }

    val playlists: Flow<List<Playlist>> = musicDao.getAllPlaylists().map { entities ->
        entities.map { entity ->
            Playlist(
                id = entity.id,
                name = entity.name,
                description = entity.description,
                artworkUrl = entity.artworkUrl,
                createdAt = entity.createdAt
            )
        }
    }

    val recentlyPlayedTracks: Flow<List<Track>> = musicDao.getRecentlyPlayedTracks().map { entities ->
        entities.map { it.toDomain() }
    }

    val recentSearches: Flow<List<String>> = musicDao.getRecentSearches().map { entities ->
        entities.map { it.query }
    }

    suspend fun initializeCatalog() = withContext(Dispatchers.IO) {
        // Older versions inserted fictional names paired with generic demo audio. Remove only those
        // known seed rows; keep user downloads, playlists, favorites, and local music untouched.
        musicDao.deleteOldDemoTracks()
        musicDao.deleteOldDemoFavorites()
        musicDao.deleteOldDemoHistory()
        musicDao.deleteOldDemoPlaylistReferences()
        musicDao.deleteOldDemoArtists()
        musicDao.deleteOldDemoAlbums()
        scanLocalAudio()
    }

    // Live search across online providers and local device files
    suspend fun liveSearch(
        query: String,
        category: SearchCategory = SearchCategory.ALL
    ): SearchResult = withContext(Dispatchers.IO) {
        val cleanQuery = query.trim()
        if (cleanQuery.isBlank()) {
            return@withContext SearchResult(cleanQuery)
        }

        // Save to recent search history
        musicDao.insertRecentSearch(RecentSearchEntity(query = cleanQuery))

        val wantsTracks = category in setOf(SearchCategory.ALL, SearchCategory.TRACKS, SearchCategory.LOCAL)
        val wantsArtists = category in setOf(SearchCategory.ALL, SearchCategory.ARTISTS)
        val wantsAlbums = category in setOf(SearchCategory.ALL, SearchCategory.ALBUMS)

        val localMatches = if (wantsTracks) {
            musicDao.searchLocalTracks(cleanQuery).map { it.toDomain() }
                .filter { category != SearchCategory.LOCAL || it.isLocal || it.isDownloaded }
        } else emptyList()
        val deviceMatches = if (wantsTracks) _localDeviceTracks.value.filter {
            it.title.contains(cleanQuery, ignoreCase = true) ||
                it.artist.contains(cleanQuery, ignoreCase = true) ||
                it.album.contains(cleanQuery, ignoreCase = true)
        } else emptyList()

        // The Local tab is intentionally device-only; it should never make a network request.
        val onlineResult = if (category == SearchCategory.LOCAL) SearchResult(cleanQuery)
            else compositeProvider.searchAll(cleanQuery, category)

        val mergedTracks = if (wantsTracks) (localMatches + deviceMatches + onlineResult.tracks)
            .distinctBy { "${it.title.lowercase().trim()}_${it.artist.lowercase().trim()}" } else emptyList()
        val artists = if (wantsArtists) onlineResult.artists else emptyList()
        val albums = if (wantsAlbums) onlineResult.albums else emptyList()

        // Cache only real provider metadata for fast detail retrieval.
        if (artists.isNotEmpty()) musicDao.insertArtists(artists.map { ArtistEntity.fromDomain(it) })
        if (albums.isNotEmpty()) musicDao.insertAlbums(albums.map { AlbumEntity.fromDomain(it) })

        SearchResult(
            query = cleanQuery,
            tracks = mergedTracks,
            artists = artists,
            albums = albums,
            totalCount = mergedTracks.size + artists.size + albums.size
        )
    }

    /** Add an explicitly user-authorized yt-dlp download to the offline library. */
    suspend fun saveLinkDownload(track: Track) = withContext(Dispatchers.IO) {
        require(track.isDownloaded && !track.localFilePath.isNullOrBlank()) {
            "A completed local file is required before saving a download."
        }
        musicDao.insertTrack(com.example.data.local.TrackEntity.fromDomain(track))
    }

    suspend fun deleteRecentSearch(query: String) = withContext(Dispatchers.IO) {
        musicDao.deleteRecentSearch(query)
    }

    suspend fun clearRecentSearches() = withContext(Dispatchers.IO) {
        musicDao.clearRecentSearches()
    }

    suspend fun getFeaturedArtists(): List<Artist> = withContext(Dispatchers.IO) {
        compositeProvider.getFeaturedArtists()
    }

    suspend fun getFeaturedAlbums(): List<Album> = withContext(Dispatchers.IO) {
        compositeProvider.getFeaturedAlbums()
    }

    suspend fun getTrendingTracks(genre: String? = null, limit: Int = 20): List<Track> = withContext(Dispatchers.IO) {
        compositeProvider.getTrendingTracks(genre, limit)
    }

    suspend fun getArtistDetail(artistId: String, artistName: String): ArtistDetail = withContext(Dispatchers.IO) {
        val cached = musicDao.getArtistByIdOrName(artistId, artistName)
        val localSongs = musicDao.getTracksByArtist(artistId, artistName).map { it.toDomain() }

        val detail = compositeProvider.getArtistDetail(artistId, artistName)
        val mergedSongs = (localSongs + detail.topTracks).distinctBy { it.id }

        ArtistDetail(
            artist = cached?.toDomain() ?: detail.artist,
            topTracks = mergedSongs,
            albums = detail.albums
        )
    }

    suspend fun getAlbumDetail(albumId: String, albumTitle: String = ""): AlbumDetail = withContext(Dispatchers.IO) {
        val cached = musicDao.getAlbumById(albumId)
        val localSongs = musicDao.getTracksByAlbum(albumId, albumTitle).map { it.toDomain() }

        val detail = compositeProvider.getAlbumDetail(albumId, albumTitle)
        val mergedTracks = (localSongs + detail.tracks).distinctBy { it.id }

        AlbumDetail(
            album = cached?.toDomain() ?: detail.album,
            tracks = mergedTracks
        )
    }

    suspend fun scanLocalAudio() = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<Track>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 15000"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        try {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val title = cursor.getString(titleCol) ?: "Unknown Track"
                    val artist = cursor.getString(artistCol) ?: "Unknown Artist"
                    val album = cursor.getString(albumCol) ?: "Unknown Album"
                    val duration = cursor.getLong(durationCol)
                    val albumId = cursor.getLong(albumIdCol)

                    val contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    val artworkUri = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)

                    tracks.add(
                        Track(
                            id = "local_$id",
                            title = title,
                            artist = if (artist == "<unknown>") "Local Artist" else artist,
                            album = album,
                            durationMs = duration,
                            mediaUri = contentUri.toString(),
                            artworkUrl = artworkUri.toString(),
                            genre = "Local Audio",
                            isLocal = true,
                            isDownloaded = false,
                            source = "Local Device"
                        )
                    )
                }
            }
            _localDeviceTracks.value = tracks
        } catch (_: Exception) {}
    }

    suspend fun toggleFavorite(track: Track) = withContext(Dispatchers.IO) {
        musicDao.insertTrack(TrackEntity.fromDomain(track))
        val isFav = musicDao.isFavorite(track.id)
        if (isFav) {
            musicDao.removeFavorite(track.id)
        } else {
            musicDao.addFavorite(FavoriteEntity(track.id))
        }
    }

    suspend fun recordPlayed(track: Track) = withContext(Dispatchers.IO) {
        musicDao.insertTrack(TrackEntity.fromDomain(track))
        musicDao.recordHistory(PlaybackHistoryEntity(trackId = track.id))
    }

    suspend fun createPlaylist(name: String, description: String = ""): String = withContext(Dispatchers.IO) {
        val id = "pl_${System.currentTimeMillis()}"
        musicDao.insertPlaylist(
            PlaylistEntity(
                id = id,
                name = name,
                description = description,
                artworkUrl = ""
            )
        )
        id
    }

    suspend fun updatePlaylist(id: String, name: String, description: String) = withContext(Dispatchers.IO) {
        musicDao.updatePlaylist(id, name, description)
    }

    suspend fun deletePlaylist(playlistId: String) = withContext(Dispatchers.IO) {
        musicDao.deletePlaylist(playlistId)
    }

    suspend fun addTrackToPlaylist(playlistId: String, track: Track) = withContext(Dispatchers.IO) {
        musicDao.insertTrack(TrackEntity.fromDomain(track))
        musicDao.addTrackToPlaylist(PlaylistTrackCrossRef(playlistId = playlistId, trackId = track.id))
    }

    suspend fun removeTrackFromPlaylist(playlistId: String, trackId: String) = withContext(Dispatchers.IO) {
        musicDao.removeTrackFromPlaylist(playlistId, trackId)
    }

    suspend fun reorderPlaylist(playlistId: String, trackIdsInOrder: List<String>) = withContext(Dispatchers.IO) {
        musicDao.reorderPlaylistTracks(playlistId, trackIdsInOrder)
    }

    fun getTracksForPlaylist(playlistId: String): Flow<List<Track>> {
        return musicDao.getTracksForPlaylist(playlistId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun exportPlaylistToJson(playlistId: String): String = withContext(Dispatchers.IO) {
        val playlist = musicDao.getPlaylistById(playlistId) ?: throw IllegalArgumentException("Playlist not found")
        val tracks = musicDao.getTracksForPlaylist(playlistId).first()
        val json = JSONObject().apply {
            put("id", playlist.id)
            put("name", playlist.name)
            put("description", playlist.description)
            put("createdAt", playlist.createdAt)
            put("tracks", JSONArray().apply {
                tracks.forEach { t ->
                    put(JSONObject().apply {
                        put("id", t.id)
                        put("title", t.title)
                        put("artist", t.artist)
                        put("album", t.album)
                        put("mediaUri", t.mediaUri)
                        put("artworkUrl", t.artworkUrl)
                        put("durationMs", t.durationMs)
                        put("genre", t.genre)
                    })
                }
            })
        }
        json.toString(2)
    }

    suspend fun importPlaylistFromJson(jsonString: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val json = JSONObject(jsonString)
            val name = json.optString("name", "Imported Playlist")
            val desc = json.optString("description", "Imported into MADXPLAYER")
            val playlistId = createPlaylist(name, desc)

            val tracksArray = json.optJSONArray("tracks")
            if (tracksArray != null) {
                for (i in 0 until tracksArray.length()) {
                    val obj = tracksArray.getJSONObject(i)
                    val track = Track(
                        id = obj.optString("id", "imp_${System.currentTimeMillis()}_$i"),
                        title = obj.optString("title", "Imported Song"),
                        artist = obj.optString("artist", "Various"),
                        album = obj.optString("album", ""),
                        durationMs = obj.optLong("durationMs", 0L),
                        mediaUri = obj.optString("mediaUri"),
                        artworkUrl = obj.optString("artworkUrl"),
                        genre = obj.optString("genre", "All")
                    )
                    addTrackToPlaylist(playlistId, track)
                }
            }
            Result.success(playlistId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
