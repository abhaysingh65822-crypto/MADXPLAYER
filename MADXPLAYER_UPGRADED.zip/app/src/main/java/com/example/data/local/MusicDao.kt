package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MusicDao {
    @Query("SELECT * FROM tracks ORDER BY addedAt DESC")
    fun getAllTracks(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks WHERE id = :id")
    suspend fun getTrackById(id: String): TrackEntity?

    @Query("SELECT * FROM tracks WHERE isDownloaded = 1 ORDER BY addedAt DESC")
    fun getDownloadedTracks(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks WHERE artistId = :artistId OR artist LIKE '%' || :artistName || '%'")
    suspend fun getTracksByArtist(artistId: String, artistName: String): List<TrackEntity>

    @Query("SELECT * FROM tracks WHERE albumId = :albumId OR album LIKE '%' || :albumTitle || '%'")
    suspend fun getTracksByAlbum(albumId: String, albumTitle: String): List<TrackEntity>

    @Query("SELECT * FROM tracks WHERE title LIKE '%' || :query || '%' OR artist LIKE '%' || :query || '%' OR album LIKE '%' || :query || '%'")
    suspend fun searchLocalTracks(query: String): List<TrackEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrack(track: TrackEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTracks(tracks: List<TrackEntity>)

    @Update
    suspend fun updateTrack(track: TrackEntity)

    @Query("DELETE FROM tracks WHERE id = :id")
    suspend fun deleteTrackById(id: String)

    // Remove seeded demonstration rows from older MADXPLAYER builds without touching user files.
    @Query("DELETE FROM tracks WHERE id GLOB 'curated_*'")
    suspend fun deleteOldDemoTracks()

    @Query("DELETE FROM favorites WHERE trackId GLOB 'curated_*'")
    suspend fun deleteOldDemoFavorites()

    @Query("DELETE FROM playback_history WHERE trackId GLOB 'curated_*'")
    suspend fun deleteOldDemoHistory()

    @Query("DELETE FROM playlist_tracks WHERE trackId GLOB 'curated_*'")
    suspend fun deleteOldDemoPlaylistReferences()

    @Query("DELETE FROM artists WHERE id GLOB 'art_*'")
    suspend fun deleteOldDemoArtists()

    @Query("DELETE FROM albums WHERE id GLOB 'alb_*'")
    suspend fun deleteOldDemoAlbums()

    // Playlists
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun getAllPlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE id = :id")
    suspend fun getPlaylistById(id: String): PlaylistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity)

    @Query("UPDATE playlists SET name = :name, description = :description WHERE id = :id")
    suspend fun updatePlaylist(id: String, name: String, description: String)

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun deletePlaylist(id: String)

    @Query("""
        SELECT t.* FROM tracks t 
        INNER JOIN playlist_tracks pt ON t.id = pt.trackId 
        WHERE pt.playlistId = :playlistId 
        ORDER BY pt.sortOrder ASC
    """)
    fun getTracksForPlaylist(playlistId: String): Flow<List<TrackEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addTrackToPlaylist(crossRef: PlaylistTrackCrossRef)

    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId AND trackId = :trackId")
    suspend fun removeTrackFromPlaylist(playlistId: String, trackId: String)

    @Transaction
    suspend fun reorderPlaylistTracks(playlistId: String, trackIdsInOrder: List<String>) {
        trackIdsInOrder.forEachIndexed { index, trackId ->
            addTrackToPlaylist(PlaylistTrackCrossRef(playlistId = playlistId, trackId = trackId, sortOrder = index))
        }
    }

    // Favorites
    @Query("SELECT trackId FROM favorites")
    fun getFavoriteTrackIds(): Flow<List<String>>

    @Query("""
        SELECT t.* FROM tracks t 
        INNER JOIN favorites f ON t.id = f.trackId 
        ORDER BY f.favoritedAt DESC
    """)
    fun getFavoriteTracks(): Flow<List<TrackEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE trackId = :trackId")
    suspend fun removeFavorite(trackId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE trackId = :trackId)")
    suspend fun isFavorite(trackId: String): Boolean

    // Playback History
    @Insert
    suspend fun recordHistory(history: PlaybackHistoryEntity)

    @Query("""
        SELECT t.* FROM tracks t
        INNER JOIN playback_history h ON t.id = h.trackId
        ORDER BY h.playedAt DESC
        LIMIT 25
    """)
    fun getRecentlyPlayedTracks(): Flow<List<TrackEntity>>

    @Query("DELETE FROM playback_history")
    suspend fun clearHistory()

    // Recent Searches
    @Query("SELECT * FROM recent_searches ORDER BY timestamp DESC LIMIT 15")
    fun getRecentSearches(): Flow<List<RecentSearchEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecentSearch(search: RecentSearchEntity)

    @Query("DELETE FROM recent_searches WHERE `query` = :query")
    suspend fun deleteRecentSearch(query: String)

    @Query("DELETE FROM recent_searches")
    suspend fun clearRecentSearches()

    // Artists Cache
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArtists(artists: List<ArtistEntity>)

    @Query("SELECT * FROM artists ORDER BY trackCount DESC LIMIT 30")
    fun getAllArtists(): Flow<List<ArtistEntity>>

    @Query("SELECT * FROM artists WHERE id = :id OR name LIKE '%' || :name || '%' LIMIT 1")
    suspend fun getArtistByIdOrName(id: String, name: String): ArtistEntity?

    // Albums Cache
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlbums(albums: List<AlbumEntity>)

    @Query("SELECT * FROM albums ORDER BY releaseYear DESC LIMIT 30")
    fun getAllAlbums(): Flow<List<AlbumEntity>>

    @Query("SELECT * FROM albums WHERE id = :id LIMIT 1")
    suspend fun getAlbumById(id: String): AlbumEntity?
}
