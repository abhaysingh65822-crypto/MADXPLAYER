package com.example.data.source

import com.example.BuildConfig
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

/** Jamendo's documented API adapter. A real Client ID is required for online data. */
class JamendoSourceAdapter(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .build()
) : MusicSourceAdapter {

    override val providerName: String = "Jamendo Music"

    private val clientId: String by lazy {
        runCatching { BuildConfig.JAMENDO_CLIENT_ID.trim() }.getOrDefault("")
            .takeUnless { it.isBlank() || it.equals("MY_JAMENDO_CLIENT_ID", ignoreCase = true) }
            .orEmpty()
    }
    override val isAvailable: Boolean get() = clientId.isNotBlank()

    override suspend fun search(query: String, category: SearchCategory, page: Int, limit: Int): Result<SearchResult> =
        withContext(Dispatchers.IO) {
            if (!isAvailable) return@withContext Result.failure(IllegalStateException("Jamendo Client ID is not configured."))
            try {
                val clean = query.trim().take(120)
                val offset = ((page - 1).coerceAtLeast(0) * limit.coerceIn(1, 50))
                when (category) {
                    SearchCategory.ARTISTS -> Result.success(SearchResult(clean, artists = fetchArtists("namesearch=${enc(clean)}", limit), totalCount = limit))
                    SearchCategory.ALBUMS -> Result.success(SearchResult(clean, albums = fetchAlbums("namesearch=${enc(clean)}", limit), totalCount = limit))
                    SearchCategory.LOCAL -> Result.success(SearchResult(clean))
                    else -> {
                        val trackResults = fetchTrackResults("search=${enc(clean)}&offset=$offset", limit.coerceIn(1, 50))
                        val tracks = trackResults.mapNotNull(::toTrack)
                        val artists = tracks.filter { it.artist.isNotBlank() }.distinctBy { it.artistId }
                            .map { Artist(it.artistId, it.artist, imageUrl = "", genre = it.genre) }
                        val albums = tracks.filter { it.album.isNotBlank() }.distinctBy { it.albumId }
                            .map { Album(it.albumId, it.album, it.artist, it.artistId, it.artworkUrl, genre = it.genre) }
                        Result.success(SearchResult(clean, tracks, artists, albums, tracks.size))
                    }
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    override suspend fun getTrendingTracks(genre: String?, limit: Int): Result<List<Track>> = withContext(Dispatchers.IO) {
        if (!isAvailable) return@withContext Result.failure(IllegalStateException("Jamendo Client ID is not configured."))
        try {
            val tagParam = if (!genre.isNullOrBlank() && !genre.equals("All", true)) "&tags=${enc(genre)}" else ""
            val items = fetchTrackResults("order=popularity_month$tagParam", limit.coerceIn(1, 50))
            Result.success(items.mapNotNull(::toTrack))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getFeaturedArtists(limit: Int): Result<List<Artist>> = withContext(Dispatchers.IO) {
        if (!isAvailable) return@withContext Result.success(emptyList())
        try {
            Result.success(fetchArtists("order=popularity_month", limit.coerceIn(1, 50)))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getFeaturedAlbums(limit: Int): Result<List<Album>> = withContext(Dispatchers.IO) {
        if (!isAvailable) return@withContext Result.success(emptyList())
        try {
            Result.success(fetchAlbums("order=popularity_month", limit.coerceIn(1, 50)))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getArtistDetail(artistId: String, artistName: String): Result<ArtistDetail> = withContext(Dispatchers.IO) {
        if (!isAvailable) return@withContext Result.failure(IllegalStateException("Jamendo Client ID is not configured."))
        try {
            val cleanId = artistId.removePrefix("jam_art_")
            val artist = fetchArtists("id=${enc(cleanId)}", 1).firstOrNull()
                ?: Artist(artistId, artistName)
            val tracks = fetchTrackResults("artist_id=${enc(cleanId)}", 50).mapNotNull(::toTrack)
            val albums = tracks.filter { it.album.isNotBlank() }.distinctBy { it.albumId }
                .map { Album(it.albumId, it.album, it.artist, it.artistId, it.artworkUrl, genre = it.genre) }
            Result.success(ArtistDetail(artist, tracks, albums))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getAlbumDetail(albumId: String): Result<AlbumDetail> = withContext(Dispatchers.IO) {
        if (!isAvailable) return@withContext Result.failure(IllegalStateException("Jamendo Client ID is not configured."))
        try {
            val cleanId = albumId.removePrefix("jam_alb_")
            val tracks = fetchTrackResults("album_id=${enc(cleanId)}", 50).mapNotNull(::toTrack)
            val first = tracks.firstOrNull()
            Result.success(
                AlbumDetail(
                    album = Album(
                        id = albumId,
                        title = first?.album.orEmpty(),
                        artist = first?.artist.orEmpty(),
                        artistId = first?.artistId.orEmpty(),
                        artworkUrl = first?.artworkUrl.orEmpty(),
                        trackCount = tracks.size,
                        genre = first?.genre.orEmpty()
                    ),
                    tracks = tracks
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun fetchTrackResults(queryParameters: String, limit: Int): List<JSONObject> {
        val separator = if (queryParameters.isBlank()) "" else "&$queryParameters"
        val url = "https://api.jamendo.com/v3.0/tracks/?client_id=$clientId&format=json&limit=$limit" +
            "&include=musicinfo&audioformat=mp32$separator"
        return readResults(url)
    }

    private fun fetchArtists(queryParameters: String, limit: Int): List<Artist> {
        val url = "https://api.jamendo.com/v3.0/artists/?client_id=$clientId&format=json&limit=$limit&$queryParameters"
        return readResults(url).mapNotNull { item ->
            val id = item.optString("id")
            val name = item.optString("name")
            if (id.isBlank() || name.isBlank()) null else Artist(
                id = "jam_art_$id",
                name = name,
                bio = item.optString("bio").takeIf { it.isNotBlank() }.orEmpty(),
                imageUrl = httpsOrEmpty(item.optString("image")),
                genre = "Jamendo"
            )
        }.distinctBy { it.id }
    }

    private fun fetchAlbums(queryParameters: String, limit: Int): List<Album> {
        val url = "https://api.jamendo.com/v3.0/albums/?client_id=$clientId&format=json&limit=$limit&$queryParameters"
        return readResults(url).mapNotNull { item ->
            val id = item.optString("id")
            val title = item.optString("name")
            if (id.isBlank() || title.isBlank()) null else Album(
                id = "jam_alb_$id",
                title = title,
                artist = item.optString("artist_name"),
                artistId = "jam_art_${item.optString("artist_id")}",
                artworkUrl = httpsOrEmpty(item.optString("image")),
                releaseYear = item.optString("releasedate").take(4),
                trackCount = item.optInt("tracks_count", 0),
                genre = "Jamendo"
            )
        }.distinctBy { it.id }
    }

    private fun readResults(url: String): List<JSONObject> {
        val request = Request.Builder().url(url).header("User-Agent", "MADXPLAYER/1.1 Android music discovery").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Jamendo HTTP ${response.code}")
            val json = JSONObject(response.body?.string().orEmpty())
            val headers = json.optJSONObject("headers")
            val code = headers?.optInt("status", 0) ?: 0
            if (code >= 400) throw IllegalStateException(headers?.optString("error_message", "Jamendo API error").orEmpty().ifBlank { "Jamendo API error" })
            val results = json.optJSONArray("results") ?: return emptyList()
            return (0 until results.length()).mapNotNull { results.optJSONObject(it) }
        }
    }

    private fun toTrack(item: JSONObject): Track? {
        val id = item.optString("id")
        val title = item.optString("name")
        val artist = item.optString("artist_name")
        val audio = httpsOrEmpty(item.optString("audio"))
        if (id.isBlank() || title.isBlank() || audio.isBlank()) return null
        val downloadAllowedByProvider = item.optBoolean("audiodownload_allowed", false)
        val downloadUri = httpsOrEmpty(item.optString("audiodownload")).takeIf { downloadAllowedByProvider }
        val artistId = item.optString("artist_id")
        val albumId = item.optString("album_id")
        val album = item.optString("album_name")
        val durationMs = (item.optLong("duration", 0L) * 1000L).coerceAtLeast(0L)
        return Track(
            id = "jam_$id",
            title = title,
            artist = artist.ifBlank { "Unknown artist" },
            album = album,
            durationMs = durationMs,
            mediaUri = audio,
            artworkUrl = httpsOrEmpty(item.optString("image")),
            genre = "Jamendo CC",
            isLocal = false,
            artistId = "jam_art_$artistId",
            albumId = "jam_alb_$albumId",
            source = "Jamendo",
            downloadUri = downloadUri,
            downloadAllowed = !downloadUri.isNullOrBlank()
        )
    }

    private fun httpsOrEmpty(value: String): String = value.trim().takeIf { it.startsWith("https://", true) }.orEmpty()
    private fun enc(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.name())
}
