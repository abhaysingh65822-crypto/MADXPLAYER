package com.example.data.ai

import com.example.BuildConfig
import com.example.data.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class SmartPlaylistResult(
    val title: String,
    val description: String,
    val recommendedTrackIds: List<String>,
    val djCommentary: String
)

data class DjMessage(
    val sender: String, // "dj" or "user"
    val text: String,
    val suggestedTrack: Track? = null
)

class GeminiMusicService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun consultMusicDj(
        userPrompt: String,
        catalog: List<Track>,
        currentTrack: Track?
    ): SmartPlaylistResult = withContext(Dispatchers.IO) {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }

        if (catalog.isEmpty()) {
            return@withContext SmartPlaylistResult(
                title = "No tracks available yet",
                description = "Add local music or configure a supported online source first.",
                recommendedTrackIds = emptyList(),
                djCommentary = "I do not have playable tracks to mix yet. Connect a music provider or scan music stored on this phone, then ask me again."
            )
        }
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext fallbackDjResponse(userPrompt, catalog)
        }

        val trackSummaries = catalog.take(20).joinToString("\n") {
            "- ID: ${it.id} | Title: ${it.title} | Artist: ${it.artist} | Genre: ${it.genre}"
        }

        val promptText = """
            You are MADX AI DJ, a charismatic, high-energy music expert for MADXPLAYER with deep knowledge of Indian & Global sounds (Hindi, Bollywood, Punjabi, Lo-fi, Indie, Synthwave).
            The user wants music for: "$userPrompt".
            ${if (currentTrack != null) "Currently playing: ${currentTrack.title} by ${currentTrack.artist}" else ""}
            
            Available catalog tracks:
            $trackSummaries

            Respond strictly in valid JSON with this structure:
            {
              "title": "A punchy, cool playlist title (max 5 words)",
              "description": "Short mood description",
              "recommendedTrackIds": ["ID1", "ID2", ...],
              "djCommentary": "A hype, 2-sentence radio DJ intro hyping the user up for these tracks"
            }
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", promptText) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.7)
            })
        }

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            if (response.isSuccessful && responseBody.isNotBlank()) {
                val json = JSONObject(responseBody)
                val candidates = json.optJSONArray("candidates")
                val text = candidates?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")

                if (!text.isNullOrBlank()) {
                    val parsed = JSONObject(text)
                    val title = parsed.optString("title", "MADX Neon Mix")
                    val desc = parsed.optString("description", "Crafted by MADX AI DJ")
                    val djWords = parsed.optString("djCommentary", "Turn up the volume and immerse into the vibes.")
                    val idsJson = parsed.optJSONArray("recommendedTrackIds")
                    val ids = mutableListOf<String>()
                    if (idsJson != null) {
                        for (i in 0 until idsJson.length()) {
                            ids.add(idsJson.getString(i))
                        }
                    }
                    return@withContext SmartPlaylistResult(
                        title = title,
                        description = desc,
                        recommendedTrackIds = if (ids.isNotEmpty()) ids else catalog.take(4).map { it.id },
                        djCommentary = djWords
                    )
                }
            }
        } catch (_: Exception) {
            // Graceful fallback to local intelligence
        }

        fallbackDjResponse(userPrompt, catalog)
    }

    suspend fun getSongMeaning(track: Track): String = withContext(Dispatchers.IO) {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "Gemini AI is not configured. Add GEMINI_API_KEY to enable song insights for ${track.title}."
        }

        val prompt = "Give a captivating 2-sentence poetic breakdown of the musical mood, cultural roots, and lyrical themes of the song '${track.title}' by '${track.artist}' in the ${track.genre} genre."

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })
            })
        }

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        try {
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (response.isSuccessful) {
                val json = JSONObject(body)
                val text = json.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                    ?.optString("text")
                if (!text.isNullOrBlank()) return@withContext text.trim()
            }
        } catch (_: Exception) {}

        "Couldn't retrieve a verified AI insight for ${track.title} right now. Check the network and Gemini API configuration, then retry."
    }

    private fun fallbackDjResponse(userPrompt: String, catalog: List<Track>): SmartPlaylistResult {
        val lower = userPrompt.lowercase()
        val matching = catalog.filter {
            it.genre.lowercase() in lower ||
            it.title.lowercase().contains(lower) ||
            it.artist.lowercase().contains(lower)
        }.ifEmpty {
            if (lower.contains("chill") || lower.contains("study") || lower.contains("sleep")) {
                catalog.filter { it.genre == "Lo-fi" }
            } else if (lower.contains("dance") || lower.contains("party") || lower.contains("energy")) {
                catalog.filter { it.genre in listOf("Punjabi", "Bollywood", "English") }
            } else {
                catalog.shuffled().take(5)
            }
        }

        return SmartPlaylistResult(
            title = "MADX Neon Pulse: ${userPrompt.capitalizeWords()}",
            description = "AI-curated mix matching '$userPrompt'",
            recommendedTrackIds = matching.map { it.id }.ifEmpty { catalog.take(4).map { it.id } },
            djCommentary = "This mix was created with MADXPLAYER's on-device mood matching. Configure Gemini to enable AI-generated DJ commentary."
        )
    }

    private fun String.capitalizeWords(): String = split(" ").joinToString(" ") { word ->
        word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }
}
