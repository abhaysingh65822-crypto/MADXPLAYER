package com.example.data.download

import com.example.data.model.Track

/** Pure policy for provider-authorized offline copies; direct stream URLs are not enough. */
object MusicDownloadPolicy {
    fun canDownload(track: Track): Boolean {
        val uri = track.downloadUri?.trim().orEmpty()
        val secureHttpUrl = uri.startsWith("https://", ignoreCase = true)
        if (!secureHttpUrl || !track.downloadAllowed || track.isLocal) return false
        // The catalog provider must both permit downloads and expose a distinct HTTPS download URL.
        return track.source.equals("Jamendo", ignoreCase = true) ||
            track.source.contains("open-license audio", ignoreCase = true)
    }
}
