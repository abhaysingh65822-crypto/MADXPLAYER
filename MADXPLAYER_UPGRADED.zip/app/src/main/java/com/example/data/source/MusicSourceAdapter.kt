package com.example.data.source

import com.example.data.model.*

interface MusicSourceAdapter {
    val providerName: String
    val isAvailable: Boolean

    suspend fun search(
        query: String,
        category: SearchCategory = SearchCategory.ALL,
        page: Int = 1,
        limit: Int = 20
    ): Result<SearchResult>

    suspend fun getTrendingTracks(genre: String? = null, limit: Int = 20): Result<List<Track>>

    suspend fun getFeaturedArtists(limit: Int = 15): Result<List<Artist>>

    suspend fun getFeaturedAlbums(limit: Int = 15): Result<List<Album>>

    suspend fun getArtistDetail(artistId: String, artistName: String): Result<ArtistDetail>

    suspend fun getAlbumDetail(albumId: String): Result<AlbumDetail>
}
