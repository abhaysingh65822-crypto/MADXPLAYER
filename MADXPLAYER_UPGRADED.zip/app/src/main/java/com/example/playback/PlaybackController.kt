package com.example.playback

import android.content.Context
import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.data.model.EqualizerPreset
import com.example.data.model.SyncedLyric
import com.example.data.model.Track
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class RepeatMode {
    OFF, ALL, ONE
}

data class PlaybackState(
    val currentTrack: Track? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val queue: List<Track> = emptyList(),
    val queueIndex: Int = -1,
    val shuffleEnabled: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val playbackSpeed: Float = 1.0f,
    val sleepTimerMinutesLeft: Int? = null,
    val errorMessage: String? = null
)

class PlaybackController private constructor(private val appContext: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var exoPlayer: ExoPlayer? = null

    // Audio effects
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private val _equalizerBands = MutableStateFlow<List<Int>>(listOf(0, 0, 0, 0, 0))
    val equalizerBands: StateFlow<List<Int>> = _equalizerBands.asStateFlow()

    private val _bassBoostLevel = MutableStateFlow(300) // 0-1000
    val bassBoostLevel: StateFlow<Int> = _bassBoostLevel.asStateFlow()

    private val _activePreset = MutableStateFlow("Electronic")
    val activePreset: StateFlow<String> = _activePreset.asStateFlow()

    private var sleepTimerJob: Job? = null
    private var positionTrackerJob: Job? = null
    private var playRequestToken: Long = 0L

    var onTrackStartedListener: ((Track) -> Unit)? = null
    private var lastRecordedTrackId: String? = null

    init {
        initializePlayer()
    }

    private fun initializePlayer() {
        val audioAttributes = AudioAttributes.Builder()
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .setUsage(C.USAGE_MEDIA)
            .build()

        val httpDataSourceFactory = androidx.media3.datasource.DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
            .setKeepPostFor302Redirects(true)
            .setConnectTimeoutMs(25000)
            .setReadTimeoutMs(30000)
            .setDefaultRequestProperties(
                mapOf(
                    "Accept" to "*/*",
                    "Accept-Encoding" to "identity",
                    "Connection" to "keep-alive"
                )
            )

        val dataSourceFactory = androidx.media3.datasource.DefaultDataSource.Factory(appContext, httpDataSourceFactory)
        val mediaSourceFactory = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(dataSourceFactory)

        exoPlayer = ExoPlayer.Builder(appContext)
            .setMediaSourceFactory(mediaSourceFactory)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build().apply {
                addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        _playbackState.value = _playbackState.value.copy(isPlaying = isPlaying)
                        if (isPlaying) {
                            val track = _playbackState.value.currentTrack
                            if (track != null && track.id != lastRecordedTrackId) {
                                lastRecordedTrackId = track.id
                                onTrackStartedListener?.invoke(track)
                            }
                            startPositionTracker()
                        } else {
                            stopPositionTracker()
                        }
                    }

                    override fun onPlaybackStateChanged(state: Int) {
                        when (state) {
                            Player.STATE_BUFFERING -> {
                                _playbackState.value = _playbackState.value.copy(isBuffering = true)
                            }
                            Player.STATE_READY -> {
                                _playbackState.value = _playbackState.value.copy(
                                    isBuffering = false,
                                    durationMs = duration.coerceAtLeast(0L)
                                )
                                attachAudioEffects(audioSessionId)
                            }
                            Player.STATE_ENDED -> handleTrackEnded()
                            Player.STATE_IDLE -> {
                                _playbackState.value = _playbackState.value.copy(isBuffering = false)
                            }
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        val message = when {
                            error.errorCodeName.contains("HTTP", ignoreCase = true) || error.message?.contains("403") == true ->
                                "Online stream temporarily restricted by provider. Try another song or refresh."
                            error.errorCodeName.contains("IO", ignoreCase = true) ->
                                "Network error while buffering audio. Check your connection."
                            else -> error.localizedMessage ?: "Playback error"
                        }
                        _playbackState.value = _playbackState.value.copy(
                            isBuffering = false,
                            isPlaying = false,
                            errorMessage = message
                        )
                    }
                })
            }
    }

    fun getPlayer(): ExoPlayer? = exoPlayer

    fun playTrack(track: Track, newQueue: List<Track> = listOf(track)) {
        val index = newQueue.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        val token = ++playRequestToken

        _playbackState.value = _playbackState.value.copy(
            currentTrack = track,
            queue = newQueue,
            queueIndex = index,
            errorMessage = null,
            currentPositionMs = 0L,
            durationMs = track.durationMs
        )

        // Repair only old cached records that contain the known guessed identifier.mp3 URL.
        // New results already carry an actual filename returned by the Archive metadata API.
        val archiveId = track.id.removePrefix("ia_")
        val guessedArchiveUri = "https://archive.org/download/$archiveId/$archiveId.mp3"
        if (!track.isDownloaded && track.id.startsWith("ia_") && track.mediaUri == guessedArchiveUri) {
            scope.launch(Dispatchers.IO) {
                val directUri = com.example.data.source.InternetArchiveSourceAdapter().resolveDirectAudioFile(archiveId)
                withContext(Dispatchers.Main) {
                    if (token != playRequestToken) return@withContext
                    if (directUri.isNullOrBlank()) {
                        _playbackState.value = _playbackState.value.copy(
                            isBuffering = false,
                            isPlaying = false,
                            errorMessage = "This old Archive entry has no verified playable audio file. Search for it again."
                        )
                    } else {
                        startExoPlayback(track.copy(mediaUri = directUri))
                    }
                }
            }
        } else {
            startExoPlayback(track)
        }
    }

    private fun startExoPlayback(track: Track) {
        val player = exoPlayer ?: return
        try {
            val playableUri = track.localFilePath
                ?.takeIf { track.isDownloaded && java.io.File(it).isFile }
                ?.let { Uri.fromFile(java.io.File(it)) }
                ?: Uri.parse(track.mediaUri)
            val mediaItem = MediaItem.Builder()
                .setMediaId(track.id)
                .setUri(playableUri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(track.title)
                        .setArtist(track.artist)
                        .setAlbumTitle(track.album)
                        .setArtworkUri(if (track.artworkUrl.isNotBlank()) Uri.parse(track.artworkUrl) else null)
                        .build()
                )
                .build()

            player.setMediaItem(mediaItem)
            player.prepare()
            player.play()
            // Attach MediaSessionService so Android can expose the persistent notification,
            // lock-screen buttons, headset keys and background playback controls.
            runCatching {
                ContextCompat.startForegroundService(appContext, Intent(appContext, MediaPlaybackService::class.java))
            }
        } catch (e: Exception) {
            _playbackState.value = _playbackState.value.copy(
                isBuffering = false,
                errorMessage = "Failed to start audio playback: ${e.localizedMessage}"
            )
        }
    }

    fun togglePlayPause() {
        val player = exoPlayer ?: return
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_IDLE || player.playbackState == Player.STATE_ENDED) {
                _playbackState.value.currentTrack?.let { playTrack(it, _playbackState.value.queue) }
            } else {
                player.play()
            }
        }
    }

    fun seekTo(positionMs: Long) {
        val player = exoPlayer ?: return
        player.seekTo(positionMs)
        _playbackState.value = _playbackState.value.copy(currentPositionMs = positionMs)
    }

    fun playNext() {
        val state = _playbackState.value
        if (state.queue.isEmpty()) return

        val nextIndex = when {
            state.shuffleEnabled -> (state.queue.indices.filter { it != state.queueIndex }.ifEmpty { state.queue.indices.toList() }).random()
            state.queueIndex + 1 < state.queue.size -> state.queueIndex + 1
            state.repeatMode == RepeatMode.ALL -> 0
            else -> null
        }

        if (nextIndex != null && nextIndex in state.queue.indices) {
            playTrack(state.queue[nextIndex], state.queue)
        }
    }

    fun playPrevious() {
        val state = _playbackState.value
        if (state.queue.isEmpty()) return

        if (state.currentPositionMs > 4000L) {
            seekTo(0L)
            return
        }

        val prevIndex = if (state.queueIndex - 1 >= 0) {
            state.queueIndex - 1
        } else if (state.repeatMode == RepeatMode.ALL) {
            state.queue.size - 1
        } else null

        if (prevIndex != null && prevIndex in state.queue.indices) {
            playTrack(state.queue[prevIndex], state.queue)
        }
    }

    private fun handleTrackEnded() {
        val state = _playbackState.value
        when (state.repeatMode) {
            RepeatMode.ONE -> {
                seekTo(0L)
                exoPlayer?.play()
            }
            else -> playNext()
        }
    }

    fun toggleShuffle() {
        _playbackState.value = _playbackState.value.copy(shuffleEnabled = !_playbackState.value.shuffleEnabled)
    }

    fun cycleRepeatMode() {
        val current = _playbackState.value.repeatMode
        val next = when (current) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
        _playbackState.value = _playbackState.value.copy(repeatMode = next)
    }

    fun addToQueue(track: Track) {
        val currentQueue = _playbackState.value.queue.toMutableList()
        if (currentQueue.none { it.id == track.id }) {
            currentQueue.add(track)
            _playbackState.value = _playbackState.value.copy(queue = currentQueue)
        }
    }

    fun playNextInQueue(track: Track) {
        val currentQueue = _playbackState.value.queue.toMutableList()
        val insertIndex = (_playbackState.value.queueIndex + 1).coerceAtMost(currentQueue.size)
        currentQueue.add(insertIndex, track)
        _playbackState.value = _playbackState.value.copy(queue = currentQueue)
    }

    fun removeQueueItem(index: Int) {
        val currentQueue = _playbackState.value.queue.toMutableList()
        if (index in currentQueue.indices) {
            currentQueue.removeAt(index)
            val newIndex = if (index < _playbackState.value.queueIndex) {
                _playbackState.value.queueIndex - 1
            } else _playbackState.value.queueIndex
            _playbackState.value = _playbackState.value.copy(queue = currentQueue, queueIndex = newIndex)
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        exoPlayer?.setPlaybackSpeed(speed)
        _playbackState.value = _playbackState.value.copy(playbackSpeed = speed)
    }

    fun setSleepTimer(minutes: Int?) {
        sleepTimerJob?.cancel()
        if (minutes == null || minutes <= 0) {
            _playbackState.value = _playbackState.value.copy(sleepTimerMinutesLeft = null)
            return
        }

        _playbackState.value = _playbackState.value.copy(sleepTimerMinutesLeft = minutes)
        sleepTimerJob = scope.launch {
            var remaining = minutes
            while (remaining > 0) {
                delay(60_000L)
                remaining--
                _playbackState.value = _playbackState.value.copy(sleepTimerMinutesLeft = remaining)
            }
            exoPlayer?.pause()
            _playbackState.value = _playbackState.value.copy(sleepTimerMinutesLeft = null)
        }
    }

    // Audio effects
    private fun attachAudioEffects(audioSessionId: Int) {
        if (audioSessionId == C.AUDIO_SESSION_ID_UNSET) return
        try {
            if (equalizer == null) {
                equalizer = Equalizer(0, audioSessionId).apply {
                    enabled = true
                }
            }
            if (bassBoost == null) {
                bassBoost = BassBoost(0, audioSessionId).apply {
                    enabled = true
                    setStrength(_bassBoostLevel.value.toShort())
                }
            }
            applyEqualizerBands(_equalizerBands.value)
        } catch (_: Exception) {
            // Audio effect initialization failed on this device session
        }
    }

    fun setEqualizerBand(bandIndex: Int, levelDb: Int) {
        val bands = _equalizerBands.value.toMutableList()
        if (bandIndex in bands.indices) {
            bands[bandIndex] = levelDb.coerceIn(-10, 10)
            _equalizerBands.value = bands
            _activePreset.value = "Custom"
            applyEqualizerBands(bands)
        }
    }

    fun setBassBoost(level: Int) {
        _bassBoostLevel.value = level.coerceIn(0, 1000)
        try {
            bassBoost?.setStrength(level.toShort())
        } catch (_: Exception) {}
    }

    fun applyPreset(preset: EqualizerPreset) {
        _activePreset.value = preset.name
        _equalizerBands.value = preset.bandLevels
        _bassBoostLevel.value = preset.bassBoost
        applyEqualizerBands(preset.bandLevels)
        setBassBoost(preset.bassBoost)
    }

    private fun applyEqualizerBands(bandLevels: List<Int>) {
        val eq = equalizer ?: return
        try {
            val numBands = eq.numberOfBands.toInt()
            val minEqLevel = eq.bandLevelRange[0]
            val maxEqLevel = eq.bandLevelRange[1]
            val range = maxEqLevel - minEqLevel

            for (i in 0 until numBands) {
                val db = bandLevels.getOrNull(i) ?: 0
                val converted = (minEqLevel + ((db + 10) / 20.0 * range)).toInt().toShort()
                eq.setBandLevel(i.toShort(), converted)
            }
        } catch (_: Exception) {}
    }

    private fun startPositionTracker() {
        stopPositionTracker()
        positionTrackerJob = scope.launch {
            while (isActive) {
                exoPlayer?.let { player ->
                    if (player.isPlaying) {
                        _playbackState.value = _playbackState.value.copy(
                            currentPositionMs = player.currentPosition,
                            durationMs = player.duration.coerceAtLeast(0L)
                        )
                    }
                }
                delay(300L)
            }
        }
    }

    private fun stopPositionTracker() {
        positionTrackerJob?.cancel()
        positionTrackerJob = null
    }

    fun release() {
        stopPositionTracker()
        sleepTimerJob?.cancel()
        try {
            equalizer?.release()
            bassBoost?.release()
            exoPlayer?.release()
        } catch (_: Exception) {}
        exoPlayer = null
    }

    companion object {
        @Volatile
        private var INSTANCE: PlaybackController? = null

        fun getInstance(context: Context): PlaybackController {
            return INSTANCE ?: synchronized(this) {
                val instance = PlaybackController(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }

        fun parseLrcLyrics(lrcContent: String?): List<SyncedLyric> {
            if (lrcContent.isNullOrBlank()) return emptyList()
            val result = mutableListOf<SyncedLyric>()
            val regex = Regex("\\[(\\d{2}):(\\d{2})\\.(\\d{2,3})\\](.*)")

            lrcContent.lines().forEach { line ->
                val match = regex.find(line.trim())
                if (match != null) {
                    val minutes = match.groupValues[1].toLongOrNull() ?: 0L
                    val seconds = match.groupValues[2].toLongOrNull() ?: 0L
                    val millisPart = match.groupValues[3]
                    val millis = if (millisPart.length == 2) millisPart.toLong() * 10 else millisPart.toLong()
                    val totalMs = (minutes * 60 + seconds) * 1000 + millis
                    val text = match.groupValues[4].trim()
                    if (text.isNotBlank()) {
                        result.add(SyncedLyric(timeMs = totalMs, text = text))
                    }
                } else if (line.isNotBlank()) {
                    // Plain text line without timestamp
                    result.add(SyncedLyric(timeMs = -1L, text = line.trim()))
                }
            }
            return result.sortedBy { it.timeMs }
        }
    }
}
