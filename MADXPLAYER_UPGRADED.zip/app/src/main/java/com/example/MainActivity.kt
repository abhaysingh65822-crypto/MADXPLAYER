package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.Playlist
import com.example.data.model.Track
import com.example.data.source.LinkMediaService
import com.example.ui.components.MiniPlayerBar
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.*
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MadxPlayerTheme {
                MadxPlayerApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MadxPlayerApp(
    playerViewModel: PlayerViewModel = viewModel(),
    homeViewModel: HomeViewModel = viewModel(),
    libraryViewModel: LibraryViewModel = viewModel(),
    aiDjViewModel: AiDjViewModel = viewModel(),
    artistViewModel: ArtistViewModel = viewModel(),
    albumViewModel: AlbumViewModel = viewModel()
) {
    var currentScreen by remember { mutableStateOf(0) } // 0: Home, 1: Search, 2: Library
    var showNowPlaying by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    var showEqualizer by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showAiDj by remember { mutableStateOf(false) }

    // Detail screens navigation
    var selectedArtist by remember { mutableStateOf<Artist?>(null) }
    var selectedAlbum by remember { mutableStateOf<Album?>(null) }
    var selectedPlaylist by remember { mutableStateOf<Playlist?>(null) }

    val playbackState by playerViewModel.playbackState.collectAsStateWithLifecycle()
    val favoriteTrackIds by playerViewModel.favoriteTrackIds.collectAsStateWithLifecycle()
    val equalizerBands by playerViewModel.equalizerBands.collectAsStateWithLifecycle()
    val bassBoost by playerViewModel.bassBoostLevel.collectAsStateWithLifecycle()
    val activePreset by playerViewModel.activePreset.collectAsStateWithLifecycle()
    val lyrics by playerViewModel.currentLyrics.collectAsStateWithLifecycle()
    val activeLyricIndex by playerViewModel.activeLyricIndex.collectAsStateWithLifecycle()
    val songMeaning by playerViewModel.songMeaning.collectAsStateWithLifecycle()
    val isMeaningLoading by playerViewModel.isMeaningLoading.collectAsStateWithLifecycle()

    val homeTracks by homeViewModel.displayedTracks.collectAsStateWithLifecycle()
    val allTracks by homeViewModel.allTracks.collectAsStateWithLifecycle()
    val quickPicks by homeViewModel.quickPicks.collectAsStateWithLifecycle()
    val recentlyPlayed by homeViewModel.recentlyPlayed.collectAsStateWithLifecycle()
    val featuredArtists by homeViewModel.featuredArtists.collectAsStateWithLifecycle()
    val featuredAlbums by homeViewModel.featuredAlbums.collectAsStateWithLifecycle()
    val isHomeRefreshing by homeViewModel.isRefreshing.collectAsStateWithLifecycle()
    val selectedGenre by homeViewModel.selectedGenre.collectAsStateWithLifecycle()

    val localTracks by libraryViewModel.localTracks.collectAsStateWithLifecycle()
    val downloadedTracks by libraryViewModel.downloadedTracks.collectAsStateWithLifecycle()
    val playlists by libraryViewModel.playlists.collectAsStateWithLifecycle()
    val favoriteTracks by libraryViewModel.favoriteTracks.collectAsStateWithLifecycle()
    val downloadProgressMap by libraryViewModel.downloadProgressMap.collectAsStateWithLifecycle()

    val djMessages by aiDjViewModel.messages.collectAsStateWithLifecycle()
    val djLoading by aiDjViewModel.isLoading.collectAsStateWithLifecycle()
    val djLastResult by aiDjViewModel.lastGeneratedResult.collectAsStateWithLifecycle()
    val djCatalogTracks by aiDjViewModel.catalogTracks.collectAsStateWithLifecycle()

    val artistState by artistViewModel.artistState.collectAsStateWithLifecycle()
    val albumState by albumViewModel.albumState.collectAsStateWithLifecycle()

    val playlistTracks by remember(selectedPlaylist) {
        if (selectedPlaylist != null) {
            libraryViewModel.getPlaylistTracks(selectedPlaylist!!.id)
        } else {
            flowOf(emptyList())
        }
    }.collectAsStateWithLifecycle(initialValue = emptyList())

    val currentTrack = playbackState.currentTrack
    val progressFraction = if (playbackState.durationMs > 0) {
        playbackState.currentPositionMs.toFloat() / playbackState.durationMs.toFloat()
    } else 0f

    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val composableScope = rememberCoroutineScope()

    LaunchedEffect(playbackState.errorMessage) {
        playbackState.errorMessage?.let { error ->
            snackbarHostState.showSnackbar(message = error, withDismissAction = true)
        }
    }

    // Predictive back handler
    BackHandler(
        enabled = showLyrics || showNowPlaying || showEqualizer || showQueue || showAiDj ||
                selectedArtist != null || selectedAlbum != null || selectedPlaylist != null ||
                currentScreen != 0
    ) {
        when {
            showLyrics -> showLyrics = false
            showEqualizer -> showEqualizer = false
            showQueue -> showQueue = false
            showAiDj -> showAiDj = false
            showNowPlaying -> showNowPlaying = false
            selectedArtist != null -> selectedArtist = null
            selectedAlbum != null -> selectedAlbum = null
            selectedPlaylist != null -> selectedPlaylist = null
            currentScreen != 0 -> currentScreen = 0
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = NeonBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                // Persistent Mini-Player
                if (currentTrack != null && !showNowPlaying) {
                    MiniPlayerBar(
                        currentTrack = currentTrack,
                        isPlaying = playbackState.isPlaying,
                        progressFraction = progressFraction,
                        isFavorite = currentTrack.id in favoriteTrackIds,
                        onExpandClick = { showNowPlaying = true },
                        onPlayPauseClick = { playerViewModel.togglePlayPause() },
                        onNextClick = { playerViewModel.playNext() },
                        onFavoriteToggle = { playerViewModel.toggleFavorite(currentTrack) }
                    )
                }

                // Bottom Navigation Bar
                NavigationBar(
                    containerColor = NeonSurface,
                    contentColor = TextPrimary,
                    tonalElevation = 8.dp,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    NavigationBarItem(
                        selected = currentScreen == 0 && selectedArtist == null && selectedAlbum == null && selectedPlaylist == null,
                        onClick = {
                            selectedArtist = null
                            selectedAlbum = null
                            selectedPlaylist = null
                            currentScreen = 0
                        },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == 0) Icons.Default.Home else Icons.Outlined.Home,
                                contentDescription = "Home"
                            )
                        },
                        label = { Text("Home") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = NeonPurpleBright,
                            indicatorColor = NeonPurple,
                            unselectedIconColor = TextTertiary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_home")
                    )

                    NavigationBarItem(
                        selected = currentScreen == 1 && selectedArtist == null && selectedAlbum == null && selectedPlaylist == null,
                        onClick = {
                            selectedArtist = null
                            selectedAlbum = null
                            selectedPlaylist = null
                            currentScreen = 1
                        },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == 1) Icons.Default.Search else Icons.Outlined.Search,
                                contentDescription = "Search"
                            )
                        },
                        label = { Text("Search") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = NeonCyanBright,
                            indicatorColor = NeonCyan,
                            unselectedIconColor = TextTertiary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_search")
                    )

                    NavigationBarItem(
                        selected = currentScreen == 2 && selectedArtist == null && selectedAlbum == null && selectedPlaylist == null,
                        onClick = {
                            selectedArtist = null
                            selectedAlbum = null
                            selectedPlaylist = null
                            currentScreen = 2
                        },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == 2) Icons.Default.LibraryMusic else Icons.Outlined.LibraryMusic,
                                contentDescription = "Your Library"
                            )
                        },
                        label = { Text("Library") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = NeonMagenta,
                            indicatorColor = NeonMagenta,
                            unselectedIconColor = TextTertiary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_library")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                selectedArtist != null -> {
                    ArtistScreen(
                        state = artistState,
                        currentTrack = currentTrack,
                        isPlaying = playbackState.isPlaying,
                        favoriteTrackIds = favoriteTrackIds,
                        downloadProgressMap = downloadProgressMap,
                        onBackClick = { selectedArtist = null },
                        onTrackClick = { track, list -> playerViewModel.playTrack(track, list) },
                        onAlbumClick = { album ->
                            selectedAlbum = album
                            albumViewModel.loadAlbum(album.id, album.title)
                        },
                        onFavoriteToggle = { playerViewModel.toggleFavorite(it) },
                        onDownloadClick = { playerViewModel.downloadTrack(it) },
                        onPlayNext = { playerViewModel.playNextInQueue(it) },
                        onAddToQueue = { playerViewModel.addToQueue(it) },
                        onLyricsClick = {
                            playerViewModel.playTrack(it, listOf(it))
                            showLyrics = true
                        }
                    )
                }
                selectedAlbum != null -> {
                    AlbumScreen(
                        state = albumState,
                        currentTrack = currentTrack,
                        isPlaying = playbackState.isPlaying,
                        favoriteTrackIds = favoriteTrackIds,
                        downloadProgressMap = downloadProgressMap,
                        onBackClick = { selectedAlbum = null },
                        onTrackClick = { track, list -> playerViewModel.playTrack(track, list) },
                        onArtistClick = { artistId, artistName ->
                            selectedArtist = Artist(id = artistId, name = artistName)
                            artistViewModel.loadArtist(artistId, artistName)
                        },
                        onFavoriteToggle = { playerViewModel.toggleFavorite(it) },
                        onDownloadClick = { playerViewModel.downloadTrack(it) },
                        onPlayNext = { playerViewModel.playNextInQueue(it) },
                        onAddToQueue = { playerViewModel.addToQueue(it) },
                        onLyricsClick = {
                            playerViewModel.playTrack(it, listOf(it))
                            showLyrics = true
                        },
                        onDownloadAllAlbum = { tracks ->
                            tracks.forEach { playerViewModel.downloadTrack(it) }
                        }
                    )
                }
                selectedPlaylist != null -> {
                    PlaylistDetailScreen(
                        playlist = selectedPlaylist!!,
                        tracks = playlistTracks,
                        currentTrack = currentTrack,
                        isPlaying = playbackState.isPlaying,
                        favoriteTrackIds = favoriteTrackIds,
                        downloadProgressMap = downloadProgressMap,
                        onBackClick = { selectedPlaylist = null },
                        onTrackClick = { track, list -> playerViewModel.playTrack(track, list) },
                        onFavoriteToggle = { playerViewModel.toggleFavorite(it) },
                        onDownloadClick = { playerViewModel.downloadTrack(it) },
                        onPlayNext = { playerViewModel.playNextInQueue(it) },
                        onAddToQueue = { playerViewModel.addToQueue(it) },
                        onLyricsClick = {
                            playerViewModel.playTrack(it, playlistTracks)
                            showLyrics = true
                        },
                        onRemoveTrack = { track ->
                            selectedPlaylist?.let { pl ->
                                libraryViewModel.removeTrackFromPlaylist(pl.id, track.id)
                            }
                        }
                    )
                }
                currentScreen == 0 -> {
                    HomeScreen(
                        displayedTracks = homeTracks,
                        allTracks = allTracks,
                        quickPicks = quickPicks,
                        recentlyPlayed = recentlyPlayed,
                        featuredArtists = featuredArtists,
                        featuredAlbums = featuredAlbums,
                        genres = homeViewModel.genres,
                        selectedGenre = selectedGenre,
                        currentTrack = currentTrack,
                        isPlaying = playbackState.isPlaying,
                        favoriteTrackIds = favoriteTrackIds,
                        downloadProgressMap = downloadProgressMap,
                        onGenreSelect = { homeViewModel.selectGenre(it) },
                        onTrackClick = { track, list -> playerViewModel.playTrack(track, list) },
                        onArtistClick = { artist ->
                            selectedArtist = artist
                            artistViewModel.loadArtist(artist.id, artist.name)
                        },
                        onAlbumClick = { album ->
                            selectedAlbum = album
                            albumViewModel.loadAlbum(album.id, album.title)
                        },
                        onFavoriteToggle = { playerViewModel.toggleFavorite(it) },
                        onDownloadClick = { playerViewModel.downloadTrack(it) },
                        onPlayNext = { playerViewModel.playNextInQueue(it) },
                        onAddToQueue = { playerViewModel.addToQueue(it) },
                        onOpenLyrics = {
                            playerViewModel.playTrack(it, homeTracks)
                            showLyrics = true
                        },
                        onOpenAiDj = { showAiDj = true },
                        isRefreshing = isHomeRefreshing,
                        onRefresh = { homeViewModel.loadDiscoveryContent() }
                    )
                }
                currentScreen == 1 -> {
                    SearchScreen(
                        currentTrack = currentTrack,
                        isPlaying = playbackState.isPlaying,
                        favoriteTrackIds = favoriteTrackIds,
                        downloadProgressMap = downloadProgressMap,
                        onTrackClick = { track, list -> playerViewModel.playTrack(track, list) },
                        onArtistClick = { artist ->
                            selectedArtist = artist
                            artistViewModel.loadArtist(artist.id, artist.name)
                        },
                        onAlbumClick = { album ->
                            selectedAlbum = album
                            albumViewModel.loadAlbum(album.id, album.title)
                        },
                        onFavoriteToggle = { playerViewModel.toggleFavorite(it) },
                        onDownloadClick = { playerViewModel.downloadTrack(it) },
                        onPlayNext = { playerViewModel.playNextInQueue(it) },
                        onAddToQueue = { playerViewModel.addToQueue(it) },
                        onOpenLyrics = {
                            playerViewModel.playTrack(it, allTracks)
                            showLyrics = true
                        },
                        onPlayCustomUrl = { rawUrl, title ->
                            val url = rawUrl.trim()
                            if (LinkMediaService.isAudioComUrl(url)) {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                }.onFailure {
                                    composableScope.launch { snackbarHostState.showSnackbar("Could not open Audio.com in a browser.") }
                                }
                                composableScope.launch {
                                    snackbarHostState.showSnackbar("Opened Audio.com’s official player. Downloads depend on the uploader’s download setting.")
                                }
                            } else {
                                composableScope.launch {
                                    runCatching { LinkMediaService.resolveStreamUrl(context, url) }
                                        .onSuccess { streamUrl ->
                                            val customTrack = Track(
                                                id = "extract_${System.currentTimeMillis()}",
                                                title = title.ifBlank { "Live Link Stream" },
                                                artist = "Online source",
                                                album = "Live Extraction",
                                                durationMs = 0L,
                                                mediaUri = streamUrl,
                                                artworkUrl = "",
                                                genre = "Stream",
                                                source = "yt-dlp live extraction"
                                            )
                                            playerViewModel.playTrack(customTrack, listOf(customTrack))
                                        }
                                        .onFailure { error ->
                                            snackbarHostState.showSnackbar(
                                                "Could not extract a playable stream: ${error.message ?: "unsupported or restricted link"}"
                                            )
                                        }
                                }
                            }
                        },
                        onDownloadCustomUrl = { rawUrl, title ->
                            val url = rawUrl.trim()
                            if (LinkMediaService.isAudioComUrl(url)) {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                }.onFailure {
                                    composableScope.launch { snackbarHostState.showSnackbar("Could not open Audio.com in a browser.") }
                                }
                                composableScope.launch {
                                    snackbarHostState.showSnackbar("Use Audio.com’s official Download control when the uploader has enabled it.")
                                }
                            } else {
                                composableScope.launch {
                                    runCatching { LinkMediaService.downloadAudio(context, url, title) }
                                        .onSuccess { downloaded ->
                                            val localTrack = Track(
                                                id = "linkdl_${System.currentTimeMillis()}",
                                                title = downloaded.title.ifBlank { title },
                                                artist = "Imported from link",
                                                album = "MADXPLAYER Downloads",
                                                durationMs = 0L,
                                                mediaUri = url,
                                                artworkUrl = "",
                                                genre = "Downloaded Audio",
                                                isLocal = false,
                                                isDownloaded = true,
                                                localFilePath = downloaded.file.absolutePath,
                                                source = "User-authorized yt-dlp download",
                                                downloadUri = null,
                                                downloadAllowed = false
                                            )
                                            runCatching { MadxApplication.instance.musicRepository.saveLinkDownload(localTrack) }
                                                .onSuccess {
                                                    snackbarHostState.showSnackbar("Saved ‘${localTrack.title}’ to Library → Downloads.")
                                                }
                                                .onFailure { error ->
                                                    downloaded.file.delete()
                                                    snackbarHostState.showSnackbar("File downloaded but could not be added to the library: ${error.message ?: "database error"}")
                                                }
                                        }
                                        .onFailure { error ->
                                            snackbarHostState.showSnackbar("Download failed: ${error.message ?: "unsupported or restricted link"}")
                                        }
                                }
                            }
                        }
                    )
                }
                currentScreen == 2 -> {
                    LibraryScreen(
                        localTracks = localTracks,
                        downloadedTracks = downloadedTracks,
                        playlists = playlists,
                        favoriteTracks = favoriteTracks,
                        currentTrack = currentTrack,
                        isPlaying = playbackState.isPlaying,
                        favoriteTrackIds = favoriteTrackIds,
                        downloadProgressMap = downloadProgressMap,
                        onTrackClick = { track, list -> playerViewModel.playTrack(track, list) },
                        onPlaylistClick = { playlist ->
                            selectedPlaylist = playlist
                        },
                        onFavoriteToggle = { playerViewModel.toggleFavorite(it) },
                        onDownloadClick = { playerViewModel.downloadTrack(it) },
                        onPlayNext = { playerViewModel.playNextInQueue(it) },
                        onAddToQueue = { playerViewModel.addToQueue(it) },
                        onLyricsClick = {
                            playerViewModel.playTrack(it, allTracks)
                            showLyrics = true
                        },
                        onScanLocalAudio = { libraryViewModel.scanLocalAudio() },
                        onCreatePlaylist = { name, desc -> libraryViewModel.createPlaylist(name, desc) },
                        onUpdatePlaylist = { id, name, desc -> libraryViewModel.updatePlaylist(id, name, desc) },
                        onDeletePlaylist = { libraryViewModel.deletePlaylist(it) },
                        onExportPlaylist = { id, onResult -> libraryViewModel.exportPlaylist(id, onResult) },
                        onImportPlaylist = { json, onResult -> libraryViewModel.importPlaylist(json, onResult) },
                        onDeleteDownloadedTrack = { libraryViewModel.deleteDownloadedTrack(it) }
                    )
                }
            }
        }
    }

    // Full Screen Now Playing Sheet Overlay
    AnimatedVisibility(
        visible = showNowPlaying && currentTrack != null,
        enter = slideInVertically(initialOffsetY = { it }),
        exit = slideOutVertically(targetOffsetY = { it })
    ) {
        if (currentTrack != null) {
            NowPlayingSheet(
                track = currentTrack,
                isPlaying = playbackState.isPlaying,
                currentPositionMs = playbackState.currentPositionMs,
                durationMs = playbackState.durationMs,
                isFavorite = currentTrack.id in favoriteTrackIds,
                shuffleEnabled = playbackState.shuffleEnabled,
                repeatMode = playbackState.repeatMode,
                sleepTimerMinutesLeft = playbackState.sleepTimerMinutesLeft,
                songMeaning = songMeaning,
                isMeaningLoading = isMeaningLoading,
                onDismiss = { showNowPlaying = false },
                onPlayPause = { playerViewModel.togglePlayPause() },
                onSeek = { playerViewModel.seekTo(it) },
                onNext = { playerViewModel.playNext() },
                onPrevious = { playerViewModel.playPrevious() },
                onToggleFavorite = { playerViewModel.toggleFavorite(currentTrack) },
                onToggleShuffle = { playerViewModel.toggleShuffle() },
                onCycleRepeat = { playerViewModel.cycleRepeatMode() },
                onDownloadClick = { playerViewModel.downloadTrack(currentTrack) },
                onOpenLyrics = { showLyrics = true },
                onOpenEqualizer = { showEqualizer = true },
                onOpenQueue = { showQueue = true },
                onFetchSongMeaning = { playerViewModel.fetchSongMeaning(currentTrack) },
                onSetSleepTimer = { playerViewModel.setSleepTimer(it) }
            )
        }
    }

    // Synced Lyrics Modal
    if (showLyrics && currentTrack != null) {
        ModalBottomSheet(
            onDismissRequest = { showLyrics = false },
            containerColor = NeonBackground
        ) {
            SyncedLyricsView(
                track = currentTrack,
                lyrics = lyrics,
                activeLyricIndex = activeLyricIndex,
                onSeekToLine = { playerViewModel.seekTo(it) },
                onClose = { showLyrics = false }
            )
        }
    }

    // Equalizer Sheet Modal
    if (showEqualizer) {
        ModalBottomSheet(
            onDismissRequest = { showEqualizer = false },
            containerColor = NeonSurface
        ) {
            EqualizerSheet(
                bands = equalizerBands,
                bassBoost = bassBoost,
                activePreset = activePreset,
                availablePresets = playerViewModel.availablePresets,
                onBandChange = { band, level -> playerViewModel.setEqualizerBand(band, level) },
                onBassBoostChange = { playerViewModel.setBassBoost(it) },
                onPresetSelect = { playerViewModel.applyPreset(it) },
                onClose = { showEqualizer = false }
            )
        }
    }

    // Up Next Queue Modal
    if (showQueue) {
        ModalBottomSheet(
            onDismissRequest = { showQueue = false },
            containerColor = NeonSurface
        ) {
            QueueSheet(
                queue = playbackState.queue,
                currentQueueIndex = playbackState.queueIndex,
                onTrackSelect = { playerViewModel.playTrack(it, playbackState.queue) },
                onRemoveFromQueue = { playerViewModel.removeQueueItem(it) },
                onClose = { showQueue = false }
            )
        }
    }

    // AI DJ Chat Modal
    if (showAiDj) {
        ModalBottomSheet(
            onDismissRequest = { showAiDj = false },
            containerColor = NeonBackground
        ) {
            AiDjDialog(
                messages = djMessages,
                isLoading = djLoading,
                quickMoods = aiDjViewModel.quickMoods,
                lastResult = djLastResult,
                allTracks = djCatalogTracks,
                onSendPrompt = { aiDjViewModel.sendPrompt(it) },
                onPlayMix = { result, tracks ->
                    aiDjViewModel.playSmartMix(result, tracks)
                    showAiDj = false
                    showNowPlaying = true
                },
                onClose = { showAiDj = false }
            )
        }
    }
}
