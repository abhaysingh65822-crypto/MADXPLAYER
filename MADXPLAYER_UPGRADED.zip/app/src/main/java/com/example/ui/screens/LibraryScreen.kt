package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.download.DownloadProgress
import com.example.data.model.Playlist
import com.example.data.model.Track
import com.example.ui.components.TrackRowItem
import com.example.ui.theme.*

@Composable
fun LibraryScreen(
    localTracks: List<Track>,
    downloadedTracks: List<Track>,
    playlists: List<Playlist>,
    favoriteTracks: List<Track>,
    currentTrack: Track?,
    isPlaying: Boolean,
    favoriteTrackIds: Set<String>,
    downloadProgressMap: Map<String, DownloadProgress>,
    onTrackClick: (Track, List<Track>) -> Unit,
    onPlaylistClick: (Playlist) -> Unit,
    onFavoriteToggle: (Track) -> Unit,
    onDownloadClick: (Track) -> Unit,
    onPlayNext: (Track) -> Unit,
    onAddToQueue: (Track) -> Unit,
    onLyricsClick: (Track) -> Unit,
    onScanLocalAudio: () -> Unit,
    onCreatePlaylist: (String, String) -> Unit,
    onUpdatePlaylist: (String, String, String) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onExportPlaylist: (String, (String?) -> Unit) -> Unit,
    onImportPlaylist: (String, (Boolean) -> Unit) -> Unit,
    onDeleteDownloadedTrack: (Track) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Playlists", "Liked Songs", "Downloads", "Device Files")

    var showCreatePlaylistDialog by remember { mutableStateOf(false) }
    var showImportDialog by remember { mutableStateOf(false) }
    var renameTargetPlaylist by remember { mutableStateOf<Playlist?>(null) }
    var exportedJsonText by remember { mutableStateOf<String?>(null) }

    // Storage permission launcher for scanning device audio
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            onScanLocalAudio()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("library_screen")
    ) {
        // Library Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "YOUR LIBRARY",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                ),
                color = TextPrimary
            )

            if (selectedTab == 0) {
                Row {
                    IconButton(onClick = { showImportDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = "Import Playlist",
                            tint = NeonCyan
                        )
                    }
                    IconButton(onClick = { showCreatePlaylistDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Create Playlist",
                            tint = NeonPurpleBright
                        )
                    }
                }
            } else if (selectedTab == 3) {
                IconButton(
                    onClick = {
                        val perm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            Manifest.permission.READ_MEDIA_AUDIO
                        } else {
                            Manifest.permission.READ_EXTERNAL_STORAGE
                        }
                        permissionLauncher.launch(perm)
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Scan Device Audio",
                        tint = NeonCyan
                    )
                }
            }
        }

        // Tab Row
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            contentColor = NeonPurpleBright,
            edgePadding = 16.dp,
            divider = {}
        ) {
            tabs.forEachIndexed { index, title ->
                val isSelected = selectedTab == index
                Tab(
                    selected = isSelected,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            ),
                            color = if (isSelected) NeonPurpleBright else TextSecondary
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Tab Content
        when (selectedTab) {
            0 -> {
                // Playlists Tab
                if (playlists.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.PlaylistPlay,
                                contentDescription = null,
                                tint = NeonPurple,
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "No playlists yet",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = TextPrimary
                            )
                            Text(
                                text = "Create or import playlists to organize your favorite tracks.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = { showCreatePlaylistDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                                ) {
                                    Text("New Playlist", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { showImportDialog = true },
                                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan)
                                ) {
                                    Text("Import JSON", color = NeonCyan)
                                }
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 120.dp)
                    ) {
                        items(playlists) { playlist ->
                            var showOptionsMenu by remember { mutableStateOf(false) }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .clickable { onPlaylistClick(playlist) },
                                colors = CardDefaults.cardColors(containerColor = NeonSurfaceVariant),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(NeonPurpleContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.QueueMusic,
                                            contentDescription = null,
                                            tint = NeonPurpleBright
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(14.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = playlist.name,
                                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                            color = TextPrimary
                                        )
                                        Text(
                                            text = playlist.description.ifBlank { "Custom Playlist" },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary
                                        )
                                    }

                                    Box {
                                        IconButton(onClick = { showOptionsMenu = true }) {
                                            Icon(
                                                imageVector = Icons.Default.MoreVert,
                                                contentDescription = "Options",
                                                tint = TextTertiary
                                            )
                                        }

                                        DropdownMenu(
                                            expanded = showOptionsMenu,
                                            onDismissRequest = { showOptionsMenu = false },
                                            modifier = Modifier.background(NeonSurfaceVariant)
                                        ) {
                                            DropdownMenuItem(
                                                text = { Text("Rename", color = TextPrimary) },
                                                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = NeonCyan) },
                                                onClick = {
                                                    showOptionsMenu = false
                                                    renameTargetPlaylist = playlist
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("Export JSON", color = TextPrimary) },
                                                leadingIcon = { Icon(Icons.Default.FileUpload, contentDescription = null, tint = NeonPurple) },
                                                onClick = {
                                                    showOptionsMenu = false
                                                    onExportPlaylist(playlist.id) { json ->
                                                        exportedJsonText = json
                                                    }
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("Delete", color = NeonRose) },
                                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = NeonRose) },
                                                onClick = {
                                                    showOptionsMenu = false
                                                    onDeletePlaylist(playlist.id)
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                // Liked Songs Tab
                if (favoriteTracks.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.FavoriteBorder, contentDescription = null, tint = NeonRose, modifier = Modifier.size(56.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No liked songs yet", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Text("Tap the heart on any song to save it here.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 120.dp)
                    ) {
                        items(favoriteTracks) { track ->
                            TrackRowItem(
                                track = track,
                                isCurrentTrack = currentTrack?.id == track.id,
                                isPlaying = isPlaying && currentTrack?.id == track.id,
                                isFavorite = true,
                                downloadProgress = downloadProgressMap[track.id],
                                onTrackClick = { onTrackClick(track, favoriteTracks) },
                                onFavoriteToggle = { onFavoriteToggle(track) },
                                onDownloadClick = { onDownloadClick(track) },
                                onPlayNextClick = { onPlayNext(track) },
                                onAddToQueueClick = { onAddToQueue(track) },
                                onLyricsClick = { onLyricsClick(track) }
                            )
                        }
                    }
                }
            }
            2 -> {
                // Downloads Tab
                if (downloadedTracks.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.DownloadDone, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(56.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No downloaded tracks", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Text("Download tracks to listen offline without internet connection.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 120.dp)
                    ) {
                        items(downloadedTracks) { track ->
                            TrackRowItem(
                                track = track,
                                isCurrentTrack = currentTrack?.id == track.id,
                                isPlaying = isPlaying && currentTrack?.id == track.id,
                                isFavorite = track.id in favoriteTrackIds,
                                downloadProgress = downloadProgressMap[track.id],
                                onTrackClick = { onTrackClick(track, downloadedTracks) },
                                onFavoriteToggle = { onFavoriteToggle(track) },
                                onDownloadClick = { onDeleteDownloadedTrack(track) },
                                onPlayNextClick = { onPlayNext(track) },
                                onAddToQueueClick = { onAddToQueue(track) },
                                onLyricsClick = { onLyricsClick(track) }
                            )
                        }
                    }
                }
            }
            3 -> {
                // Device Files Tab
                if (localTracks.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.FolderOpen, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(64.dp))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("No local device audio scanned", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Text("Grant audio storage permission to scan MP3s and music on your device.", style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
                            Button(
                                onClick = {
                                    val perm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        Manifest.permission.READ_MEDIA_AUDIO
                                    } else {
                                        Manifest.permission.READ_EXTERNAL_STORAGE
                                    }
                                    permissionLauncher.launch(perm)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                            ) {
                                Text("Scan Device Audio", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 120.dp)
                    ) {
                        items(localTracks) { track ->
                            TrackRowItem(
                                track = track,
                                isCurrentTrack = currentTrack?.id == track.id,
                                isPlaying = isPlaying && currentTrack?.id == track.id,
                                isFavorite = track.id in favoriteTrackIds,
                                downloadProgress = downloadProgressMap[track.id],
                                onTrackClick = { onTrackClick(track, localTracks) },
                                onFavoriteToggle = { onFavoriteToggle(track) },
                                onDownloadClick = {},
                                onPlayNextClick = { onPlayNext(track) },
                                onAddToQueueClick = { onAddToQueue(track) },
                                onLyricsClick = { onLyricsClick(track) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Create Playlist Dialog
    if (showCreatePlaylistDialog) {
        var playlistName by remember { mutableStateOf("") }
        var playlistDesc by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showCreatePlaylistDialog = false },
            title = { Text("New Playlist", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = playlistName,
                        onValueChange = { playlistName = it },
                        label = { Text("Playlist Name") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = playlistDesc,
                        onValueChange = { playlistDesc = it },
                        label = { Text("Description (Optional)") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (playlistName.isNotBlank()) {
                            onCreatePlaylist(playlistName.trim(), playlistDesc.trim())
                            showCreatePlaylistDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                ) {
                    Text("Create", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreatePlaylistDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = NeonSurfaceVariant
        )
    }

    // Rename Playlist Dialog
    renameTargetPlaylist?.let { target ->
        var renameName by remember { mutableStateOf(target.name) }
        var renameDesc by remember { mutableStateOf(target.description) }

        AlertDialog(
            onDismissRequest = { renameTargetPlaylist = null },
            title = { Text("Rename Playlist", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = renameName,
                        onValueChange = { renameName = it },
                        label = { Text("Name") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = renameDesc,
                        onValueChange = { renameDesc = it },
                        label = { Text("Description") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (renameName.isNotBlank()) {
                            onUpdatePlaylist(target.id, renameName.trim(), renameDesc.trim())
                            renameTargetPlaylist = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { renameTargetPlaylist = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = NeonSurfaceVariant
        )
    }

    // Exported JSON Dialog
    exportedJsonText?.let { json ->
        AlertDialog(
            onDismissRequest = { exportedJsonText = null },
            title = { Text("Exported Playlist JSON", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = json,
                    onValueChange = {},
                    readOnly = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                    modifier = Modifier.fillMaxWidth().heightIn(max = 240.dp)
                )
            },
            confirmButton = {
                Button(onClick = { exportedJsonText = null }, colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)) {
                    Text("Close", color = Color.Black)
                }
            },
            containerColor = NeonSurfaceVariant
        )
    }

    // Import Playlist JSON Dialog
    if (showImportDialog) {
        var importInput by remember { mutableStateOf("") }
        var importError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = { Text("Import Playlist from JSON", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Paste a MADXPLAYER playlist JSON string below:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = importInput,
                        onValueChange = { importInput = it; importError = null },
                        placeholder = { Text("{\"name\": \"...\", \"tracks\": [...]}") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                        modifier = Modifier.fillMaxWidth().height(160.dp)
                    )
                    if (importError != null) {
                        Text(importError ?: "", color = NeonRose, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (importInput.isNotBlank()) {
                            onImportPlaylist(importInput) { success ->
                                if (success) {
                                    showImportDialog = false
                                } else {
                                    importError = "Invalid playlist JSON structure"
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text("Import", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = NeonSurfaceVariant
        )
    }
}
