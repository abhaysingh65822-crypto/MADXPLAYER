package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// MADXPLAYER Cyber-Neon & AMOLED Black Palette
val NeonBackground = Color(0xFF09070F)
val NeonSurface = Color(0xFF130E22)
val NeonSurfaceVariant = Color(0xFF1E1736)
val NeonSurfaceBorder = Color(0xFF2E234F)

val NeonPurple = Color(0xFFA855F7)
val NeonPurpleBright = Color(0xFFC084FC)
val NeonPurpleContainer = Color(0xFF341754)

val NeonCyan = Color(0xFF06B6D4)
val NeonCyanBright = Color(0xFF22D3EE)

val NeonMagenta = Color(0xFFE879F9)
val NeonRose = Color(0xFFF43F5E)

val TextPrimary = Color(0xFFFAF7FF)
val TextSecondary = Color(0xFFA39EB5)
val TextTertiary = Color(0xFF706A85)

val SliderTrackDark = Color(0xFF261D42)
