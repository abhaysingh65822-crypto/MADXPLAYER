package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.download.DownloadProgress
import com.example.data.model.AlbumDetail
import com.example.data.model.Track
import com.example.ui.components.TrackRowItem
import com.example.ui.theme.*
import com.example.ui.viewmodel.DetailUiState

@Composable
fun AlbumScreen(
    state: DetailUiState<AlbumDetail>,
    currentTrack: Track?,
    isPlaying: Boolean,
    favoriteTrackIds: Set<String>,
    downloadProgressMap: Map<String, DownloadProgress>,
    onBackClick: () -> Unit,
    onTrackClick: (Track, List<Track>) -> Unit,
    onArtistClick: (String, String) -> Unit,
    onFavoriteToggle: (Track) -> Unit,
    onDownloadClick: (Track) -> Unit,
    onPlayNext: (Track) -> Unit,
    onAddToQueue: (Track) -> Unit,
    onLyricsClick: (Track) -> Unit,
    onDownloadAllAlbum: (List<Track>) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(NeonBackground)
            .statusBarsPadding()
            .testTag("album_screen")
    ) {
        when (state) {
            is DetailUiState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = NeonCyan)
                }
            }
            is DetailUiState.Error -> {
                Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = NeonRose, modifier = Modifier.size(54.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(state.message, color = TextPrimary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = onBackClick, colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)) {
                            Text("Go Back", color = Color.Black)
                        }
                    }
                }
            }
            is DetailUiState.Success -> {
                val detail = state.data
                val album = detail.album

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 120.dp)
                ) {
                    // Header Bar
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onBackClick, modifier = Modifier.size(40.dp)) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = TextPrimary
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ALBUM",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                ),
                                color = NeonCyan
                            )
                        }
                    }

                    // Album Artwork Card & Info
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp, vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(200.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .border(1.dp, NeonPurple.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
                                    .shadow(16.dp, RoundedCornerShape(18.dp), spotColor = NeonPurple)
                                    .background(NeonSurfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                if (album.artworkUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = album.artworkUrl,
                                        contentDescription = album.title,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Icon(Icons.Default.Album, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(80.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = album.title,
                                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                                color = TextPrimary
                            )

                            // Clickable artist link
                            Text(
                                text = album.artist,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = NeonPurpleBright,
                                modifier = Modifier
                                    .padding(top = 4.dp)
                                    .clickable { onArtistClick(album.artistId, album.artist) }
                            )

                            Text(
                                text = "${album.releaseYear.ifBlank { "2024" }} • ${detail.tracks.size} Songs",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                modifier = Modifier.padding(top = 4.dp)
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            // Play and Download buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Button(
                                    onClick = {
                                        if (detail.tracks.isNotEmpty()) {
                                            onTrackClick(detail.tracks.first(), detail.tracks)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                                    shape = RoundedCornerShape(24.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("PLAY", color = Color.Black, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { onDownloadAllAlbum(detail.tracks) },
                                    shape = RoundedCornerShape(24.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Outlined.Download, contentDescription = null, tint = NeonCyan)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("DOWNLOAD", color = NeonCyan, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Tracklist
                    item {
                        Text(
                            text = "TRACKLIST",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            ),
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                        )
                    }

                    items(detail.tracks) { track ->
                        TrackRowItem(
                            track = track,
                            isCurrentTrack = currentTrack?.id == track.id,
                            isPlaying = isPlaying && currentTrack?.id == track.id,
                            isFavorite = track.id in favoriteTrackIds,
                            downloadProgress = downloadProgressMap[track.id],
                            onTrackClick = { onTrackClick(track, detail.tracks) },
                            onFavoriteToggle = { onFavoriteToggle(track) },
                            onDownloadClick = { onDownloadClick(track) },
                            onPlayNextClick = { onPlayNext(track) },
                            onAddToQueueClick = { onAddToQueue(track) },
                            onLyricsClick = { onLyricsClick(track) }
                        )
                    }
                }
            }
        }
    }
}
