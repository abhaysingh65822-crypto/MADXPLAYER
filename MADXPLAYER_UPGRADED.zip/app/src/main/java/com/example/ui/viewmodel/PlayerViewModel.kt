package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.MadxApplication
import com.example.data.model.EqualizerPreset
import com.example.data.model.SyncedLyric
import com.example.data.model.Track
import com.example.playback.PlaybackController
import com.example.playback.PlaybackState
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class PlayerViewModel : ViewModel() {

    private val controller = MadxApplication.instance.playbackController
    private val repository = MadxApplication.instance.musicRepository

    val playbackState: StateFlow<PlaybackState> = controller.playbackState
    val equalizerBands: StateFlow<List<Int>> = controller.equalizerBands
    val bassBoostLevel: StateFlow<Int> = controller.bassBoostLevel
    val activePreset: StateFlow<String> = controller.activePreset
    val favoriteTrackIds: StateFlow<Set<String>> = repository.favoriteTrackIds.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet()
    )

    private val _songMeaning = MutableStateFlow<String?>(null)
    val songMeaning: StateFlow<String?> = _songMeaning.asStateFlow()

    private val _isMeaningLoading = MutableStateFlow(false)
    val isMeaningLoading: StateFlow<Boolean> = _isMeaningLoading.asStateFlow()

    val availablePresets: List<EqualizerPreset> = listOf(
        EqualizerPreset("Electronic", listOf(4, 2, 0, 3, 5), 450),
        EqualizerPreset("Bass Boost", listOf(6, 4, 1, 0, 2), 750),
        EqualizerPreset("Pop", listOf(2, 4, 3, 2, 4), 300),
        EqualizerPreset("Rock", listOf(5, 3, -1, 2, 5), 400),
        EqualizerPreset("Vocal", listOf(-2, 1, 5, 4, 1), 150),
        EqualizerPreset("Flat", listOf(0, 0, 0, 0, 0), 0)
    )

    val currentLyrics: StateFlow<List<SyncedLyric>> = playbackState.map { state ->
        PlaybackController.parseLrcLyrics(state.currentTrack?.lyrics)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeLyricIndex: StateFlow<Int> = combine(playbackState, currentLyrics) { state, lyrics ->
        val pos = state.currentPositionMs
        if (lyrics.isEmpty()) -1
        else {
            val idx = lyrics.indexOfLast { it.timeMs in 0..pos }
            if (idx != -1) idx else 0
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), -1)

    fun playTrack(track: Track, queue: List<Track> = listOf(track)) {
        controller.playTrack(track, queue)
        _songMeaning.value = null
        // Playback history is recorded by PlaybackController only after audio actually starts.
    }

    fun togglePlayPause() = controller.togglePlayPause()

    fun seekTo(positionMs: Long) = controller.seekTo(positionMs)

    fun playNext() = controller.playNext()

    fun playPrevious() = controller.playPrevious()

    fun toggleShuffle() = controller.toggleShuffle()

    fun cycleRepeatMode() = controller.cycleRepeatMode()

    fun addToQueue(track: Track) = controller.addToQueue(track)

    fun playNextInQueue(track: Track) = controller.playNextInQueue(track)

    fun removeQueueItem(index: Int) = controller.removeQueueItem(index)

    fun setSleepTimer(minutes: Int?) = controller.setSleepTimer(minutes)

    fun setEqualizerBand(band: Int, level: Int) = controller.setEqualizerBand(band, level)

    fun setBassBoost(level: Int) = controller.setBassBoost(level)

    fun applyPreset(preset: EqualizerPreset) = controller.applyPreset(preset)

    fun toggleFavorite(track: Track) {
        viewModelScope.launch {
            repository.toggleFavorite(track)
        }
    }

    fun downloadTrack(track: Track) {
        repository.downloadManager.downloadTrack(track)
    }

    fun fetchSongMeaning(track: Track) {
        viewModelScope.launch {
            _isMeaningLoading.value = true
            _songMeaning.value = repository.geminiService.getSongMeaning(track)
            _isMeaningLoading.value = false
        }
    }
}
