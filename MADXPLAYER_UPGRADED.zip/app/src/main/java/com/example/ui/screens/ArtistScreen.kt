package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.download.DownloadProgress
import com.example.data.model.Album
import com.example.data.model.ArtistDetail
import com.example.data.model.Track
import com.example.ui.components.NeonBadge
import com.example.ui.components.SectionHeader
import com.example.ui.components.TrackRowItem
import com.example.ui.theme.*
import com.example.ui.viewmodel.DetailUiState

@Composable
fun ArtistScreen(
    state: DetailUiState<ArtistDetail>,
    currentTrack: Track?,
    isPlaying: Boolean,
    favoriteTrackIds: Set<String>,
    downloadProgressMap: Map<String, DownloadProgress>,
    onBackClick: () -> Unit,
    onTrackClick: (Track, List<Track>) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onFavoriteToggle: (Track) -> Unit,
    onDownloadClick: (Track) -> Unit,
    onPlayNext: (Track) -> Unit,
    onAddToQueue: (Track) -> Unit,
    onLyricsClick: (Track) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(NeonBackground)
            .statusBarsPadding()
            .testTag("artist_screen")
    ) {
        when (state) {
            is DetailUiState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = NeonPurpleBright)
                }
            }
            is DetailUiState.Error -> {
                Box(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = NeonRose, modifier = Modifier.size(54.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(state.message, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = onBackClick, colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)) {
                            Text("Go Back", color = Color.Black)
                        }
                    }
                }
            }
            is DetailUiState.Success -> {
                val detail = state.data
                val artist = detail.artist

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 120.dp)
                ) {
                    // Hero Artist Banner
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp)
                        ) {
                            if (artist.imageUrl.isNotBlank()) {
                                AsyncImage(
                                    model = artist.imageUrl,
                                    contentDescription = artist.name,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Brush.verticalGradient(listOf(NeonPurpleContainer, NeonSurface)))
                                )
                            }

                            // Dark Gradient Overlay
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                Color.Black.copy(alpha = 0.4f),
                                                Color.Transparent,
                                                NeonBackground
                                            )
                                        )
                                    )
                            )

                            // Top Back Button
                            IconButton(
                                onClick = onBackClick,
                                modifier = Modifier
                                    .padding(16.dp)
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.5f))
                                    .align(Alignment.TopStart)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = TextPrimary
                                )
                            }

                            // Artist Name and Bio Summary
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(horizontal = 20.dp, vertical = 12.dp)
                            ) {
                                if (artist.genre.isNotBlank()) {
                                    NeonBadge(text = artist.genre.uppercase(), accentColor = NeonCyan)
                                    Spacer(modifier = Modifier.height(6.dp))
                                }
                                Text(
                                    text = artist.name,
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.sp
                                    ),
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${detail.topTracks.size} Tracks available",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }

                    // Play All & Shuffle Action Bar
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    if (detail.topTracks.isNotEmpty()) {
                                        onTrackClick(detail.topTracks.first(), detail.topTracks)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                                shape = RoundedCornerShape(24.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("PLAY ALL", color = Color.Black, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    if (detail.topTracks.isNotEmpty()) {
                                        val shuffled = detail.topTracks.shuffled()
                                        onTrackClick(shuffled.first(), shuffled)
                                    }
                                },
                                shape = RoundedCornerShape(24.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Shuffle, contentDescription = null, tint = NeonPurple)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("SHUFFLE", color = NeonPurple, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Biography Card
                    if (artist.bio.isNotBlank()) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp, vertical = 8.dp),
                                colors = CardDefaults.cardColors(containerColor = NeonSurfaceVariant),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "ABOUT THE ARTIST",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 1.sp
                                        ),
                                        color = NeonPurpleBright
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = artist.bio,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextPrimary
                                    )
                                }
                            }
                        }
                    }

                    // Discography Albums Carousel (if any)
                    if (detail.albums.isNotEmpty()) {
                        item {
                            SectionHeader(title = "Albums & Singles", subtitle = "Discography")
                        }
                        item {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 20.dp),
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                modifier = Modifier.padding(bottom = 12.dp)
                            ) {
                                items(detail.albums) { album ->
                                    Column(
                                        modifier = Modifier
                                            .width(120.dp)
                                            .clickable { onAlbumClick(album) }
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(120.dp)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(NeonSurfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (album.artworkUrl.isNotBlank()) {
                                                AsyncImage(
                                                    model = album.artworkUrl,
                                                    contentDescription = album.title,
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentScale = ContentScale.Crop
                                                )
                                            } else {
                                                Icon(Icons.Default.Album, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(40.dp))
                                            }
                                        }
                                        Text(
                                            text = album.title,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = TextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                        Text(
                                            text = album.releaseYear.ifBlank { "Album" },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Top Tracks Section
                    item {
                        SectionHeader(title = "Popular Tracks", subtitle = "${detail.topTracks.size} available")
                    }

                    items(detail.topTracks) { track ->
                        TrackRowItem(
                            track = track,
                            isCurrentTrack = currentTrack?.id == track.id,
                            isPlaying = isPlaying && currentTrack?.id == track.id,
                            isFavorite = track.id in favoriteTrackIds,
                            downloadProgress = downloadProgressMap[track.id],
                            onTrackClick = { onTrackClick(track, detail.topTracks) },
                            onFavoriteToggle = { onFavoriteToggle(track) },
                            onDownloadClick = { onDownloadClick(track) },
                            onPlayNextClick = { onPlayNext(track) },
                            onAddToQueueClick = { onAddToQueue(track) },
                            onLyricsClick = { onLyricsClick(track) }
                        )
                    }
                }
            }
        }
    }
}
