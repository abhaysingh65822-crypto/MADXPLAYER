package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.MadxApplication
import com.example.data.download.DownloadProgress
import com.example.data.model.Playlist
import com.example.data.model.Track
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class LibraryViewModel : ViewModel() {

    private val repository = MadxApplication.instance.musicRepository

    val allTracks: StateFlow<List<Track>> = repository.allTracks.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val localTracks: StateFlow<List<Track>> = repository.localDeviceTracks.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val downloadedTracks: StateFlow<List<Track>> = repository.downloadedTracks.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val playlists: StateFlow<List<Playlist>> = repository.playlists.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val favoriteTracks: StateFlow<List<Track>> = combine(allTracks, repository.favoriteTrackIds) { tracks, favIds ->
        tracks.filter { it.id in favIds }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloadProgressMap: StateFlow<Map<String, DownloadProgress>> = repository.downloadManager.downloadProgressMap

    fun scanLocalAudio() {
        viewModelScope.launch {
            repository.scanLocalAudio()
        }
    }

    fun createPlaylist(name: String, description: String = "") {
        viewModelScope.launch {
            repository.createPlaylist(name, description)
        }
    }

    fun updatePlaylist(id: String, name: String, description: String) {
        viewModelScope.launch {
            repository.updatePlaylist(id, name, description)
        }
    }

    fun deletePlaylist(id: String) {
        viewModelScope.launch {
            repository.deletePlaylist(id)
        }
    }

    fun addTrackToPlaylist(playlistId: String, track: Track) {
        viewModelScope.launch {
            repository.addTrackToPlaylist(playlistId, track)
        }
    }

    fun removeTrackFromPlaylist(playlistId: String, trackId: String) {
        viewModelScope.launch {
            repository.removeTrackFromPlaylist(playlistId, trackId)
        }
    }

    fun deleteDownloadedTrack(track: Track) {
        viewModelScope.launch {
            repository.downloadManager.deleteDownloadedTrack(track)
        }
    }

    fun exportPlaylist(playlistId: String, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val json = repository.exportPlaylistToJson(playlistId)
                onResult(json)
            } catch (e: Exception) {
                onResult(null)
            }
        }
    }

    fun importPlaylist(json: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val res = repository.importPlaylistFromJson(json)
            onResult(res.isSuccess)
        }
    }

    fun getPlaylistTracks(playlistId: String): Flow<List<Track>> {
        return repository.getTracksForPlaylist(playlistId)
    }
}
