package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.MadxApplication
import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.Track
import com.example.data.repository.CuratedMusicCatalog
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class HomeViewModel : ViewModel() {
    private val repository = MadxApplication.instance.musicRepository

    val genres = CuratedMusicCatalog.getGenres()
    private val _selectedGenre = MutableStateFlow("All")
    val selectedGenre: StateFlow<String> = _selectedGenre.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    // This is the saved/local library only. Online discovery is a separate stream and never gets
    // persisted as a fake or permanent library entry just because it appeared on the home screen.
    val allTracks: StateFlow<List<Track>> = repository.allTracks.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    private val _onlineTracks = MutableStateFlow<List<Track>>(emptyList())
    val onlineTracks: StateFlow<List<Track>> = _onlineTracks.asStateFlow()
    private var discoveryJob: Job? = null

    private val discoveryTracks: StateFlow<List<Track>> = combine(allTracks, onlineTracks) { local, online ->
        (online + local).distinctBy { it.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentlyPlayed: StateFlow<List<Track>> = repository.recentlyPlayedTracks.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    private val _featuredArtists = MutableStateFlow<List<Artist>>(emptyList())
    val featuredArtists: StateFlow<List<Artist>> = _featuredArtists.asStateFlow()

    private val _featuredAlbums = MutableStateFlow<List<Album>>(emptyList())
    val featuredAlbums: StateFlow<List<Album>> = _featuredAlbums.asStateFlow()

    // Online results have already been searched for the selected genre; do not filter them a
    // second time by a provider's generic label such as "Jamendo CC" or valid results disappear.
    val displayedTracks: StateFlow<List<Track>> = combine(allTracks, onlineTracks, selectedGenre) { local, online, genre ->
        val localMatches = if (genre.equals("All", true)) local else local.filter { track ->
            track.genre.equals(genre, ignoreCase = true) || track.genre.contains(genre, ignoreCase = true)
        }
        (online + localMatches).distinctBy { it.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val quickPicks: StateFlow<List<Track>> = discoveryTracks.map { tracks -> tracks.take(8) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init { loadDiscoveryContent() }

    fun loadDiscoveryContent(genre: String = _selectedGenre.value) {
        discoveryJob?.cancel()
        discoveryJob = viewModelScope.launch {
            _isRefreshing.value = true
            try {
                val providerQuery = if (genre.equals("All", true)) null else genre
                val tracks = repository.getTrendingTracks(providerQuery, 16)
                _onlineTracks.value = tracks
                // Artist/album cards are derived from provider-returned records, not fictional profiles.
                _featuredArtists.value = tracks.filter { it.artist.isNotBlank() && it.artist != "Unknown creator" }
                    .distinctBy { it.artistId.ifBlank { it.artist.lowercase() } }
                    .take(12)
                    .map { track -> Artist(track.artistId, track.artist, imageUrl = "", trackCount = 0, genre = track.genre) }
                _featuredAlbums.value = tracks.filter { it.album.isNotBlank() }
                    .distinctBy { it.albumId.ifBlank { it.album.lowercase() } }
                    .take(12)
                    .map { track -> Album(track.albumId, track.album, track.artist, track.artistId, track.artworkUrl, genre = track.genre) }
            } catch (_: Exception) {
                // Keep local content usable even if an online provider fails.
                _onlineTracks.value = emptyList()
                _featuredArtists.value = emptyList()
                _featuredAlbums.value = emptyList()
            } finally {
                _isRefreshing.value = false
            }
        }
    }

    fun selectGenre(genre: String) {
        if (_selectedGenre.value.equals(genre, ignoreCase = true)) return
        _selectedGenre.value = genre
        loadDiscoveryContent(genre)
    }
}
