package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.data.download.DownloadProgress
import com.example.data.model.*
import com.example.ui.components.NeonBadge
import com.example.ui.components.SectionHeader
import com.example.ui.components.TrackRowItem
import com.example.ui.theme.*
import com.example.ui.viewmodel.SearchUiState
import com.example.ui.viewmodel.SearchViewModel

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    currentTrack: Track?,
    isPlaying: Boolean,
    favoriteTrackIds: Set<String>,
    downloadProgressMap: Map<String, DownloadProgress>,
    onTrackClick: (Track, List<Track>) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onFavoriteToggle: (Track) -> Unit,
    onDownloadClick: (Track) -> Unit,
    onPlayNext: (Track) -> Unit,
    onAddToQueue: (Track) -> Unit,
    onOpenLyrics: (Track) -> Unit,
    onPlayCustomUrl: (String, String) -> Unit,
    onDownloadCustomUrl: (String, String) -> Unit,
    searchViewModel: SearchViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    val query by searchViewModel.query.collectAsStateWithLifecycle()
    val searchState by searchViewModel.searchState.collectAsStateWithLifecycle()
    val recentSearches by searchViewModel.recentSearches.collectAsStateWithLifecycle()
    val selectedCategory by searchViewModel.selectedCategory.collectAsStateWithLifecycle()

    var showUrlDialog by remember { mutableStateOf(false) }

    val categories = listOf(
        SearchCategory.ALL to "All",
        SearchCategory.TRACKS to "Songs",
        SearchCategory.ARTISTS to "Artists",
        SearchCategory.ALBUMS to "Albums",
        SearchCategory.LOCAL to "Local Device"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("search_screen")
    ) {
        // Search Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "SEARCH & DISCOVER",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                ),
                color = TextPrimary
            )

            // Direct URL Stream Button
            IconButton(onClick = { showUrlDialog = true }) {
                Icon(
                    imageVector = Icons.Default.Link,
                    contentDescription = "Stream Direct URL",
                    tint = NeonCyan
                )
            }
        }

        // Live Search Input Box
        OutlinedTextField(
            value = query,
            onValueChange = { searchViewModel.onQueryChanged(it) },
            placeholder = { Text("Search songs, artists, albums, genres...", color = TextTertiary) },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = NeonPurple)
            },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { searchViewModel.onQueryChanged("") }) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary)
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonPurple,
                unfocusedBorderColor = NeonSurfaceBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedContainerColor = NeonSurfaceVariant,
                unfocusedContainerColor = NeonSurfaceVariant
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("search_input_field"),
            singleLine = true
        )

        // Category Filter Pills
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { (cat, label) ->
                val isSelected = selectedCategory == cat
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isSelected) NeonCyan else NeonSurfaceVariant)
                        .border(
                            1.dp,
                            if (isSelected) NeonCyanBright else NeonSurfaceBorder,
                            RoundedCornerShape(14.dp)
                        )
                        .clickable { searchViewModel.onCategoryChanged(cat) }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        ),
                        color = if (isSelected) Color.Black else TextPrimary
                    )
                }
            }
        }

        // Search Content depending on state
        when (val state = searchState) {
            is SearchUiState.Idle -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 120.dp)
                ) {
                    if (recentSearches.isNotEmpty()) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "RECENT SEARCHES",
                                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                                    color = TextSecondary
                                )
                                TextButton(onClick = { searchViewModel.clearRecentSearches() }) {
                                    Text("Clear All", color = NeonRose, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }

                        items(recentSearches) { term ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { searchViewModel.onQueryChanged(term) }
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.History, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(text = term, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                                }
                                IconButton(
                                    onClick = { searchViewModel.deleteRecentSearch(term) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Delete", tint = TextTertiary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(20.dp))
                        SectionHeader(title = "Popular Search Ideas", subtitle = "Tap to explore")
                    }

                    item {
                        val ideas = listOf(
                            "Lo-fi instrumental", "Punjabi music", "Indian classical", "Acoustic guitar",
                            "Ambient music", "Bhojpuri folk", "Tamil music", "Indie pop"
                        )
                        FlowRow(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ideas.forEach { idea ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(NeonSurfaceVariant)
                                        .clickable { searchViewModel.onQueryChanged(idea) }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Text(idea, color = NeonPurpleBright, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }

            is SearchUiState.Loading -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = NeonPurpleBright)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Searching online catalogs and local storage...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }

            is SearchUiState.Empty -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.SearchOff, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(64.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No results found for \"${state.query}\"",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                        Text(
                            text = "Check spelling or search for broad genres like Hindi, Lo-fi, Instrumental, or Rock.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }

            is SearchUiState.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.CloudOff, contentDescription = null, tint = NeonRose, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Search Error",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                        Text(
                            text = state.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                        )
                        Button(
                            onClick = { searchViewModel.retry() },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                        ) {
                            Text("Retry Search", color = Color.Black)
                        }
                    }
                }
            }

            is SearchUiState.Success -> {
                val res = state.result
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 120.dp)
                ) {
                    // Matching Artists (if any)
                    if (res.artists.isNotEmpty() && (selectedCategory == SearchCategory.ALL || selectedCategory == SearchCategory.ARTISTS)) {
                        item {
                            SectionHeader(title = "Artists", subtitle = "${res.artists.size} found")
                        }
                        item {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                modifier = Modifier.padding(bottom = 12.dp)
                            ) {
                                items(res.artists) { artist ->
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .width(84.dp)
                                            .clickable { onArtistClick(artist) }
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(72.dp)
                                                .clip(CircleShape)
                                                .border(2.dp, NeonPurpleBright, CircleShape)
                                                .background(NeonSurfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (artist.imageUrl.isNotBlank()) {
                                                AsyncImage(
                                                    model = artist.imageUrl,
                                                    contentDescription = artist.name,
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentScale = ContentScale.Crop
                                                )
                                            } else {
                                                Icon(Icons.Default.Person, contentDescription = null, tint = NeonPurple)
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = artist.name,
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                            color = TextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Matching Albums (if any)
                    if (res.albums.isNotEmpty() && (selectedCategory == SearchCategory.ALL || selectedCategory == SearchCategory.ALBUMS)) {
                        item {
                            SectionHeader(title = "Albums", subtitle = "${res.albums.size} found")
                        }
                        item {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.padding(bottom = 12.dp)
                            ) {
                                items(res.albums) { album ->
                                    Column(
                                        modifier = Modifier
                                            .width(110.dp)
                                            .clickable { onAlbumClick(album) }
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(110.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(NeonSurfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (album.artworkUrl.isNotBlank()) {
                                                AsyncImage(
                                                    model = album.artworkUrl,
                                                    contentDescription = album.title,
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentScale = ContentScale.Crop
                                                )
                                            } else {
                                                Icon(Icons.Default.Album, contentDescription = null, tint = NeonCyan)
                                            }
                                        }
                                        Text(
                                            text = album.title,
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                            color = TextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                        Text(
                                            text = album.artist,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Matching Songs
                    if (res.tracks.isNotEmpty() && (selectedCategory == SearchCategory.ALL || selectedCategory == SearchCategory.TRACKS || selectedCategory == SearchCategory.LOCAL)) {
                        item {
                            SectionHeader(title = "Songs", subtitle = "${res.tracks.size} tracks found")
                        }
                        items(res.tracks) { track ->
                            TrackRowItem(
                                track = track,
                                isCurrentTrack = currentTrack?.id == track.id,
                                isPlaying = isPlaying && currentTrack?.id == track.id,
                                isFavorite = track.id in favoriteTrackIds,
                                downloadProgress = downloadProgressMap[track.id],
                                onTrackClick = { onTrackClick(track, res.tracks) },
                                onFavoriteToggle = { onFavoriteToggle(track) },
                                onDownloadClick = { onDownloadClick(track) },
                                onPlayNextClick = { onPlayNext(track) },
                                onAddToQueueClick = { onAddToQueue(track) },
                                onLyricsClick = { onOpenLyrics(track) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Link streaming / optional offline download dialog.
    if (showUrlDialog) {
        var urlInput by remember { mutableStateOf("") }
        var titleInput by remember { mutableStateOf("") }
        var hasPermission by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showUrlDialog = false },
            title = { Text("Live Link Player", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Paste a direct audio link or a supported media page. Live extraction plays a stream without saving the whole file. Downloads are optional and stay in MADXPLAYER's offline library.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text("Track title (optional)") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        label = { Text("Media page or direct audio URL") },
                        placeholder = { Text("https://...") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = hasPermission,
                            onCheckedChange = { hasPermission = it },
                            colors = CheckboxDefaults.colors(checkedColor = NeonCyan)
                        )
                        Text(
                            "I have permission to use this media, and the source allows this action.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    Text(
                        "Audio.com links open in its official player. In-app extraction is disabled there; downloads must be enabled by the uploader.",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary
                    )
                }
            },
            confirmButton = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(
                        enabled = urlInput.isNotBlank() && hasPermission,
                        onClick = {
                            onPlayCustomUrl(urlInput.trim(), titleInput.ifBlank { "Live Link Stream" })
                            showUrlDialog = false
                        }
                    ) {
                        Text("PLAY LIVE", color = if (urlInput.isNotBlank() && hasPermission) NeonCyan else TextTertiary)
                    }
                    Button(
                        enabled = urlInput.isNotBlank() && hasPermission,
                        onClick = {
                            onDownloadCustomUrl(urlInput.trim(), titleInput.ifBlank { "Downloaded Audio" })
                            showUrlDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) {
                        Text("DOWNLOAD", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showUrlDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = NeonSurfaceVariant
        )
    }
}