package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val MadxDarkColorScheme = darkColorScheme(
    primary = NeonPurple,
    onPrimary = Color.Black,
    primaryContainer = NeonPurpleContainer,
    onPrimaryContainer = NeonPurpleBright,
    secondary = NeonCyan,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF0F3542),
    onSecondaryContainer = NeonCyanBright,
    tertiary = NeonMagenta,
    onTertiary = Color.Black,
    background = NeonBackground,
    onBackground = TextPrimary,
    surface = NeonSurface,
    onSurface = TextPrimary,
    surfaceVariant = NeonSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = NeonSurfaceBorder,
    error = NeonRose,
    onError = Color.White
)

@Composable
fun MadxPlayerTheme(
    darkTheme: Boolean = true,
    // By default keep signature MADXPLAYER neon palette unless dynamic color explicitly toggled
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        else -> MadxDarkColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backward-compatible alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MadxPlayerTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}
