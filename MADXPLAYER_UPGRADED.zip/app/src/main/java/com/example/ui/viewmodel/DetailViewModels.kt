package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.MadxApplication
import com.example.data.model.AlbumDetail
import com.example.data.model.ArtistDetail
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface DetailUiState<out T> {
    object Loading : DetailUiState<Nothing>
    data class Success<T>(val data: T) : DetailUiState<T>
    data class Error(val message: String) : DetailUiState<Nothing>
}

class ArtistViewModel : ViewModel() {
    private val repository = MadxApplication.instance.musicRepository

    private val _artistState = MutableStateFlow<DetailUiState<ArtistDetail>>(DetailUiState.Loading)
    val artistState: StateFlow<DetailUiState<ArtistDetail>> = _artistState.asStateFlow()

    fun loadArtist(artistId: String, artistName: String) {
        viewModelScope.launch {
            _artistState.value = DetailUiState.Loading
            try {
                val detail = repository.getArtistDetail(artistId, artistName)
                _artistState.value = DetailUiState.Success(detail)
            } catch (e: Exception) {
                _artistState.value = DetailUiState.Error(e.localizedMessage ?: "Failed to load artist profile")
            }
        }
    }
}

class AlbumViewModel : ViewModel() {
    private val repository = MadxApplication.instance.musicRepository

    private val _albumState = MutableStateFlow<DetailUiState<AlbumDetail>>(DetailUiState.Loading)
    val albumState: StateFlow<DetailUiState<AlbumDetail>> = _albumState.asStateFlow()

    fun loadAlbum(albumId: String, albumTitle: String = "") {
        viewModelScope.launch {
            _albumState.value = DetailUiState.Loading
            try {
                val detail = repository.getAlbumDetail(albumId, albumTitle)
                _albumState.value = DetailUiState.Success(detail)
            } catch (e: Exception) {
                _albumState.value = DetailUiState.Error(e.localizedMessage ?: "Failed to load album tracks")
            }
        }
    }
}
