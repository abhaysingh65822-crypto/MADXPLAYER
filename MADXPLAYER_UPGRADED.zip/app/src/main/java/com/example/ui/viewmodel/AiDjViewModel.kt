package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.MadxApplication
import com.example.data.ai.DjMessage
import com.example.data.ai.SmartPlaylistResult
import com.example.data.model.Track
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AiDjViewModel : ViewModel() {

    private val repository = MadxApplication.instance.musicRepository
    private val controller = MadxApplication.instance.playbackController

    private val _messages = MutableStateFlow<List<DjMessage>>(
        listOf(
            DjMessage(
                sender = "dj",
                text = "Hi, I'm MADX AI DJ. Tell me your mood, activity, or favorite genre. I'll match your request against tracks that are actually available to play; if no matching catalog is connected, I'll tell you rather than inventing songs."
            )
        )
    )
    val messages: StateFlow<List<DjMessage>> = _messages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _lastGeneratedResult = MutableStateFlow<SmartPlaylistResult?>(null)
    val lastGeneratedResult: StateFlow<SmartPlaylistResult?> = _lastGeneratedResult.asStateFlow()

    private val _catalogTracks = MutableStateFlow<List<Track>>(emptyList())
    val catalogTracks: StateFlow<List<Track>> = _catalogTracks.asStateFlow()

    val quickMoods = listOf(
        "Late night coding lo-fi",
        "High energy Punjabi workout",
        "Rainy Mumbai drive",
        "Melodic Bollywood romance",
        "Chill coffee acoustic"
    )

    fun sendPrompt(userPrompt: String) {
        if (userPrompt.isBlank() || _isLoading.value) return
        _messages.value = _messages.value + DjMessage(sender = "user", text = userPrompt)
        _isLoading.value = true

        viewModelScope.launch {
            try {
                // first() returns one snapshot. A normal collect would never finish, so the old
                // implementation stayed on its loading spinner and never called the DJ service.
                val savedTracks = repository.allTracks.first()
                val onlineTracks = repository.getTrendingTracks("All", 16)
                val availableTracks = (onlineTracks + savedTracks).distinctBy { it.id }
                _catalogTracks.value = availableTracks

                val result = repository.geminiService.consultMusicDj(
                    userPrompt,
                    availableTracks,
                    controller.playbackState.value.currentTrack
                )
                // Ignore any IDs the model returned that are not in the actual playable catalog.
                val verifiedIds = result.recommendedTrackIds.filter { id -> availableTracks.any { it.id == id } }.distinct()
                val verifiedResult = result.copy(recommendedTrackIds = verifiedIds)
                _lastGeneratedResult.value = verifiedResult
                val reply = if (availableTracks.isEmpty()) {
                    "I couldn't find playable tracks yet. Add music to your phone or configure a supported online provider, then try again."
                } else {
                    "${verifiedResult.djCommentary}\n\n${verifiedIds.size} matching playable tracks found for this mix."
                }
                _messages.value = _messages.value + DjMessage(sender = "dj", text = reply)
            } catch (e: Exception) {
                _messages.value = _messages.value + DjMessage(
                    sender = "dj",
                    text = "I couldn't build a mix right now. Check your internet connection and music-provider configuration, then try again."
                )
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun playSmartMix(result: SmartPlaylistResult, allTracks: List<Track>) {
        val tracksToPlay = result.recommendedTrackIds.mapNotNull { id ->
            allTracks.find { it.id == id }
        }

        if (tracksToPlay.isNotEmpty()) {
            controller.playTrack(tracksToPlay.first(), tracksToPlay)
        }
    }
}
