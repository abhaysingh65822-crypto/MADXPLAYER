package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.download.DownloadProgress
import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.Track
import com.example.ui.components.SectionHeader
import com.example.ui.components.TrackRowItem
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    displayedTracks: List<Track>,
    allTracks: List<Track>,
    quickPicks: List<Track>,
    recentlyPlayed: List<Track>,
    featuredArtists: List<Artist>,
    featuredAlbums: List<Album>,
    genres: List<String>,
    selectedGenre: String,
    currentTrack: Track?,
    isPlaying: Boolean,
    favoriteTrackIds: Set<String>,
    downloadProgressMap: Map<String, DownloadProgress>,
    onGenreSelect: (String) -> Unit,
    onTrackClick: (Track, List<Track>) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onFavoriteToggle: (Track) -> Unit,
    onDownloadClick: (Track) -> Unit,
    onPlayNext: (Track) -> Unit,
    onAddToQueue: (Track) -> Unit,
    onOpenLyrics: (Track) -> Unit,
    onOpenAiDj: () -> Unit,
    isRefreshing: Boolean = false,
    onRefresh: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen"),
        contentPadding = PaddingValues(bottom = 120.dp)
    ) {
        // App Bar / Title Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "MADXPLAYER",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        ),
                        color = TextPrimary
                    )
                    Text(
                        text = "DISCOVER • STREAM • FEEL",
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp),
                        color = NeonPurpleBright
                    )
                }

                // AI DJ Launcher Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            Brush.horizontalGradient(listOf(NeonPurple, NeonMagenta))
                        )
                        .clickable(onClick = onOpenAiDj)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("home_ai_dj_pill"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "AI DJ",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.Black
                        )
                    }
                }
            }
        }

        // Hero AI DJ Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable(onClick = onOpenAiDj),
                colors = CardDefaults.cardColors(containerColor = NeonSurfaceVariant),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    Brush.horizontalGradient(listOf(NeonPurple, NeonCyan))
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "MADX AI Smart Sets",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                        Text(
                            text = "Ask for a mood-based mix from tracks that are actually available. Gemini is optional; local matching works without an API key.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
                        )
                        Text(
                            text = "Tap to launch DJ →",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = NeonCyanBright
                        )
                    }
                }
            }
        }

        // Genre Filter Chips
        item {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(genres) { genre ->
                    val isSelected = selectedGenre.equals(genre, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) NeonPurple else NeonSurfaceVariant)
                            .border(
                                1.dp,
                                if (isSelected) NeonPurpleBright else NeonSurfaceBorder,
                                RoundedCornerShape(16.dp)
                            )
                            .clickable { onGenreSelect(genre) }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .testTag("genre_chip_$genre")
                    ) {
                        Text(
                            text = genre,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            ),
                            color = if (isSelected) Color.Black else TextPrimary
                        )
                    }
                }
            }
        }

        // Featured Singers and Artists Section
        if (featuredArtists.isNotEmpty()) {
            item {
                SectionHeader(title = "Featured Singers & Artists", subtitle = "Explore artist profiles & discography")
            }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    items(featuredArtists) { artist ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .width(90.dp)
                                .clickable { onArtistClick(artist) }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, NeonPurpleBright, CircleShape)
                                    .background(NeonSurfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                if (artist.imageUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = artist.imageUrl,
                                        contentDescription = artist.name,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = NeonPurple,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = artist.name,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                color = TextPrimary,
                                textAlign = TextAlign.Center,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // Top Albums Carousel
        if (featuredAlbums.isNotEmpty()) {
            item {
                SectionHeader(title = "Albums & Collections", subtitle = "From connected music sources")
            }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    items(featuredAlbums) { album ->
                        Column(
                            modifier = Modifier
                                .width(120.dp)
                                .clickable { onAlbumClick(album) }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(120.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                    .background(NeonSurfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                if (album.artworkUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = album.artworkUrl,
                                        contentDescription = album.title,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Album,
                                        contentDescription = null,
                                        tint = NeonCyan,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }
                            }
                            Text(
                                text = album.title,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                            Text(
                                text = album.artist,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // Quick Picks Carousel
        if (quickPicks.isNotEmpty()) {
            item {
                SectionHeader(title = "Quick Picks", subtitle = "From your available catalog")
            }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    items(quickPicks) { track ->
                        QuickPickCard(
                            track = track,
                            isCurrent = currentTrack?.id == track.id,
                            onClick = { onTrackClick(track, quickPicks) }
                        )
                    }
                }
            }
        }

        // Recently Played Section (if any)
        if (recentlyPlayed.isNotEmpty()) {
            item {
                SectionHeader(title = "Recently Played", subtitle = "Your listening history")
            }
            items(recentlyPlayed.take(4)) { track ->
                TrackRowItem(
                    track = track,
                    isCurrentTrack = currentTrack?.id == track.id,
                    isPlaying = isPlaying && currentTrack?.id == track.id,
                    isFavorite = track.id in favoriteTrackIds,
                    downloadProgress = downloadProgressMap[track.id],
                    onTrackClick = { onTrackClick(track, recentlyPlayed) },
                    onFavoriteToggle = { onFavoriteToggle(track) },
                    onDownloadClick = { onDownloadClick(track) },
                    onPlayNextClick = { onPlayNext(track) },
                    onAddToQueueClick = { onAddToQueue(track) },
                    onLyricsClick = { onOpenLyrics(track) }
                )
            }
            item {
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        // Main Songs Section Header
        item {
            SectionHeader(
                title = if (selectedGenre == "All") "Trending & Fresh" else "$selectedGenre Vibe",
                subtitle = "${displayedTracks.size} tracks available"
            )
        }

        // An honest empty/loading state instead of a fake demo-song wall.
        if (displayedTracks.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = NeonSurfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonSurfaceBorder)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (isRefreshing) {
                            CircularProgressIndicator(color = NeonPurpleBright)
                            Spacer(Modifier.height(12.dp))
                            Text("Searching connected music sources…", color = TextPrimary)
                        } else {
                            Icon(Icons.Default.MusicNote, contentDescription = null, tint = NeonPurpleBright, modifier = Modifier.size(42.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("No playable tracks found yet", color = TextPrimary, style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Connect Jamendo in the project configuration, check your internet connection, or add music on your phone. Only real playable results are shown.",
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = onRefresh) {
                                Text("Retry discovery")
                            }
                        }
                    }
                }
            }
        } else {
            items(displayedTracks, key = { it.id }) { track ->
                TrackRowItem(
                    track = track,
                    isCurrentTrack = currentTrack?.id == track.id,
                    isPlaying = isPlaying && currentTrack?.id == track.id,
                    isFavorite = track.id in favoriteTrackIds,
                    downloadProgress = downloadProgressMap[track.id],
                    onTrackClick = { onTrackClick(track, displayedTracks) },
                    onFavoriteToggle = { onFavoriteToggle(track) },
                    onDownloadClick = { onDownloadClick(track) },
                    onPlayNextClick = { onPlayNext(track) },
                    onAddToQueueClick = { onAddToQueue(track) },
                    onLyricsClick = { onOpenLyrics(track) }
                )
            }
        }
    }
}

@Composable
fun QuickPickCard(
    track: Track,
    isCurrent: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(130.dp)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(130.dp)
                .clip(RoundedCornerShape(14.dp))
                .border(
                    1.dp,
                    if (isCurrent) NeonPurpleBright else NeonSurfaceBorder,
                    RoundedCornerShape(14.dp)
                )
                .background(NeonSurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (track.artworkUrl.isNotBlank()) {
                AsyncImage(
                    model = track.artworkUrl,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = NeonPurple,
                    modifier = Modifier.size(44.dp)
                )
            }

            // Quick Play pill
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(NeonPurple),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Play",
                    tint = Color.Black,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Text(
            text = track.title,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
            ),
            color = if (isCurrent) NeonPurpleBright else TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp)
        )
        Text(
            text = track.artist,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
