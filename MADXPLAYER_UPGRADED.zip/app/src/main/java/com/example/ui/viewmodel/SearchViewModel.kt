package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.MadxApplication
import com.example.data.model.SearchCategory
import com.example.data.model.SearchResult
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface SearchUiState {
    object Idle : SearchUiState
    object Loading : SearchUiState
    data class Success(val result: SearchResult) : SearchUiState
    data class Empty(val query: String) : SearchUiState
    data class Error(val message: String) : SearchUiState
}

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
class SearchViewModel : ViewModel() {

    private val repository = MadxApplication.instance.musicRepository

    val recentSearches: StateFlow<List<String>> = repository.recentSearches.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _selectedCategory = MutableStateFlow(SearchCategory.ALL)
    val selectedCategory: StateFlow<SearchCategory> = _selectedCategory.asStateFlow()

    private val _searchState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val searchState: StateFlow<SearchUiState> = _searchState.asStateFlow()

    init {
        // Debounce search query changes by 350ms to cancel redundant requests
        _query
            .debounce(350L)
            .distinctUntilChanged()
            .flatMapLatest { q ->
                flow {
                    if (q.isBlank()) {
                        emit(SearchUiState.Idle)
                    } else {
                        emit(SearchUiState.Loading)
                        try {
                            val res = repository.liveSearch(q, _selectedCategory.value)
                            if (res.tracks.isEmpty() && res.artists.isEmpty() && res.albums.isEmpty()) {
                                emit(SearchUiState.Empty(q))
                            } else {
                                emit(SearchUiState.Success(res))
                            }
                        } catch (e: Exception) {
                            emit(SearchUiState.Error(e.localizedMessage ?: "Failed to perform live search"))
                        }
                    }
                }
            }
            .onEach { state -> _searchState.value = state }
            .launchIn(viewModelScope)
    }

    fun onQueryChanged(newQuery: String) {
        _query.value = newQuery
    }

    fun onCategoryChanged(category: SearchCategory) {
        _selectedCategory.value = category
        if (_query.value.isNotBlank()) {
            executeSearchNow(_query.value, category)
        }
    }

    fun executeSearchNow(q: String = _query.value, category: SearchCategory = _selectedCategory.value) {
        if (q.isBlank()) {
            _searchState.value = SearchUiState.Idle
            return
        }
        viewModelScope.launch {
            _searchState.value = SearchUiState.Loading
            try {
                val res = repository.liveSearch(q, category)
                if (res.tracks.isEmpty() && res.artists.isEmpty() && res.albums.isEmpty()) {
                    _searchState.value = SearchUiState.Empty(q)
                } else {
                    _searchState.value = SearchUiState.Success(res)
                }
            } catch (e: Exception) {
                _searchState.value = SearchUiState.Error(e.localizedMessage ?: "Network search error")
            }
        }
    }

    fun deleteRecentSearch(recentQuery: String) {
        viewModelScope.launch {
            repository.deleteRecentSearch(recentQuery)
        }
    }

    fun clearRecentSearches() {
        viewModelScope.launch {
            repository.clearRecentSearches()
        }
    }

    fun retry() {
        executeSearchNow()
    }
}
