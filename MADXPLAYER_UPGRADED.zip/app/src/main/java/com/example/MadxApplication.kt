package com.example

import android.app.Application
import com.example.data.ai.GeminiMusicService
import com.example.data.download.DownloadManager
import com.example.data.local.MadxDatabase
import com.example.data.repository.MusicRepository
import com.example.playback.PlaybackController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MadxApplication : Application() {

    lateinit var database: MadxDatabase
        private set

    lateinit var musicRepository: MusicRepository
        private set

    lateinit var playbackController: PlaybackController
        private set

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = MadxDatabase.getDatabase(this)
        playbackController = PlaybackController.getInstance(this)

        val downloadManager = DownloadManager(this, database.musicDao())
        val geminiService = GeminiMusicService()

        musicRepository = MusicRepository(
            context = this,
            musicDao = database.musicDao(),
            downloadManager = downloadManager,
            geminiService = geminiService
        )

        // Record history once a track actually begins playing.
        playbackController.onTrackStartedListener = { track ->
            applicationScope.launch(Dispatchers.IO) {
                musicRepository.recordPlayed(track)
            }
        }

        // Remove obsolete demo seeds and scan real local audio in background
        applicationScope.launch {
            musicRepository.initializeCatalog()
        }
    }

    companion object {
        lateinit var instance: MadxApplication
            private set
    }
}
