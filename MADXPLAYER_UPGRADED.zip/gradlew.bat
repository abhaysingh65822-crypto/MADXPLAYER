@echo off
setlocal
set VERSION=9.3.1
set ROOT_DIR=%~dp0
set GRADLE_HOME=%USERPROFILE%\.gradle\madx-bootstrap\gradle-%VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Downloading Gradle %VERSION% (first run only)...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $u='https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip'; $z=Join-Path $env:TEMP 'madx-gradle.zip'; Invoke-WebRequest $u -OutFile $z; $d=Join-Path $env:USERPROFILE '.gradle\madx-bootstrap'; New-Item -ItemType Directory -Force $d | Out-Null; Expand-Archive -Path $z -DestinationPath $d -Force; Remove-Item $z -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" -p "%ROOT_DIR%" %*
exit /b %ERRORLEVEL%
